import torch


def masked_knn(query_xyz, key_xyz, key_mask, k, radius=None):
    """Return neighbor indices and validity for each query point.

    query_xyz: [B,N,3], key_xyz: [B,M,3], key_mask: [B,M]
    returns idx [B,N,K], valid [B,N,K], squared distances [B,N,K]
    """
    B, N, _ = query_xyz.shape
    M = key_xyz.shape[1]
    k_eff = min(max(1, k), max(1, M))
    d2 = torch.cdist(query_xyz, key_xyz, p=2).pow(2)  # [B,N,M]
    d2 = d2.masked_fill(~key_mask[:, None, :], float('inf'))
    vals, idx = torch.topk(d2, k=k_eff, dim=-1, largest=False, sorted=False)
    valid = torch.isfinite(vals)
    if radius is not None:
        valid = valid & (vals <= radius * radius)
    if k_eff < k:
        pad = k - k_eff
        idx = torch.cat([idx, torch.zeros(B, N, pad, dtype=idx.dtype, device=idx.device)], dim=-1)
        vals = torch.cat([vals, torch.full((B,N,pad), float('inf'), device=vals.device, dtype=vals.dtype)], dim=-1)
        valid = torch.cat([valid, torch.zeros(B,N,pad, dtype=torch.bool, device=valid.device)], dim=-1)
    return idx, valid, vals


def gather_neighbors(features, idx):
    """features [B,M,C], idx [B,N,K] -> [B,N,K,C]."""
    B, M, C = features.shape
    N, K = idx.shape[1], idx.shape[2]
    expanded = features[:, None, :, :].expand(B, N, M, C)
    gather_idx = idx[..., None].expand(B, N, K, C)
    return torch.gather(expanded, 2, gather_idx)


def masked_max(x, valid, dim=2):
    """Masked max where all-invalid rows return zeros."""
    fill = torch.finfo(x.dtype).min
    y = x.masked_fill(~valid[..., None], fill)
    out = y.max(dim=dim).values
    any_valid = valid.any(dim=dim)
    out = torch.where(any_valid[..., None], out, torch.zeros_like(out))
    return out
