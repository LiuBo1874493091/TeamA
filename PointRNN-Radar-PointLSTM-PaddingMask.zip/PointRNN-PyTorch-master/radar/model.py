import torch
import torch.nn as nn
from .masked_ops import masked_knn, gather_neighbors, masked_max


class MaskedSpatioTemporalCorrelation(nn.Module):
    """Pure-PyTorch, padding-aware version of PointRNN's spatio-temporal correlation."""
    def __init__(self, radius, nsamples, in_channels, out_channels):
        super().__init__()
        self.radius = radius
        self.nsamples = nsamples
        self.in_channels = in_channels
        self.net = nn.Sequential(
            nn.Linear(in_channels + out_channels + 3, out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, p1, p2, x1, s2, mask1, mask2):
        idx, neigh_valid, _ = masked_knn(p1, p2, mask2, self.nsamples, self.radius)
        p2g = gather_neighbors(p2, idx)
        s2g = gather_neighbors(s2, idx)
        disp = p2g - p1[:, :, None, :]
        parts = [s2g]
        if self.in_channels > 0:
            parts.append(x1[:, :, None, :].expand(-1, -1, self.nsamples, -1))
        parts.append(disp)
        corr = torch.cat(parts, dim=-1)
        out = self.net(corr)
        out = masked_max(out, neigh_valid, dim=2)
        out = out * mask1[..., None].to(out.dtype)
        return out


class MaskedPointLSTMCell(nn.Module):
    """PointLSTM cell with explicit masks for current and previous point sets."""
    def __init__(self, radius, nsamples, in_channels, out_channels):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.i_corr = MaskedSpatioTemporalCorrelation(radius, nsamples, in_channels, out_channels)
        self.f_corr = MaskedSpatioTemporalCorrelation(radius, nsamples, in_channels, out_channels)
        self.o_corr = MaskedSpatioTemporalCorrelation(radius, nsamples, in_channels, out_channels)
        self.c_new = MaskedSpatioTemporalCorrelation(radius, nsamples, in_channels, out_channels)
        self.c_old = MaskedSpatioTemporalCorrelation(radius, nsamples, 0, out_channels)

    def forward(self, p1, x1, mask1, state=None):
        if state is None:
            # First frame: use same locations as zero-valued memory so current features still enter gates.
            p2 = p1
            mask2 = mask1
            h2 = torch.zeros(p1.size(0), p1.size(1), self.out_channels, device=p1.device, dtype=p1.dtype)
            c2 = torch.zeros_like(h2)
        else:
            p2, h2, c2, mask2 = state
            # If a batch item had an empty previous frame, fall back to zero memory
            # located at the current valid points so current features are still processed.
            no_prev = ~mask2.any(dim=1)
            if no_prev.any():
                sel = no_prev[:, None, None]
                p2 = torch.where(sel, p1, p2)
                h2 = torch.where(sel, torch.zeros_like(h2), h2)
                c2 = torch.where(sel, torch.zeros_like(c2), c2)
                mask2 = torch.where(no_prev[:, None], mask1, mask2)

        i = torch.sigmoid(self.i_corr(p1, p2, x1, h2, mask1, mask2))
        f = torch.sigmoid(self.f_corr(p1, p2, x1, h2, mask1, mask2))
        o = torch.sigmoid(self.o_corr(p1, p2, x1, h2, mask1, mask2))
        c_new = torch.tanh(self.c_new(p1, p2, x1, h2, mask1, mask2))
        c_old = self.c_old(p1, p2, None, c2, mask1, mask2)
        c1 = f * c_old + i * c_new
        h1 = o * torch.tanh(c1)
        m = mask1[..., None].to(h1.dtype)
        h1, c1 = h1 * m, c1 * m
        return p1, h1, c1, mask1


class RadarPointLSTMClassifier(nn.Module):
    """Sequence-of-point-sets binary classifier.

    Input:
      xyz      [B,L,T,3]
      features [B,L,T,F]
      mask     [B,L,T] bool
    Output:
      logits   [B,L,T,2]
    """
    def __init__(self, feature_dim, hidden_dims=(64,128,128), radius=(0.08,0.16,0.24), nsamples=(16,16,16), dropout=0.1):
        super().__init__()
        if isinstance(radius, (int,float)):
            radius = (radius,) * len(hidden_dims)
        if isinstance(nsamples, int):
            nsamples = (nsamples,) * len(hidden_dims)
        assert len(hidden_dims) == len(radius) == len(nsamples)
        self.input_embed = nn.Sequential(
            nn.Linear(feature_dim, hidden_dims[0]), nn.ReLU(inplace=True),
            nn.LayerNorm(hidden_dims[0])
        )
        cells = []
        in_c = hidden_dims[0]
        for h, r, k in zip(hidden_dims, radius, nsamples):
            cells.append(MaskedPointLSTMCell(r, k, in_c, h))
            in_c = h
        self.cells = nn.ModuleList(cells)
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dims[-1], hidden_dims[-1]),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(hidden_dims[-1], 2),
        )

    def forward(self, xyz, features, mask):
        B, L, T, _ = xyz.shape
        states = [None for _ in self.cells]
        outputs = []
        for t in range(L):
            p = xyz[:, t]
            m = mask[:, t]
            x = self.input_embed(features[:, t]) * m[..., None].to(features.dtype)
            for i, cell in enumerate(self.cells):
                states[i] = cell(p, x, m, states[i])
                x = states[i][1]
            logits = self.classifier(x)
            # Zero padded logits for clean downstream output; loss still uses mask.
            logits = logits * m[..., None].to(logits.dtype)
            outputs.append(logits)
        return torch.stack(outputs, dim=1)
