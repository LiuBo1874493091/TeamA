import json
import math
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset


def _as_numeric(series, name):
    x = pd.to_numeric(series, errors='coerce')
    if x.isna().all():
        raise ValueError(f'Column {name!r} has no numeric values.')
    return x


def infer_round_ids(azimuth_deg, wrap_drop_deg=180.0):
    """Infer scan-circle IDs from chronological azimuth values by 360->0 wrap."""
    a = np.asarray(azimuth_deg, dtype=np.float64)
    if len(a) == 0:
        return np.zeros(0, dtype=np.int64)
    prev = a[:-1]
    cur = a[1:]
    wrap = (cur - prev) < -abs(wrap_drop_deg)
    out = np.zeros(len(a), dtype=np.int64)
    out[1:] = np.cumsum(wrap)
    return out


class RadarSequenceDataset(Dataset):
    def __init__(self, csv_path, config, split='train'):
        self.csv_path = str(csv_path)
        self.cfg = config
        self.split = split
        df = pd.read_csv(csv_path)
        cols = config['columns']
        azi_col = cols['azimuth']
        range_col = cols['range']
        label_col = cols['label']
        for c in [azi_col, range_col, label_col]:
            if c not in df.columns:
                raise KeyError(f'Required CSV column {c!r} not found. Available columns: {list(df.columns)}')

        df = df.copy()
        df['_row_order'] = np.arange(len(df))
        df[azi_col] = _as_numeric(df[azi_col], azi_col) % 360.0
        df[range_col] = _as_numeric(df[range_col], range_col)

        round_col = cols.get('round_id')
        if round_col and round_col in df.columns:
            df['_round'] = pd.to_numeric(df[round_col], errors='raise').astype(np.int64)
        else:
            df = df.sort_values('_row_order')
            df['_round'] = infer_round_ids(df[azi_col].to_numpy(), config['data'].get('wrap_drop_deg', 180.0))

        sector_width = float(config['data'].get('sector_width_deg', 30.0))
        if 360.0 % sector_width != 0:
            raise ValueError('sector_width_deg must divide 360 exactly in this implementation.')
        df['_sector'] = np.floor(df[azi_col] / sector_width).astype(np.int64)

        # Binary labels. Values listed in positive_label_values map to 1, all others to 0.
        positives = set(str(v) for v in config['data'].get('positive_label_values', [1, '1', True, 'true', 'target']))
        df['_label'] = df[label_col].map(lambda v: 1 if str(v) in positives else 0).astype(np.int64)

        self.feature_cols = list(cols.get('features', []))
        if not self.feature_cols:
            self.feature_cols = [range_col, azi_col]
        for c in self.feature_cols:
            if c not in df.columns:
                raise KeyError(f'Feature column {c!r} not found in CSV.')
            df[c] = pd.to_numeric(df[c], errors='coerce')
        df[self.feature_cols] = df[self.feature_cols].replace([np.inf,-np.inf], np.nan)
        df[self.feature_cols] = df[self.feature_cols].fillna(df[self.feature_cols].median(numeric_only=True)).fillna(0.0)

        # Feature normalization statistics (can be exported/reused later).
        means = df[self.feature_cols].mean().to_numpy(np.float32)
        stds = df[self.feature_cols].std(ddof=0).to_numpy(np.float32)
        stds[stds < 1e-6] = 1.0
        self.feature_mean = means
        self.feature_std = stds

        elev_col = cols.get('elevation')
        range_scale = float(config['data'].get('range_scale', 1000.0))
        az = np.deg2rad(df[azi_col].to_numpy(np.float32))
        rr = df[range_col].to_numpy(np.float32) / range_scale
        if elev_col and elev_col in df.columns:
            elev = np.deg2rad(pd.to_numeric(df[elev_col], errors='coerce').fillna(0).to_numpy(np.float32))
            xy = rr * np.cos(elev)
            df['_x'] = xy * np.cos(az)
            df['_y'] = xy * np.sin(az)
            df['_z'] = rr * np.sin(elev)
        else:
            df['_x'] = rr * np.cos(az)
            df['_y'] = rr * np.sin(az)
            df['_z'] = 0.0

        self.df = df
        self.groups = {(int(r), int(s)): g for (r,s),g in df.groupby(['_round','_sector'], sort=False)}
        rounds = np.array(sorted(df['_round'].unique()), dtype=np.int64)
        seq_len = int(config['data'].get('sequence_length', 8))
        stride = int(config['data'].get('sequence_stride', 1))
        n_sectors = int(round(360.0 / sector_width))

        # Build chronological sequence windows first, then split by window index.
        # This stays usable even when val/test each contain fewer raw rounds than sequence_length.
        windows = []
        if len(rounds) >= seq_len:
            for start_i in range(0, len(rounds)-seq_len+1, stride):
                win = rounds[start_i:start_i+seq_len]
                if config['data'].get('require_consecutive_round_ids', True) and np.any(np.diff(win) != 1):
                    continue
                windows.append(win.copy())
        if not windows:
            raise RuntimeError('No sequence windows built. Check circle count and sequence_length.')

        train_ratio = float(config['split'].get('train_ratio', 0.7))
        val_ratio = float(config['split'].get('val_ratio', 0.15))
        nw = len(windows)
        train_end = max(1, int(nw * train_ratio))
        val_end = max(train_end + (1 if nw >= 3 else 0), int(nw * (train_ratio + val_ratio)))
        val_end = min(val_end, nw)
        if split == 'train': selected_windows = windows[:train_end]
        elif split == 'val': selected_windows = windows[train_end:val_end]
        elif split == 'test': selected_windows = windows[val_end:]
        else: selected_windows = windows

        self.samples = []
        for win in selected_windows:
            for sector in range(n_sectors):
                if any((int(r), sector) in self.groups for r in win):
                    self.samples.append((win.copy(), sector))

        if len(self.samples) == 0:
            raise RuntimeError(f'No {split} samples built. Check circle count, sequence_length and split ratios.')

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        rounds, sector = self.samples[idx]
        xyz_seq, feat_seq, label_seq = [], [], []
        for r in rounds:
            g = self.groups.get((int(r), int(sector)))
            if g is None:
                xyz_seq.append(np.zeros((0,3), np.float32))
                feat_seq.append(np.zeros((0,len(self.feature_cols)), np.float32))
                label_seq.append(np.zeros((0,), np.int64))
                continue
            xyz = g[['_x','_y','_z']].to_numpy(np.float32)
            feat = g[self.feature_cols].to_numpy(np.float32)
            feat = (feat - self.feature_mean) / self.feature_std
            lab = g['_label'].to_numpy(np.int64)
            max_points = int(self.cfg['data'].get('max_points_per_frame', 0) or 0)
            if max_points > 0 and len(xyz) > max_points:
                # Deterministic uniform thinning, preserving broad spatial coverage/order.
                ids = np.linspace(0, len(xyz)-1, max_points).round().astype(np.int64)
                xyz, feat, lab = xyz[ids], feat[ids], lab[ids]
            xyz_seq.append(xyz); feat_seq.append(feat); label_seq.append(lab)
        return {'xyz': xyz_seq, 'features': feat_seq, 'labels': label_seq,
                'rounds': rounds.astype(np.int64), 'sector': int(sector)}


def radar_collate_fn(batch):
    B = len(batch)
    L = len(batch[0]['xyz'])
    F = batch[0]['features'][0].shape[1] if batch[0]['features'][0].ndim == 2 else 0
    T = max(max((len(frame) for frame in item['xyz']), default=0) for item in batch)
    T = max(T, 1)
    xyz = torch.zeros(B,L,T,3, dtype=torch.float32)
    features = torch.zeros(B,L,T,F, dtype=torch.float32)
    labels = torch.full((B,L,T), -100, dtype=torch.long)
    mask = torch.zeros(B,L,T, dtype=torch.bool)
    sectors = torch.tensor([b['sector'] for b in batch], dtype=torch.long)
    rounds = torch.stack([torch.from_numpy(b['rounds']) for b in batch])
    for b,item in enumerate(batch):
        for t in range(L):
            n = len(item['xyz'][t])
            if n == 0: continue
            xyz[b,t,:n] = torch.from_numpy(item['xyz'][t])
            features[b,t,:n] = torch.from_numpy(item['features'][t])
            labels[b,t,:n] = torch.from_numpy(item['labels'][t])
            mask[b,t,:n] = True
    return {'xyz': xyz, 'features': features, 'labels': labels, 'mask': mask,
            'rounds': rounds, 'sector': sectors}


def load_config(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)
