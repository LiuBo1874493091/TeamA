import argparse, json, os, random
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from radar.dataset import RadarSequenceDataset, radar_collate_fn, load_config
from radar.model import RadarPointLSTMClassifier
from radar.metrics import BinaryMetrics


def seed_all(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)


def make_loader(csv_path, cfg, split, shuffle=False):
    ds = RadarSequenceDataset(csv_path, cfg, split)
    return ds, DataLoader(ds, batch_size=cfg['train']['batch_size'], shuffle=shuffle,
                          num_workers=cfg['train'].get('workers',0), collate_fn=radar_collate_fn,
                          pin_memory=torch.cuda.is_available())


def run_epoch(model, loader, optimizer, device, class_weights=None):
    train = optimizer is not None
    model.train(train)
    criterion = nn.CrossEntropyLoss(weight=class_weights, ignore_index=-100)
    metrics = BinaryMetrics(); total_loss=0.0; total_batches=0
    for batch in loader:
        xyz=batch['xyz'].to(device); feat=batch['features'].to(device)
        labels=batch['labels'].to(device); mask=batch['mask'].to(device)
        with torch.set_grad_enabled(train):
            logits=model(xyz,feat,mask)
            loss=criterion(logits.reshape(-1,2), labels.reshape(-1))
            if train:
                optimizer.zero_grad(set_to_none=True); loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0); optimizer.step()
        total_loss += float(loss.item()); total_batches += 1
        metrics.update(logits.detach(),labels,mask)
    out=metrics.compute(); out['loss']=total_loss/max(total_batches,1); return out


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--csv', required=True); ap.add_argument('--config', default='radar_config.json')
    ap.add_argument('--output', default='outputs/radar_pointlstm'); ap.add_argument('--resume', default='')
    args=ap.parse_args(); cfg=load_config(args.config); seed_all(cfg['train'].get('seed',42))
    out=Path(args.output); out.mkdir(parents=True, exist_ok=True)
    train_ds,train_loader=make_loader(args.csv,cfg,'train',True)
    val_ds,val_loader=make_loader(args.csv,cfg,'val',False)
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model=RadarPointLSTMClassifier(len(train_ds.feature_cols),
        hidden_dims=tuple(cfg['model']['hidden_dims']), radius=tuple(cfg['model']['radius']),
        nsamples=tuple(cfg['model']['nsamples']), dropout=cfg['model'].get('dropout',0.1)).to(device)
    opt=torch.optim.AdamW(model.parameters(),lr=cfg['train']['lr'],weight_decay=cfg['train'].get('weight_decay',1e-4))
    start=0; best=-1
    if args.resume:
        ck=torch.load(args.resume,map_location=device); model.load_state_dict(ck['model']); opt.load_state_dict(ck['optimizer']); start=ck['epoch']+1; best=ck.get('best_f1',-1)
    weights=cfg['train'].get('class_weights')
    cw=torch.tensor(weights,dtype=torch.float32,device=device) if weights else None
    with open(out/'resolved_config.json','w',encoding='utf-8') as f: json.dump(cfg,f,ensure_ascii=False,indent=2)
    for epoch in range(start,cfg['train']['epochs']):
        tr=run_epoch(model,train_loader,opt,device,cw); va=run_epoch(model,val_loader,None,device,cw)
        print(f"epoch={epoch:03d} train loss={tr['loss']:.4f} f1={tr['f1']:.4f} | val loss={va['loss']:.4f} f1={va['f1']:.4f} P={va['precision']:.4f} R={va['recall']:.4f}")
        ck={'model':model.state_dict(),'optimizer':opt.state_dict(),'epoch':epoch,'best_f1':max(best,va['f1']),
            'feature_cols':train_ds.feature_cols,'feature_mean':train_ds.feature_mean,'feature_std':train_ds.feature_std,'config':cfg}
        torch.save(ck,out/'last.pth')
        if va['f1']>best:
            best=va['f1']; torch.save(ck,out/'best.pth')

if __name__=='__main__': main()
