> 历史版本说明：本次流式缓存、增强配置及验证状态以 [README.md](README.md) 和 [STREAMING_AUGMENTATION_CHANGELOG.md](STREAMING_AUGMENTATION_CHANGELOG.md) 为准。本文原有运行验证记录不代表此次修改已通过测试。

# 数据缓存、无泄漏划分与训练曲线更新

## 1. 样本数量
若总圈数为 R，序列长度为 L，stride=S，则一个扇区中的窗口数为：

`floor((R-L)/S)+1`

完整 360°、每个扇区 30° 时有 12 个扇区，因此在每个窗口的 12 个扇区都有点的理想情况下：

`样本数 = 窗口数 × 12`

例如 R=8、L=4、S=1：窗口数为5，因此最多60个样本。若只使用0~180°，才是5×6=30。

## 2. 先按圈次切分，再构建序列
新版先把圈次按时间顺序划分为 train / val / test，再分别在各自内部滑窗，避免训练窗口和验证/测试窗口共享圈次而造成数据泄漏。

因此，对于严格独立的 train/val/test，每个非空划分至少需要 L 圈。小规模示例数据如果圈数过少，应增加圈数，而不是让三个集合共享圈次。

## 3. 持久化预处理缓存
默认：

```json
"cache_preprocessed": true
```

首次运行会在 CSV 旁生成：

`data.csv.radar_cache.pkl`

后续 CSV 和相关配置未变化时直接加载缓存，不再重复读取、分组和构建索引。

强制重建：

```bash
python radar_train.py --csv ./data/data.csv --config radar_config.json --rebuild-cache
```

也可以指定缓存位置：

```bash
python radar_train.py --csv ./data/data.csv --config radar_config.json --cache-path ./data/data_processed.pkl
```

## 4. Loss 与 F1 曲线
每个 epoch 结束后会自动更新：

- `outputs/radar_pointlstm/train_history.csv`
- `outputs/radar_pointlstm/loss_curve.png`
- `outputs/radar_pointlstm/f1_curve.png`

其中 loss_curve 同时包含 Train Loss 与 Val Loss。

## 5. 独立测试集
训练期间只使用 train 和 val。训练完成后使用最佳 checkpoint 在 test 上评估：

```bash
python radar_test.py --csv ./data/data.csv --config radar_config.json --checkpoint outputs/radar_pointlstm/best.pth
```

测试集不参与模型选择和调参。
