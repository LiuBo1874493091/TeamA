"""Independent train-only rotation and IQ transforms; labels/counts stay fixed."""
import math
import numpy as np
import torch

IQ_COLUMNS = ('和I', '和Q', '方I', '方Q')


def _probability(value, name):
    v = float(value)
    if not math.isfinite(v) or not 0 <= v <= 1:
        raise ValueError(f'{name} must be in [0,1].')
    return v


class RadarAugmenter:
    def __init__(self, config, feature_cols, feature_mean, feature_std):
        self.cfg = config.get('augmentation', {}) or {}
        self.rotation = self.cfg.get('sample_rotation', {}) or {}
        self.iq = self.cfg.get('iq_augmentation', {}) or {}
        self.rotation_enabled = bool(self.rotation.get('enabled', False))
        self.iq_enabled = bool(self.iq.get('enabled', False))
        self.enabled = bool(self.cfg.get('enabled', True)) and (self.rotation_enabled or self.iq_enabled)
        self.rprob = _probability(self.rotation.get('probability', .5), 'sample_rotation.probability')
        self.iprob = _probability(self.iq.get('probability', .5), 'iq_augmentation.probability')
        self.feature_cols = list(feature_cols)
        self.indices = {c: i for i, c in enumerate(self.feature_cols)}
        self.mean, self.std = np.asarray(feature_mean, np.float32), np.asarray(feature_std, np.float32)
        if self.mean.shape != (len(feature_cols),) or self.std.shape != self.mean.shape:
            raise ValueError('Augmenter scaler/feature dimension mismatch.')
        if not np.isfinite(self.mean).all() or not np.isfinite(self.std).all() or (self.std <= 0).any():
            raise ValueError('Augmenter requires finite scaler and positive std.')
        self.azimuth_col = config['columns']['azimuth']
        self.range_col = config['columns']['range']
        bounds = self.rotation.get('angle_range_deg', [-180, 180])
        if len(bounds) != 2:
            raise ValueError('sample_rotation.angle_range_deg must be [min,max].')
        self.amin, self.amax = map(float, bounds)
        if not all(map(math.isfinite, (self.amin, self.amax))) or self.amin > self.amax:
            raise ValueError('Invalid sample_rotation.angle_range_deg.')
        names = self.iq.get('columns', list(IQ_COLUMNS))
        if len(names) != len(set(names)) or any(c not in IQ_COLUMNS for c in names):
            raise ValueError(f'iq_augmentation.columns may only select from {IQ_COLUMNS}.')
        if self.enabled and self.iq_enabled and any(c not in self.indices for c in names):
            raise ValueError('Enabled IQ columns must exist in columns.features.')
        self.iq_indices = [self.indices[c] for c in names if c in self.indices]
        self.noise_enabled = bool(self.iq.get('gaussian_noise_enabled', True))
        noise = self.iq.get('noise_std', .02)
        if isinstance(noise, dict):
            if any(c not in names for c in noise):
                raise ValueError('noise_std contains a column outside iq_augmentation.columns.')
            self.noise = np.asarray([float(noise.get(c, 0)) for c in names], np.float64)
        else:
            self.noise = np.full(len(names), float(noise), np.float64)
        if not np.isfinite(self.noise).all() or (self.noise < 0).any():
            raise ValueError('iq_augmentation.noise_std must be finite and >= 0.')
        self.noise_units = self.iq.get('noise_units', 'train_std')
        if self.noise_units not in ('train_std', 'raw'):
            raise ValueError('iq_augmentation.noise_units must be train_std or raw.')
        self.scale_enabled = bool(self.iq.get('amplitude_scale_enabled', True))
        scales = self.iq.get('amplitude_scale_range', [.95, 1.05])
        if len(scales) != 2:
            raise ValueError('amplitude_scale_range must be [min,max].')
        self.smin, self.smax = map(float, scales)
        if not all(map(math.isfinite, (self.smin, self.smax))) or not 0 < self.smin <= self.smax:
            raise ValueError('amplitude_scale_range must be finite, positive and ordered.')

    def _rng(self, sample_idx):
        seed = (int(torch.initial_seed()) + int(sample_idx) * 1000003
                + int(np.random.randint(0, 2**31 - 1))) % (2**63 - 1)
        return np.random.default_rng(seed)

    def __call__(self, xyz_seq, feat_seq, label_seq, sector, sample_idx):
        if not self.enabled:
            return xyz_seq, feat_seq, label_seq
        rng = self._rng(sample_idx)
        rotate = self.rotation_enabled and rng.random() < self.rprob
        augment_iq = self.iq_enabled and rng.random() < self.iprob
        if not rotate and not augment_iq:
            return xyz_seq, feat_seq, label_seq
        # A single angle and amplitude multiplier for all points in all frames.
        angle = rng.uniform(self.amin, self.amax) if rotate else 0.
        amplitude = rng.uniform(self.smin, self.smax) if augment_iq and self.scale_enabled else 1.
        out_xyz, out_feat = [], []
        for x, f in zip(xyz_seq, feat_seq):
            xyz, feat = x.copy(), f.copy()
            if len(x):
                if rotate:
                    j = self.indices.get(self.azimuth_col)
                    az = (f[:, j].astype(np.float64) * self.std[j] + self.mean[j]
                          if j is not None else np.degrees(np.arctan2(x[:, 1], x[:, 0])))
                    az = np.mod(az + angle, 360.)
                    horizontal = np.hypot(x[:, 0].astype(np.float64), x[:, 1].astype(np.float64))
                    rad = np.deg2rad(az)
                    xyz[:, 0], xyz[:, 1] = horizontal * np.cos(rad), horizontal * np.sin(rad)
                    # z/elevation and range stay unchanged, including range features.
                    if j is not None:
                        feat[:, j] = (az - self.mean[j]) / self.std[j]
                if augment_iq:
                    jj = self.iq_indices
                    raw = f[:, jj].astype(np.float64) * self.std[jj] + self.mean[jj]
                    raw *= amplitude
                    if self.noise_enabled:
                        sigma = self.noise * (self.std[jj] if self.noise_units == 'train_std' else 1.)
                        raw += rng.normal(0., sigma, size=raw.shape)
                    feat[:, jj] = (raw - self.mean[jj]) / self.std[jj]
                if not np.isfinite(xyz).all() or not np.isfinite(feat).all():
                    raise FloatingPointError('Augmentation produced NaN/Inf.')
            out_xyz.append(xyz.astype(np.float32, copy=False))
            out_feat.append(feat.astype(np.float32, copy=False))
        return out_xyz, out_feat, label_seq
