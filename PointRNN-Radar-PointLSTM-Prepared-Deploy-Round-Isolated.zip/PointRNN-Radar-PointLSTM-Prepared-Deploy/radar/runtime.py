"""Explicit CUDA/library/model warmup, with CPU as a no-op."""
import time
import torch
from .validation import validate_model_batch, require_finite


def cuda_warmup(device, enabled=True, matmul_size=256):
    if not enabled or device.type != 'cuda':
        return
    t = time.perf_counter()
    print('[CUDA] Initializing context and warming up matrix multiplication...', flush=True)
    torch.cuda.init()
    with torch.no_grad():
        x = torch.ones(int(matmul_size), int(matmul_size), device=device)
        _ = x @ x
    torch.cuda.synchronize(device)
    print(f'[CUDA] Warmup complete: {time.perf_counter() - t:.3f}s', flush=True)


def model_warmup(model, batch, device, enabled=True):
    if not enabled or device.type != 'cuda':
        return
    t = time.perf_counter()
    print('[CUDA] Warming up first model forward...', flush=True)
    mode = model.training
    try:
        model.eval()
        with torch.no_grad():
            xyz = batch['xyz'].to(device)
            feat = batch['features'].to(device)
            mask = batch['mask'].to(device)
            validate_model_batch(xyz, feat, mask, feature_dim=model.feature_dim, stage='warmup')
            require_finite('warmup logits', model(xyz, feat, mask))
        torch.cuda.synchronize(device)
    finally:
        model.train(mode)
    print(f'[CUDA] Model warmup complete: {time.perf_counter() - t:.3f}s', flush=True)
