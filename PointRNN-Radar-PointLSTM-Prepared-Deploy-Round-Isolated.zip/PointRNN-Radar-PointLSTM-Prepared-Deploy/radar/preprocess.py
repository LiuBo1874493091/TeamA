import numpy as np


def infer_round_ids(azimuth_deg, wrap_drop_deg=180.0):
    a = np.asarray(azimuth_deg, dtype=np.float64)
    out = np.zeros(len(a), dtype=np.int64)
    if len(a) > 1:
        out[1:] = np.cumsum((a[1:] - a[:-1]) < -abs(wrap_drop_deg))
    return out


def _windows(rounds, L, stride, consecutive=True):
    for i in range(0, max(0, len(rounds)-L+1), stride):
        w=np.asarray(rounds[i:i+L],dtype=np.int64)
        if len(w)!=L: continue
        if consecutive and np.any(np.diff(w)!=1): continue
        yield w


def _split_rounds(rounds, train_ratio, val_ratio, min_rounds=1):
    """Partition chronological raw rounds before constructing any windows."""
    rounds = np.asarray(rounds, dtype=np.int64)
    if rounds.ndim != 1 or (np.diff(rounds) <= 0).any():
        raise ValueError('Round IDs must be unique and strictly increasing for isolated splitting.')
    n = len(rounds)
    n_train, n_val = int(n * train_ratio), int(n * val_ratio)
    partitions = {
        'train': rounds[:n_train],
        'val': rounds[n_train:n_train + n_val],
        'test': rounds[n_train + n_val:],
    }
    active = ('train', 'val', 'test') if val_ratio > 0 else ('train', 'test')
    for name in active:
        if len(partitions[name]) < min_rounds:
            raise ValueError(
                f'round_isolated {name} has {len(partitions[name])} raw rounds, '
                f'but sequence_length requires at least {min_rounds}. '
                'Increase data or adjust split ratios/sequence_length; '
                'samples are never borrowed across split boundaries.'
            )
    return partitions


def prepare_data(csv_path, config, output_dir):
    from .streaming_prepare import prepare_data_streaming
    return prepare_data_streaming(csv_path, config, output_dir)
