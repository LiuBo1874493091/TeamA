"""CSV chunks -> temporary disk frames -> bounded, normalized sample shards.

Point arrays are bounded by chunks, the frame cache and a single shard/sample.
Only lightweight window references scale with the number of windows in RAM.
"""
import json
import math
import os
import sqlite3
import tempfile
import uuid
from collections import OrderedDict
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

from .preprocess import infer_round_ids, _windows, _split_rounds


def _binary_labels(series, positive_values):
    # Explicit strings/numeric conversion makes labels independent of chunk size.
    def canonical(v):
        s = str(v).strip().lower()
        try:
            x = float(s)
            if math.isfinite(x):
                return ('number', x)
        except ValueError:
            pass
        return ('text', s)
    pos = {canonical(v) for v in positive_values}
    return series.map(lambda v: int(not pd.isna(v) and canonical(v) in pos)).to_numpy(np.int64)


def positive_int(value, name):
    result = int(value)
    if isinstance(value, bool) or result <= 0 or result != value:
        raise ValueError(f'{name} must be a positive integer.')
    return result


class DiskFrames:
    """A disk index and append-only files keyed by (round, sector)."""
    def __init__(self, root, features, config):
        self.root, self.F, self.cfg = Path(root), len(features), config
        dc = config['data']
        self.chunk = positive_int(dc.get('csv_chunksize', 100000), 'data.csv_chunksize')
        self.budget = int(float(dc.get('prepare_memory_budget_mb', 256)) * 1024**2)
        if self.budget < 1024**2:
            raise ValueError('data.prepare_memory_budget_mb must be >= 1.')
        self.dtype = np.dtype([('xyz', '<f4', (3,)), ('features', '<f4', (self.F,)), ('label', '<i8')])
        self.db = sqlite3.connect(str(self.root / 'frames.sqlite'))
        self.db.execute('PRAGMA cache_size=-8192')
        self.db.execute('CREATE TABLE frames (r INTEGER,s INTEGER,n INTEGER,p INTEGER,PRIMARY KEY(r,s))')
        self.db.execute('CREATE TABLE rounds (r INTEGER PRIMARY KEY)')
        self.cache, self.cache_bytes = OrderedDict(), 0

    def path(self, r, s, selected=False):
        return self.root / f'{int(r)}_{int(s)}.{"selected" if selected else "raw"}'

    def close(self):
        self.cache.clear()
        self.db.close()

    def append(self, r, s, records):
        with open(self.path(r, s), 'ab') as f:
            records.tofile(f)
        p = int((records['label'] == 1).sum())
        self.db.execute('INSERT INTO frames VALUES(?,?,?,?) ON CONFLICT(r,s) DO UPDATE SET n=n+excluded.n,p=p+excluded.p',
                        (int(r), int(s), len(records), p))
        self.db.execute('INSERT OR IGNORE INTO rounds VALUES(?)', (int(r),))

    def ingest(self, csv_path, cols):
        dc = self.cfg['data']
        fc = list(cols.get('features') or [cols['range'], cols['azimuth']])
        encoding = dc.get('csv_encoding', 'utf-8-sig')
        header = pd.read_csv(csv_path, nrows=0, encoding=encoding)
        required = list(dict.fromkeys([cols['range'], cols['azimuth'], cols['label']] + fc))
        for c in required:
            if c not in header.columns:
                raise KeyError(f'Missing CSV column {c!r}')
        rcol, ecol = cols.get('round_id'), cols.get('elevation')
        explicit = bool(rcol and rcol in header.columns)
        for c in (rcol if explicit else None, ecol):
            if c and c in header.columns and c not in required:
                required.append(c)
        sw, scale = float(dc.get('sector_width_deg', 30)), float(dc.get('range_scale', 1000))
        prev_az = last_round = None
        inferred = total = max_chunk = 0
        numeric_features = np.zeros(self.F, dtype=np.int64)
        reader = pd.read_csv(csv_path, chunksize=self.chunk, usecols=required, dtype=str, encoding=encoding)
        with reader:
            for df in tqdm(reader, desc='CSV chunks', unit='chunk'):
                if df.empty:
                    continue
                max_chunk = max(max_chunk, len(df))
                rv = pd.to_numeric(df[cols['range']], errors='coerce').to_numpy(np.float64)
                av = pd.to_numeric(df[cols['azimuth']], errors='coerce').to_numpy(np.float64)
                if not np.isfinite(rv).all() or not np.isfinite(av).all() or (rv < 0).any():
                    raise ValueError(f'Invalid range/azimuth in CSV rows {total + 2}..{total + len(df) + 1}; geometry must be finite and range >= 0.')
                av %= 360.0
                if explicit:
                    ids = pd.to_numeric(df[rcol], errors='raise').to_numpy(np.float64)
                    if not np.isfinite(ids).all() or (ids != np.floor(ids)).any() or (np.abs(ids) >= 2**53).any():
                        raise ValueError('round_id must be finite exact integers with abs(value) < 2**53.')
                    rounds = ids.astype(np.int64)
                else:
                    rounds = infer_round_ids(av, dc.get('wrap_drop_deg', 180))
                    if prev_az is not None and av[0] - prev_az < -abs(float(dc.get('wrap_drop_deg', 180))):
                        inferred += 1
                    rounds += inferred
                    inferred = int(rounds[-1])
                if (np.diff(rounds) < 0).any() or (last_round is not None and rounds[0] < last_round):
                    raise ValueError('CSV must be chronological with nondecreasing round_id; no implicit reordering is performed.')
                prev_az, last_round = av[-1], int(rounds[-1])
                sector = np.floor(av / sw).astype(np.int64)
                rec = np.empty(len(df), dtype=self.dtype)
                rr, az = rv / scale, np.deg2rad(av)
                el = np.zeros(len(df), dtype=np.float64)
                if ecol and ecol in df:
                    el = np.deg2rad(pd.to_numeric(df[ecol], errors='coerce').fillna(0).to_numpy(np.float64))
                    if not np.isfinite(el).all():
                        raise ValueError('Elevation must be finite.')
                rec['xyz'] = np.stack([rr * np.cos(el) * np.cos(az), rr * np.cos(el) * np.sin(az), rr * np.sin(el)], 1)
                for j, c in enumerate(fc):
                    v = av if c == cols['azimuth'] else rv if c == cols['range'] else pd.to_numeric(df[c], errors='coerce').to_numpy(np.float64)
                    numeric_features[j] += np.isfinite(v).sum()
                    with np.errstate(over='ignore'):
                        rec['features'][:, j] = v
                rec['features'][~np.isfinite(rec['features'])] = np.nan
                if not np.isfinite(rec['xyz']).all():
                    raise ValueError('Geometry overflow after float32 conversion.')
                rec['label'] = _binary_labels(df[cols['label']], dc.get('positive_label_values', [1, '1', 'target', 'true']))
                grouping = pd.DataFrame({'r': rounds, 's': sector})
                for (r, s), idx in grouping.groupby(['r', 's'], sort=False).indices.items():
                    self.append(r, s, rec[idx])
                self.db.commit()
                total += len(df)
        if not total:
            raise ValueError('CSV contains no data rows.')
        if (numeric_features == 0).any():
            raise ValueError(f'Feature columns with no finite values: {[fc[j] for j in np.flatnonzero(numeric_features == 0)]}')
        return dict(source_rows=total, max_csv_chunk_rows=max_chunk, csv_chunksize=self.chunk,
                    round_id_source=rcol if explicit else 'inferred_azimuth_wrap')

    def finalize(self, max_points, seed):
        # Target-priority uniform reservoirs: one key per point, independent of
        # CSV chunk boundaries. At most 2*max_points + one read block in RAM.
        if max_points > 0 and 2 * max_points * self.dtype.itemsize > self.budget:
            raise MemoryError('Frame reservoir exceeds prepare_memory_budget_mb. Reduce max_points_per_frame or raise the budget.')
        for r, s, n in tqdm(self.db.execute('SELECT r,s,n FROM frames ORDER BY r,s'), desc='disk frames', unit='frame'):
            selected = self.path(r, s, True)
            if max_points <= 0 or n <= max_points:
                os.replace(self.path(r, s), selected)
                continue
            with open(self.path(r, s), 'rb') as raw:
                rng = np.random.default_rng((int(seed) + int(r) * 1000003 + int(s) * 9176) % (2**63 - 1))
                pools = [(np.empty(0, dtype=self.dtype), np.empty(0), np.empty(0, dtype=np.int64)) for _ in range(2)]
                for start in range(0, n, self.chunk):
                    block = np.fromfile(raw, dtype=self.dtype, count=min(self.chunk, n - start))
                    keys = rng.random(len(block))
                    order = np.arange(start, start + len(block), dtype=np.int64)
                    for cls in (0, 1):
                        mask = block['label'] == cls
                        records, scores, ids = pools[cls]
                        records = np.concatenate([records, block[mask]])
                        scores = np.concatenate([scores, keys[mask]])
                        ids = np.concatenate([ids, order[mask]])
                        if len(scores) > max_points:
                            ii = np.argpartition(scores, max_points - 1)[:max_points]
                            records, scores, ids = records[ii], scores[ii], ids[ii]
                        pools[cls] = records, scores, ids
                pos, _, pi = pools[1]
                neg, nk, ni = pools[0]
                need = max_points - len(pos)
                if need < len(neg):
                    ii = np.argsort(nk)[:need]
                    neg, ni = neg[ii], ni[ii]
                data = np.concatenate([pos, neg])
                data = data[np.argsort(np.concatenate([pi, ni]))]
                with open(selected, 'wb') as f:
                    data.tofile(f)
            self.path(r, s).unlink()

    def counts(self, rounds, sector):
        n = p = 0
        for r in rounds:
            row = self.db.execute('SELECT n,p FROM frames WHERE r=? AND s=?', (int(r), int(sector))).fetchone()
            if row:
                n += row[0]
                p += row[1]
        return n, p

    def get(self, r, sector):
        key = int(r), int(sector)
        if key in self.cache:
            self.cache.move_to_end(key)
            return self.cache[key]
        path = self.path(*key, selected=True)
        size = path.stat().st_size if path.exists() else 0
        if size > self.budget:
            raise MemoryError('One frame exceeds prepare_memory_budget_mb. Set max_points_per_frame > 0 or raise the budget.')
        if not size:
            return np.empty(0, dtype=self.dtype)
        while self.cache and (self.cache_bytes + size > self.budget or len(self.cache) >= 1024):
            _, old = self.cache.popitem(last=False)
            self.cache_bytes -= old.nbytes
        a = np.fromfile(path, dtype=self.dtype) if size else np.empty(0, dtype=self.dtype)
        self.cache[key], self.cache_bytes = a, self.cache_bytes + a.nbytes
        return a

    def sample(self, ref):
        rounds, sector = ref
        out = dict(xyz=[], features=[], labels=[], rounds=np.asarray(rounds, np.int64), sector=int(sector))
        total = 0
        for r in rounds:
            a = self.get(r, sector)
            total += a.nbytes
            if total > self.budget:
                raise MemoryError('One sample exceeds prepare_memory_budget_mb. Reduce max_points_per_frame or raise the budget.')
            out['xyz'].append(a['xyz'].copy())
            out['features'].append(a['features'].copy())
            out['labels'].append(a['label'].copy())
        return out


class StreamingBalance:
    """Exact global clutter quota, uniformly selected without storing positions."""
    def __init__(self, positive, negative, seed, enabled):
        self.remaining, self.keep = int(negative), min(int(positive), int(negative))
        self.enabled = enabled and positive > 0 and negative > 0
        self.rng = np.random.default_rng(seed)

    def apply(self, sample):
        if not self.enabled:
            return sample
        for ti, y in enumerate(sample['labels']):
            neg = np.flatnonzero(y == 0)
            n = len(neg)
            if n and max(self.keep, self.remaining - self.keep) >= 10**9:
                # NumPy's hypergeometric sampler bounds its population parameters.
                # Conditional Bernoulli draws also give exact uniform selection.
                selected = []
                for j in neg:
                    take = self.rng.random() < self.keep / self.remaining
                    self.remaining -= 1
                    self.keep -= int(take)
                    if take:
                        selected.append(j)
                mask = y == 1
                mask[selected] = True
                for field in ('xyz', 'features', 'labels'):
                    sample[field][ti] = sample[field][ti][mask]
                continue
            k = int(self.rng.hypergeometric(self.keep, self.remaining - self.keep, n)) if n else 0
            self.remaining -= n
            self.keep -= k
            mask = y == 1
            if k:
                mask[self.rng.choice(neg, k, replace=False)] = True
            for field in ('xyz', 'features', 'labels'):
                sample[field][ti] = sample[field][ti][mask]
        return sample


class OnlineScaler:
    """Float64 Chan/Welford moments, with training-mean missing value fill."""
    def __init__(self, features):
        self.count = np.zeros(features, dtype=np.int64)
        self.mean, self.m2 = np.zeros(features, np.float64), np.zeros(features, np.float64)
        self.total = 0

    def update(self, features):
        self.total += len(features)
        for j in range(features.shape[1]):
            v = features[:, j].astype(np.float64)
            v = v[np.isfinite(v)]
            n = len(v)
            if not n:
                continue
            mean = v.mean()
            delta, total = mean - self.mean[j], self.count[j] + n
            self.m2[j] += np.square(v - mean).sum() + delta**2 * self.count[j] * n / total
            self.mean[j] += delta * n / total
            self.count[j] = total

    def finish(self):
        if not self.total or (self.count == 0).any():
            raise ValueError('No finite training values for one or more features; cannot fit train-only scaler.')
        std = np.sqrt(np.maximum(self.m2 / self.total, 0))
        std[std < 1e-6] = 1.0
        mean, std = self.mean.astype(np.float32), std.astype(np.float32)
        if not np.isfinite(mean).all() or not np.isfinite(std).all():
            raise ValueError('Non-finite feature scaler.')
        return mean, std


def atomic_torch_save(payload, path):
    temp = path.with_suffix('.tmp')
    torch.save(payload, temp)
    os.replace(temp, path)


class ShardWriter:
    def __init__(self, root, max_samples, max_points):
        self.root, self.max_samples, self.max_points = root, max_samples, max_points
        self.pending, self.points, self.shards = [], 0, []

    def flush(self):
        if self.pending:
            name = f'{len(self.shards):06d}.pt'
            atomic_torch_save({'samples': self.pending}, self.root / name)
            self.shards.append(dict(path=name, samples=len(self.pending), points=self.points))
            self.pending, self.points = [], 0

    def add(self, sample):
        n = sum(len(y) for y in sample['labels'])
        if self.pending and (len(self.pending) >= self.max_samples or self.points + n > self.max_points):
            self.flush()
        stored = {field: [torch.from_numpy(a) for a in sample[field]] for field in ('xyz', 'features', 'labels')}
        stored.update(rounds=torch.from_numpy(sample['rounds']), sector=sample['sector'])
        self.pending.append(stored)
        self.points += n
        if self.points >= self.max_points:
            self.flush()


def prepare_data_streaming(csv_path, config, output_dir):
    cols, dc, sc = config['columns'], config['data'], config['split']
    seed = int(config.get('train', {}).get('seed', 42))
    fc = list(cols.get('features') or [cols['range'], cols['azimuth']])
    if not fc or len(set(fc)) != len(fc) or cols['label'] in fc:
        raise ValueError('Feature columns must be unique, nonempty and exclude the label column.')
    length = positive_int(dc.get('sequence_length', 3), 'data.sequence_length')
    stride = positive_int(dc.get('sequence_stride', 1), 'data.sequence_stride')
    sw = float(dc.get('sector_width_deg', 30))
    if not math.isfinite(sw) or sw <= 0 or abs(round(360 / sw) * sw - 360) > 1e-5:
        raise ValueError('sector_width_deg must divide 360 exactly.')
    scale = float(dc.get('range_scale', 1000))
    if not math.isfinite(scale) or scale <= 0:
        raise ValueError('range_scale must be finite and > 0.')
    tr, vr = float(sc.get('train_ratio', .7)), float(sc.get('val_ratio', .15))
    if not (0 < tr < 1 and 0 <= vr < 1 and tr + vr < 1):
        raise ValueError('Require 0 < train_ratio < 1, val_ratio >= 0 and train_ratio + val_ratio < 1.')
    requested_mode = str(sc.get('mode', 'round_isolated')).lower()
    if requested_mode not in ('auto', 'sample', 'round_isolated'):
        raise ValueError('split.mode must be auto, sample or round_isolated.')
    # Legacy configs must never silently re-enable overlapping sample splits.
    mode = 'round_isolated'
    if requested_mode == 'sample':
        print('[split] Legacy sample mode now uses chronological round_isolated splitting; '
              'random assignment of overlapping windows has been removed.', flush=True)
    maxp = int(dc.get('max_points_per_frame', 256) or 0)
    if maxp < 0:
        raise ValueError('max_points_per_frame must be >= 0.')
    shard_samples = positive_int(dc.get('processed_shard_samples', 128), 'data.processed_shard_samples')
    shard_points = positive_int(dc.get('processed_shard_points', 200000), 'data.processed_shard_points')
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    temp_root = dc.get('prepare_temp_dir') or None
    if temp_root:
        Path(temp_root).mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='radar_prepare_', dir=temp_root) as tmp:
        store = DiskFrames(tmp, fc, config)
        try:
            print('[1/6] Chunked CSV -> temporary disk frames', flush=True)
            input_meta = store.ingest(csv_path, cols)
            print('[2/6] Select frame points (target priority, chunk-independent)', flush=True)
            store.finalize(maxp, seed)
            rounds = np.asarray([r[0] for r in store.db.execute('SELECT r FROM rounds ORDER BY r')], np.int64)
            removed = 0

            def build_refs(subset):
                nonlocal removed
                refs = []
                for w in _windows(subset, length, stride, bool(dc.get('require_consecutive_round_ids', True))):
                    for sector in range(int(round(360 / sw))):
                        n, p = store.counts(w, sector)
                        if not n:
                            continue
                        if dc.get('drop_all_clutter_windows', True) and not p:
                            removed += 1
                            continue
                        refs.append((w, sector))
                return refs

            print(f'[3/6] Build references and split: {mode}', flush=True)
            partitions = _split_rounds(rounds, tr, vr, min_rounds=length)
            refs = {name: build_refs(rr) for name, rr in partitions.items()}
            for name in ('train', 'test') + (('val',) if vr > 0 else ()):
                if not refs[name]:
                    raise RuntimeError(f'{name} has no samples after filtering; check circle count, sequence_length and split ratios.')
            totals = {}
            for name, split_refs in refs.items():
                p = n = 0
                for ref in split_refs:
                    for r in ref[0]:
                        labels = store.get(r, ref[1])['label']
                        p += int((labels == 1).sum())
                        n += int((labels == 0).sum())
                totals[name] = p, n
            offsets = dict(train=101, val=211, test=307)

            def balanced_samples(name):
                p, n = totals[name]
                balancer = StreamingBalance(p, n, seed + offsets[name], name != 'test' or bool(sc.get('sample_test_clutter', False)))
                for ref in refs[name]:
                    yield balancer.apply(store.sample(ref))

            print('[4/6] Streaming train-only scaler pass after clutter undersampling', flush=True)
            moments = OnlineScaler(len(fc))
            for s in tqdm(balanced_samples('train'), total=len(refs['train']), desc='fit scaler'):
                for f in s['features']:
                    moments.update(f)
            mean, std = moments.finish()
            meta = dict(input_meta, split_mode=mode, requested_split_mode=requested_mode,
                        split_policy='chronological_round_isolated_v1',
                        sequence_length=length, sequence_stride=stride,
                        sector_width_deg=sw, max_points_per_frame=maxp, pure_clutter_removed=removed,
                        source_csv=str(csv_path), cache_format='radar_sharded_v2',
                        scaler_fit='train_points_after_clutter_undersampling', missing_feature_fill='train_mean',
                        prepare_memory_budget_mb=store.budget / 1024**2)
            meta['round_partitions'] = {k: [int(r) for r in v] for k, v in partitions.items()}
            print('[5/6] Reproducible balance pass -> normalized sample shards', flush=True)
            stats, manifests = {}, {}
            generation = uuid.uuid4().hex[:12]
            point_limit = min(shard_points, max(1, store.budget // store.dtype.itemsize))
            for name in ('train', 'val', 'test'):
                root = out / 'shards' / f'{name}_{generation}'
                if refs[name]:
                    root.mkdir(parents=True)
                writer = ShardWriter(root, shard_samples, point_limit)
                p = n = 0
                for s in tqdm(balanced_samples(name), total=len(refs[name]), desc=f'write {name}'):
                    for ti, (f, y) in enumerate(zip(s['features'], s['labels'])):
                        clean = np.where(np.isfinite(f), f, mean)
                        s['features'][ti] = ((clean.astype(np.float64) - mean) / std).astype(np.float32)
                        if not np.isfinite(s['features'][ti]).all():
                            raise ValueError('Feature overflow during standardization.')
                        p += int((y == 1).sum())
                        n += int((y == 0).sum())
                    writer.add(s)
                writer.flush()
                stats[name] = dict(samples=len(refs[name]), target_points=p, clutter_points=n,
                                   valid_points=p + n, target_ratio=p / (p + n) if p + n else 0.)
                for entry in writer.shards:
                    entry['path'] = (root.relative_to(out) / entry['path']).as_posix()
                manifests[name] = dict(format_version=2, shards=writer.shards, feature_cols=fc,
                                       feature_mean=mean, feature_std=std, stats=stats[name], meta=meta)
            print('[6/6] Publish split manifests and scaler', flush=True)
            for name in ('train', 'val', 'test'):
                if name == 'val' and not refs[name]:
                    (out / 'val.pt').unlink(missing_ok=True)
                else:
                    atomic_torch_save(manifests[name], out / f'{name}.pt')
            np.savez(out / 'scaler.npz', feature_mean=mean, feature_std=std, feature_cols=np.asarray(fc, dtype=str))
            summary = dict(meta=meta, stats=stats)
            for filename, value in (('split_summary.json', summary), ('resolved_config.json', config)):
                with open(out / filename, 'w', encoding='utf-8') as f:
                    json.dump(value, f, ensure_ascii=False, indent=2)
            print(json.dumps(stats, ensure_ascii=False, indent=2), flush=True)
            return summary
        finally:
            store.close()
