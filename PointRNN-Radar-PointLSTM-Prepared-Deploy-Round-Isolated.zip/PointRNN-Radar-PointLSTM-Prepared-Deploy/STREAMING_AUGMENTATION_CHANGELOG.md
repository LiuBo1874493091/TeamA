# 2026-10-30 后续更新：全部集合统一按圈次隔离

无论 train/val/test 还是 train/test，都先按时间划分原始圈次，再在各自圈段内部生成滑窗。已移除随机窗口划分代码；auto 及旧 sample 配置均按 round_isolated 处理。训练/验证/测试入口拒绝旧 sample 或缺少划分来源的缓存，并提示重新准备完整缓存/scaler。

本次未进行构建、smoke test、训练、测试或部署。详细规则及迁移步骤见 [ROUND_ISOLATED_SPLIT_UPDATE.md](ROUND_ISOLATED_SPLIT_UPDATE.md)。

以下为 2026-10-29 历史说明；其中曾经保留的 sample 划分策略已被本次更新取代。

# 2026-10-29 变更说明

## 来源与交付状态

基于用户指定的 `PointRNN-Radar-PointLSTM-Prepared-Deploy.zip` 进行修改，原 ZIP 未改动。

**按用户在本次工作期间的最新要求，不进行构建、测试、smoke test、训练、模型推理或部署运行。此交付仅完成源码修改、静态人工核对、文档更新和压缩打包，未经运行验证。** 历史文档中的已验证记录描述的是此前版本，不适用于本次改动。

## 主要文件

| 文件 | 变更 |
| --- | --- |
| `data_prepare.py` | 命令接口保持不变，通过 preprocess 进入新流式处理器 |
| `radar/preprocess.py` | 保留划分/滑窗辅助函数；移除整表预处理与全局样本物化逻辑 |
| `radar/streaming_prepare.py` | CSV chunks、磁盘帧暂存、SQLite 索引、目标优先限点、流式全局杂波下采样、train-only scaler、分片输出 |
| `radar/dataset.py` | 新版分片 LRU 按需加载，同时兼容旧版 `samples` 单文件缓存；Windows worker 启动不复制已加载分片 |
| `radar/augmentation.py` | 两类独立增强，统一样本角度及 IQ 四列白名单；不改变标签、点数或顺序 |
| `radar/runtime.py` | 显式 CUDA 矩阵预热/模型前向预热，CPU 跳过 |
| `radar_train.py` / `radar_test.py` | 保留已有训练/测试行为，接入显式预热；新缓存由 Dataset 自动读取 |
| `radar_deploy_sim.py` | 保留部署逻辑，补充显式预热、有限值检查及方位特征与 xyz 的 wrap 一致性 |
| `radar_predict.py` | 修复原工程对已移除 `RadarSequenceDataset` 的导入，改为从 processed 导出概率，任何 split 都不增强 |
| `radar_config.json` | 改为指定中文列；新增 CSV/磁盘缓存参数、两类增强参数和预热开关 |
| `README.md` | 更新完整流程、配置、缓存迁移与内存边界说明 |

## 行为与兼容性

- 保留按时间、round_id、扇区、sequence_length/stride/consecutive 构造样本的逻辑；拒绝圈次回退，避免排序掩盖异常输入。
- 仍在限点之前判定全杂波窗口，在划分之后执行点级下采样；train/val 精确保留不超过目标数量的杂波，test 开关保持原语义。
- 新的随机优先级蓄水池及分帧超几何分配保持随机均匀选择和目标优先规则，随机抽样结果可能与旧算法不同。同一输入/config/seed 下不依赖 CSV chunk 边界。
- scaler 只统计最终 train 点，缺失特征用 train 均值填充；从全表中位数改为训练均值是有意变更。均值/方差采用 float64 增量算法，近常量列 std=1。
- 新版 train.pt/val.pt/test.pt 是分片索引。训练/测试脚本入口不变，旧版缓存仍可读取；新版缓存必须携带整个 shards 目录。分片和窗口引用并非全部点数据常驻内存。
- `sample` 模式仍可能共享原始圈，严格隔离使用 `round_isolated`；无 val 的 auto 模式默认圈隔离。
- 本次没有自动生成任何 processed 数据、训练权重、曲线或预测 CSV；也没有声称已有这些运行结果。
- 原部署模拟仍有全表回写内存开销；本次 streaming 范围是数据准备。
- 原本 `radar_predict.py --csv ...` 路径在所提供版本中引用不存在的 Dataset；现在使用 `--data processed`，逐窗口概率输出与逐原始行部署输出分开。

## 静态核对范围

人工阅读了 CSV chunk 跨界圈次状态、扇区/窗口引用、划分边界、train-only scaler 数据来源、杂波全局配额、训练增强入口和 val/test/deploy 关闭路径；检查了新模块导入关系、缓存相对路径及打包文件清单。未执行语法编译或任何自动化验证，运行时正确性仍需用户后续验证。
