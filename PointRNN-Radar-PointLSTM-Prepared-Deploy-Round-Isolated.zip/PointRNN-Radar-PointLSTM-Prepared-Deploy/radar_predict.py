"""Export per-window point probabilities from prepared caches (no augmentation)."""
import argparse
import csv
from pathlib import Path

import torch
from torch.utils.data import DataLoader

from radar.dataset import ProcessedRadarDataset, radar_collate_fn, load_config, load_processed_split
from radar.model import RadarPointLSTMClassifier
from radar.runtime import cuda_warmup, model_warmup
from radar.validation import validate_model_batch, validate_logits


def main():
    ap = argparse.ArgumentParser(description='Export point probabilities from processed train/val/test caches.')
    ap.add_argument('--data', default='processed')
    ap.add_argument('--config', default='radar_config.json')
    ap.add_argument('--checkpoint', required=True)
    ap.add_argument('--output', default='radar_predictions.csv')
    ap.add_argument('--split', default='test', choices=['train', 'val', 'test', 'all'])
    args = ap.parse_args()
    cfg = load_config(args.config)
    names = ('train', 'val', 'test') if args.split == 'all' else (args.split,)
    paths = [Path(args.data) / f'{name}.pt' for name in names]
    if args.split == 'all':
        paths = [p for p in paths if p.is_file()]
    if not paths:
        raise FileNotFoundError('No prepared caches found. Run data_prepare.py first.')
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    cuda_warmup(device, cfg.get('train', {}).get('cuda_warmup', True))
    ck = load_processed_split(args.checkpoint)
    model = None
    warmed = False
    count = 0
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        writer.writerow(['round_id', 'sector_id', 'sequence_t', 'point_index_in_frame',
                         'target_probability', 'pred_label', 'gt_label'])
        for path in paths:
            # Even --split train uses inference mode, so labels/geometry stay fixed.
            ds = ProcessedRadarDataset(path, cfg, split='predict')
            if list(ck.get('feature_cols', ds.feature_cols)) != ds.feature_cols:
                raise ValueError('Checkpoint features differ from prepared cache features.')
            if model is None:
                model = RadarPointLSTMClassifier(len(ds.feature_cols),
                    hidden_dims=tuple(cfg['model']['hidden_dims']), radius=tuple(cfg['model']['radius']),
                    nsamples=tuple(cfg['model']['nsamples']), dropout=cfg['model'].get('dropout', .1),
                    knn_query_chunk_size=cfg['model'].get('knn_query_chunk_size', 128)).to(device)
                model.load_state_dict(ck['model'])
                model.eval()
            loader = DataLoader(ds, batch_size=cfg['train'].get('batch_size', 1), shuffle=False,
                                num_workers=0, collate_fn=radar_collate_fn)
            with torch.no_grad():
                for batch in loader:
                    if not warmed:
                        model_warmup(model, batch, device, cfg.get('train', {}).get('model_warmup', True))
                        warmed = True
                    xyz, feat, mask = (batch[k].to(device) for k in ('xyz', 'features', 'mask'))
                    labels = batch['labels'].to(device)
                    validate_model_batch(xyz, feat, mask, labels, model.feature_dim, stage='predict')
                    logits = model(xyz, feat, mask)
                    validate_logits(logits, labels, mask)
                    prob, pred = logits.softmax(-1)[..., 1].cpu(), logits.argmax(-1).cpu()
                    for b in range(prob.size(0)):
                        for t in range(prob.size(1)):
                            for j in torch.where(batch['mask'][b, t])[0].tolist():
                                writer.writerow([int(batch['rounds'][b, t]), int(batch['sector'][b]), t, j,
                                                 float(prob[b, t, j]), int(pred[b, t, j]), int(batch['labels'][b, t, j])])
                                count += 1
    print(f'Wrote {count} point predictions to {out}')


if __name__ == '__main__':
    main()
