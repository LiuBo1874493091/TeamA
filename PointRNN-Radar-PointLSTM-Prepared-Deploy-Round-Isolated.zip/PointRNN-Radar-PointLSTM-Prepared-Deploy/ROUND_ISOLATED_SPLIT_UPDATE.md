# 2026-10-30：训练、验证、测试统一圈次隔离

## 新规则

不再先生成全部重叠窗口再随机分配。无论需要 train/val/test 还是只需要 train/test，都按以下步骤处理：

1. 按时间排列的唯一原始圈次，依 train_ratio、val_ratio 分成互不重叠的连续圈段。
2. 每段内部独立按 sequence_length、sequence_stride 和 sector 构建窗口；不生成跨段窗口。
3. 各段内继续执行原有全杂波过滤、限点及杂波下采样；scaler 仍只统计最终 train 点。

例如 100 圈、train_ratio=0.7、val_ratio=0.15、sequence_length=3：train 仅用 1～70 圈，val 仅用 71～85 圈，test 仅用 86～100 圈。不存在 [69,70,71]、[84,85,86] 这样的跨集合窗口。

比例按原始圈次数量计算，train/val 数量向下取整，test 接收剩余圈次。每个启用集合至少需要 sequence_length 圈；若不足或过滤后没有样本，明确报错，不借圈或回退到随机划分。过滤和滑窗之后的点数/样本数比例不保证等于原始圈次比例。

## 配置与兼容

默认 split.mode 已改为 round_isolated；auto 始终采用该规则。旧 sample 配置也迁移到圈隔离并打印提示；随机分配窗口的实现已移除。shuffle_samples 不再参与划分，默认配置已移除这个字段。训练时在 train 集内部 shuffle batch 继续保留。

split_summary.json 与每套缓存元数据保存 round_partitions、split_mode=round_isolated，并新增 split_policy=chronological_round_isolated_v1 和 requested_split_mode。

## 旧缓存迁移

只修改配置不能改变旧 train.pt/val.pt/test.pt 中已经分配好的窗口。

旧 sample 缓存或缺少 split_mode 元数据的缓存，在训练/验证/测试读取时会明确报错。请之后手动重新运行 data_prepare.py，重新生成完整的三个集合、shards 及 scaler，然后用新缓存重新训练。旧 round_isolated 缓存仍兼容，前提是字段及模型配置匹配。predict 导出旧缓存仍可用于历史结果查看，不代表旧划分满足新评估要求。

以下是供用户后续执行的命令，本次未执行：

```powershell
python data_prepare.py --csv ./data/data.csv --config radar_config.json --output processed_round_isolated
```

建议使用新输出目录，保留上一版缓存。训练与测试时将 --data 指向 processed_round_isolated；部署时将 --processed 指向该目录以使用新 scaler，checkpoint 使用基于新缓存重新训练的权重。

## 修改文件

- radar/preprocess.py：移除 _split_samples；圈段长度不足时给出明确错误。
- radar/streaming_prepare.py：统一模式解析，始终先切圈再构造窗口，记录划分来源。
- radar/dataset.py：训练/验证/测试入口拒绝旧随机划分及来源不明的缓存。
- radar_config.json：默认 round_isolated，移除 shuffle_samples。
- README 及变更文档：更新划分规则、示例和缓存迁移说明。

## 验证状态

按用户明确要求，**不进行构建、smoke test、训练、测试或部署**。本次仅修改源码、人工静态核对、更新文档和打包 ZIP；未生成新数据缓存、模型权重或预测结果，未经运行验证。
