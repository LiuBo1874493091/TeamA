> 历史版本说明：本次流式缓存、增强配置及验证状态以 [README.md](README.md) 和 [STREAMING_AUGMENTATION_CHANGELOG.md](STREAMING_AUGMENTATION_CHANGELOG.md) 为准。本文原有运行验证记录不代表此次修改已通过测试。

# Radar PointLSTM：当前推荐流程

详细说明见 `PIPELINE_REFACTOR.md`。

## 1. 一次性数据处理
```bash
python data_prepare.py --csv ./data/data.csv --config radar_config.json --output processed
```

## 2. 训练
```bash
python radar_train.py --data processed --config radar_config.json --output outputs/exp1
```

## 3. 测试
有验证集时优先：
```bash
python radar_test.py --data processed --config radar_config.json --checkpoint outputs/exp1/best.pth
```
无验证集时：
```bash
python radar_test.py --data processed --config radar_config.json --checkpoint outputs/exp1/last.pth
```

## 4. 模拟实际部署
```bash
python radar_deploy_sim.py --csv ./data/data.csv --config radar_config.json --processed processed --checkpoint outputs/exp1/best.pth --output deploy_prediction.csv
```

## split.mode
- `auto`：`val_ratio>0` 使用样本级 split；`val_ratio=0` 自动使用圈隔离。
- `sample`：生成全部滑窗后按样本划分。
- `round_isolated`：先隔离圈次，再各自生成滑窗，避免原始圈泄漏。

部署脚本不读取原始 label 来做决策，不做杂波下采样或数据增强。
