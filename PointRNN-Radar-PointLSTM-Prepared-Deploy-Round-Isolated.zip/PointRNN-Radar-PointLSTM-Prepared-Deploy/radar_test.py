import argparse
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm
from radar.dataset import ProcessedRadarDataset,radar_collate_fn,load_config,processed_paths
from radar.model import RadarPointLSTMClassifier
from radar.metrics import BinaryMetrics
from radar.runtime import cuda_warmup, model_warmup
from radar.validation import validate_model_batch,validate_logits

def load_ck(path,device):
    try:return torch.load(path,map_location=device,weights_only=False)
    except TypeError:return torch.load(path,map_location=device)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--data',default='processed');ap.add_argument('--config',default='radar_config.json');ap.add_argument('--checkpoint',required=True);args=ap.parse_args()
    cfg=load_config(args.config);p=processed_paths(args.data)['test']
    if not p.exists():raise FileNotFoundError(f'{p} not found. Run data_prepare.py first.')
    ds=ProcessedRadarDataset(p,cfg,'test');loader=DataLoader(ds,batch_size=cfg['train'].get('batch_size',1),shuffle=False,num_workers=cfg['train'].get('workers',0),collate_fn=radar_collate_fn,pin_memory=torch.cuda.is_available())
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu');ck=load_ck(args.checkpoint,device)
    cuda_warmup(device, cfg['train'].get('cuda_warmup', True))
    model=RadarPointLSTMClassifier(len(ds.feature_cols),hidden_dims=tuple(cfg['model']['hidden_dims']),radius=tuple(cfg['model']['radius']),nsamples=tuple(cfg['model']['nsamples']),dropout=cfg['model'].get('dropout',0.1),knn_query_chunk_size=cfg['model'].get('knn_query_chunk_size',128)).to(device);model.load_state_dict(ck['model']);model.eval()
    model_warmup(model, radar_collate_fn([ds[0]]), device, cfg['train'].get('model_warmup', True))
    weights=cfg['train'].get('class_weights');cw=torch.tensor(weights,dtype=torch.float32,device=device) if weights else None;crit=nn.CrossEntropyLoss(weight=cw,ignore_index=-100);m=BinaryMetrics();loss=0.;nb=0
    with torch.no_grad():
        for b in tqdm(loader,desc='test',unit='batch'):
            xyz=b['xyz'].to(device);feat=b['features'].to(device);lab=b['labels'].to(device);mask=b['mask'].to(device);validate_model_batch(xyz,feat,mask,labels=lab,feature_dim=model.feature_dim,stage='test');logits=model(xyz,feat,mask);validate_logits(logits,lab,mask);loss+=float(crit(logits.reshape(-1,2),lab.reshape(-1)).item());nb+=1;m.update(logits,lab,mask)
    r=m.compute();print('\n===== TEST RESULT =====');print(f'samples   : {len(ds)}');print(f'target pts: {ds.stats.get("target_points",0)}');print(f'clutter pts: {ds.stats.get("clutter_points",0)}');print(f'loss      : {loss/max(nb,1):.6f}');print(f'accuracy  : {r["accuracy"]:.6f}');print(f'precision : {r["precision"]:.6f}');print(f'recall(point, positive class): {r["recall"]:.6f}');print(f'f1        : {r["f1"]:.6f}');print(f'TP/FP/TN/FN: {r["tp"]}/{r["fp"]}/{r["tn"]}/{r["fn"]}')
if __name__=='__main__':main()
