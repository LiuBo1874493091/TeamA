import json
from bisect import bisect_right
from collections import OrderedDict
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import Dataset

from .augmentation import RadarAugmenter


def load_config(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def load_processed_split(path):
    try:
        return torch.load(path, map_location='cpu', weights_only=False)
    except TypeError:
        return torch.load(path, map_location='cpu')


class ProcessedRadarDataset(Dataset):
    """Dataset backed by data_prepare.py output.

    Each stored sample contains variable-length frames before padding:
      xyz:      list[L] of FloatTensor[Ti,3]
      features: list[L] of FloatTensor[Ti,F]
      labels:   list[L] of LongTensor[Ti]
    Training-only online augmentation is optionally applied in __getitem__.
    """
    def __init__(self, split_file, config, split='train'):
        self.split_file = str(split_file)
        self.cfg = config
        self.split = split
        payload = load_processed_split(split_file)
        self.samples = payload.get('samples')
        self.shards = payload.get('shards', [])
        self.shard_ends = np.cumsum([int(s['samples']) for s in self.shards]).tolist()
        self.shard_cache = OrderedDict()
        self.shard_cache_size = int(config.get('data', {}).get('processed_cache_shards', 1))
        if self.shard_cache_size < 0:
            raise ValueError('data.processed_cache_shards must be >= 0.')
        self.feature_cols = list(payload['feature_cols'])
        self.feature_mean = np.asarray(payload['feature_mean'], dtype=np.float32)
        self.feature_std = np.asarray(payload['feature_std'], dtype=np.float32)
        self.stats = dict(payload.get('stats', {}))
        self.meta = dict(payload.get('meta', {}))
        if self.meta.get('scaler_fitted') is False:
            raise RuntimeError(
                f'{split_file}: preprocessing returned no training samples, so no scaler was fitted. '
                'Add sufficient training rounds and rerun data_prepare.py before training or evaluation.'
            )
        if split in ('train', 'val', 'test') and self.meta.get('split_mode') != 'round_isolated':
            raise ValueError(
                f'{split_file}: this cache was not prepared with round_isolated splitting '
                f'(recorded mode={self.meta.get("split_mode")!r}). '
                'Rerun data_prepare.py with the new config to regenerate the complete '
                'train/val/test caches and train-only scaler before training or evaluation.'
            )
        configured_features = list(config.get('columns', {}).get('features') or self.feature_cols)
        if configured_features != self.feature_cols:
            raise ValueError(f'Configured features {configured_features} differ from cached features {self.feature_cols}. Use a matching config or prepare data again.')
        if payload.get('format_version', 1) not in (1, 2):
            raise ValueError('Unsupported processed cache format.')
        if self.samples is None:
            for shard in self.shards:
                path = (Path(split_file).parent / shard['path']).resolve()
                if Path(split_file).parent.resolve() not in path.parents:
                    raise ValueError('Shard path must stay inside processed directory.')
                if not path.is_file():
                    raise FileNotFoundError(f'Missing cache shard: {path}. Copy the entire processed folder including shards/.')
        self.augmenter = (
            RadarAugmenter(config, self.feature_cols, self.feature_mean, self.feature_std)
            if split == 'train' else None
        )
        if len(self) == 0:
            raise RuntimeError(f'Processed split is empty: {split_file}')

    def __len__(self):
        return len(self.samples) if self.samples is not None else (self.shard_ends[-1] if self.shard_ends else 0)

    def _stored_sample(self, idx):
        if idx < 0:
            idx += len(self)
        if not 0 <= idx < len(self):
            raise IndexError(idx)
        if self.samples is not None:
            return self.samples[idx]
        si = bisect_right(self.shard_ends, idx)
        if si in self.shard_cache:
            samples = self.shard_cache[si]
            self.shard_cache.move_to_end(si)
        else:
            samples = load_processed_split(Path(self.split_file).parent / self.shards[si]['path'])['samples']
            if len(samples) != int(self.shards[si]['samples']):
                raise ValueError('Cache shard sample count mismatch.')
            if self.shard_cache_size:
                self.shard_cache[si] = samples
                while len(self.shard_cache) > self.shard_cache_size:
                    self.shard_cache.popitem(last=False)
        return samples[idx - (self.shard_ends[si - 1] if si else 0)]

    def __getstate__(self):
        state = self.__dict__.copy()
        state['shard_cache'] = OrderedDict()
        return state

    def __getitem__(self, idx):
        s = self._stored_sample(idx)
        xyz_seq = [x.detach().cpu().numpy().astype(np.float32, copy=True) for x in s['xyz']]
        feat_seq = [x.detach().cpu().numpy().astype(np.float32, copy=True) for x in s['features']]
        lab_seq = [x.detach().cpu().numpy().astype(np.int64, copy=True) for x in s['labels']]
        if self.augmenter is not None and self.augmenter.enabled:
            xyz_seq, feat_seq, lab_seq = self.augmenter(
                xyz_seq, feat_seq, lab_seq, int(s['sector']), int(idx)
            )
        return {
            'xyz': xyz_seq,
            'features': feat_seq,
            'labels': lab_seq,
            'rounds': np.asarray(s['rounds'], dtype=np.int64),
            'sector': int(s['sector']),
        }


def radar_collate_fn(batch):
    if not batch:
        raise ValueError('radar_collate_fn received an empty batch.')
    B = len(batch)
    L = len(batch[0]['xyz'])
    if L <= 0 or any(len(b['xyz']) != L for b in batch):
        raise ValueError('All samples must have the same non-zero sequence length.')

    F = None
    T = 0
    for bi, item in enumerate(batch):
        if not (len(item['xyz']) == len(item['features']) == len(item['labels']) == L):
            raise ValueError(f'sample {bi}: sequence field length mismatch')
        for ti, (x, f, y) in enumerate(zip(item['xyz'], item['features'], item['labels'])):
            x = np.asarray(x); f = np.asarray(f); y = np.asarray(y)
            if x.ndim != 2 or x.shape[1] != 3:
                raise ValueError(f'sample={bi}, frame={ti}: xyz must be [n,3], got {x.shape}')
            if f.ndim != 2 or y.ndim != 1 or not (len(x) == len(f) == len(y)):
                raise ValueError(f'sample={bi}, frame={ti}: point count/shape mismatch')
            if F is None: F = f.shape[1]
            elif F != f.shape[1]: raise ValueError('Feature dimension mismatch in batch.')
            if x.size and not np.isfinite(x).all(): raise ValueError('NaN/Inf in xyz.')
            if f.size and not np.isfinite(f).all(): raise ValueError('NaN/Inf in features.')
            if y.size and np.any((y != 0) & (y != 1)): raise ValueError('Labels must be 0/1.')
            T = max(T, len(x))
    if T <= 0 or F is None or F <= 0:
        raise ValueError('Batch has no valid radar points/features.')

    xyz = torch.zeros(B, L, T, 3, dtype=torch.float32)
    features = torch.zeros(B, L, T, F, dtype=torch.float32)
    labels = torch.full((B, L, T), -100, dtype=torch.long)
    mask = torch.zeros(B, L, T, dtype=torch.bool)
    rounds = torch.stack([torch.as_tensor(b['rounds'], dtype=torch.long) for b in batch])
    sectors = torch.as_tensor([b['sector'] for b in batch], dtype=torch.long)

    for b, item in enumerate(batch):
        for t in range(L):
            n = len(item['xyz'][t])
            if n == 0: continue
            xyz[b,t,:n] = torch.as_tensor(item['xyz'][t], dtype=torch.float32)
            features[b,t,:n] = torch.as_tensor(item['features'][t], dtype=torch.float32)
            labels[b,t,:n] = torch.as_tensor(item['labels'][t], dtype=torch.long)
            mask[b,t,:n] = True
    if not mask.any(): raise ValueError('Entire batch is padding.')
    return {'xyz':xyz, 'features':features, 'labels':labels, 'mask':mask,
            'rounds':rounds, 'sector':sectors}


def processed_paths(processed_dir):
    p = Path(processed_dir)
    return {name: p / f'{name}.pt' for name in ('train','val','test')}
