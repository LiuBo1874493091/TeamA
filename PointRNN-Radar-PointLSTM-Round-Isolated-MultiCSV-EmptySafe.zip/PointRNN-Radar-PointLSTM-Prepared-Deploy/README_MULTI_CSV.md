# 多 CSV 按文件、按圈隔离处理

本次版本以用户指定的 PointRNN-Radar-PointLSTM-Prepared-Deploy-Round-Isolated.zip 工程为基础。入口同时接受单个 CSV 或目录；目录只枚举直接子文件，扩展名不区分大小写，按 `(文件名.casefold(), 文件名)` 稳定排序，不递归。请用 `001_...csv` 等文件名明确文件间时间顺序。

```powershell
python data_prepare.py --input ./data --config radar_config.json --output processed
python data_prepare.py --input ./data/file1.csv --config radar_config.json --output processed_single
python radar_train.py --data processed --config radar_config.json --output outputs/exp1
python radar_test.py --data processed --config radar_config.json --checkpoint outputs/exp1/best.pth
python radar_deploy_sim.py --csv ./data/file1.csv --config radar_config.json --processed processed --checkpoint outputs/exp1/best.pth --output deploy_prediction.csv
```

`--csv` 是预处理 `--input` 的兼容别名。部署模拟仍然逐文件运行；它不按 Label 删除点或下采样。

每个文件独立取完整圈，前 `floor(N*train_ratio)` 圈训练，接着 `floor(N*val_ratio)` 圈验证，余下圈测试。默认 0.7/0.15/剩余 0.15，20 圈为 14/3/3，40 圈为 28/6/6。`split.mode=auto` 也始终按圈隔离；旧的 `sample` 配置继续按基础版本的迁移规则打印提示，并统一使用圈隔离划分。

先分别隔离圈段，再在各段按 `sequence_length`、`sequence_stride` 生成圈滑窗，内部按递增扇区编号生成样本。不得跨文件、跨 split 边界。CSV 必须按时间排列，显式圈号必须为非递减整数；乱序报错，不自动排序。默认要求连续圈号，缺圈时跳过对应窗口。没有配置圈号列时，按方位回绕流式推断，各文件重新开始。

不足 `sequence_length` 的圈段明确打印 WARNING 并跳过。合并后 train/test 为空时提示并正常返回，仍输出对应的零样本分片索引；val 为空时不生成 val.pt。设 `val_ratio=0` 可关闭验证，训练保存 last.pth，测试相应使用该文件。

各文件样本合并后，train、val 总是分别用 `train.seed`、`train.seed+1` 打乱；旧 `shuffle_samples` 字段不再控制此行为。test 保持文件顺序、窗口起始圈顺序、扇区顺序。重叠滑窗中点会重复出现，统计是样本内有效点的累计次数，不是原始行去重计数。

保留纯杂波窗口过滤 `data.drop_all_clutter_windows`、目标优先 `max_points_per_frame`、padding/mask、逐点 Recall、仅 train 在线旋转及 IQ 增强。点迹级杂波下采样在合并后的每个 split 内进行：`split.sample_train_clutter=true`、`sample_val_clutter=true`、`sample_test_clutter=false`。下采样全局精确保留 min(目标数, 杂波数) 个杂波，目标不受该步骤删除。注意 `max_points_per_frame` 仍可能截断点；需要测试保留所有点时设为 0，并配置足够单帧内存预算。

CSV 只通过 chunksize 分块读取，圈/扇区原始点暂存在磁盘；每个文件使用独立缓存命名空间，因此重复圈号不会混淆。`prepare_temp_dir` 可设到空闲磁盘，默认系统临时目录。点数组内存由块大小、单帧/单样本预算和输出分片限制；轻量窗口引用及圈清单仍随样本数量增长，磁盘缓存也需足够空间。单帧或单样本超过预算会给出明确错误，不尝试无限分配内存。

输出 `train.pt`、可选 `val.pt`、`test.pt` 为现有 dataset 支持的分片索引，点数组在 `processed/shards/`。务必复制整个 processed 目录。`scaler.npz` 只用训练点拟合，验证/测试不参与缺失值填充或均值方差计算。另有 `resolved_config.json` 和 `split_summary.json`，含每个文件圈清单、split 圈数、样本数、警告、读取行数，以及最终逐点目标/杂波汇总。

每个存储样本增加 `file_id`、`source_file`、与每帧点一一对应的 `row_ids`。行号从 2 开始（表头记为第 1 行），表示 CSV 逻辑记录序号；若单元格含嵌入换行则不是物理文本行号。这些字段经过目标优先采样和杂波下采样仍对齐。可通过 `ProcessedRadarDataset._stored_sample(i)` 读取来源；训练批次接口保持原样。

本次根据用户要求不运行测试、训练、部署或构建。仅进行源文件差异及人工静态核对；此前基于其他 ZIP 的测试结论不适用于本交付版本。基础版本的 radar/dataset.py 保持原样，继续拒绝旧 sample 划分或缺失 split_mode 的训练/验证/测试缓存。请重新生成数据缓存并重新训练。

## 圈数不足时正常返回（本次更新）

单文件、单圈段不足 sequence_length 时打印提示，该段样本列表为空，继续处理其他圈段和文件。所有文件合并后仍为空也不抛异常，正常保存 split_summary.json、train.pt/test.pt 空索引并返回汇总。仅有表头的 CSV 也按零圈处理；非法字段、配置或数据错误仍明确报错。

若 train 有有效点，照常拟合 scaler，空 test 不影响预处理完成。若 train 无有效点，跳过 scaler 拟合，不生成 scaler.npz，并清除同输出目录中旧的 scaler.npz；其他 split 如有样本则保留原始特征，元数据记录 scaler_fitted=false、features_normalized=false。此时缓存中的零均值/单位标准差仅为结构占位，不代表已拟合。训练/测试数据加载器会明确提示需增加训练圈数并重新预处理，避免误用未标准化数据。预处理本身正常返回，不会触发该加载器错误。

本次按用户要求未运行测试。
