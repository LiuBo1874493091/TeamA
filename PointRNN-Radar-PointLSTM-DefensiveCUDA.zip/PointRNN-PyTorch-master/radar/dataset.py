import hashlib
import json
import pickle
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
from tqdm import tqdm


def _log(message):
    print(message, flush=True)


def _read_csv_with_progress(csv_path, chunksize=200_000):
    """Read a large CSV in chunks so the user sees progress while parsing."""
    _log(f"[数据处理 1/5] 正在读取 CSV：{csv_path}")
    started = time.perf_counter()
    chunks = []
    reader = pd.read_csv(csv_path, chunksize=chunksize)
    total_rows = 0
    for chunk in tqdm(reader, desc="读取 CSV", unit="块", leave=True):
        chunks.append(chunk)
        total_rows += len(chunk)
    if not chunks:
        raise ValueError(f"CSV 文件为空：{csv_path}")
    df = pd.concat(chunks, ignore_index=True)
    _log(f"  已读取 {total_rows:,} 行，耗时 {time.perf_counter() - started:.1f}s")
    return df


def _as_numeric(series, name):
    x = pd.to_numeric(series, errors='coerce')
    if x.isna().all():
        raise ValueError(f'Column {name!r} has no numeric values.')
    return x


def infer_round_ids(azimuth_deg, wrap_drop_deg=180.0):
    """Infer scan-circle IDs from chronological azimuth values by 360->0 wrap."""
    a = np.asarray(azimuth_deg, dtype=np.float64)
    if len(a) == 0:
        return np.zeros(0, dtype=np.int64)
    wrap = (a[1:] - a[:-1]) < -abs(wrap_drop_deg)
    out = np.zeros(len(a), dtype=np.int64)
    out[1:] = np.cumsum(wrap)
    return out


def _cache_signature(csv_path, config):
    """Build a stable signature so stale preprocessing cache is not reused."""
    p = Path(csv_path)
    st = p.stat()
    relevant = {
        'columns': config.get('columns', {}),
        'data': config.get('data', {}),
        'split': config.get('split', {}),
        'csv_size': st.st_size,
        'csv_mtime_ns': st.st_mtime_ns,
        'cache_version': 2,
    }
    text = json.dumps(relevant, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def _default_cache_path(csv_path):
    p = Path(csv_path)
    return p.with_suffix(p.suffix + '.radar_cache.pkl')


def _build_windows(rounds, seq_len, stride, require_consecutive=True):
    windows = []
    if len(rounds) < seq_len:
        return windows
    for start_i in range(0, len(rounds) - seq_len + 1, stride):
        win = rounds[start_i:start_i + seq_len]
        if require_consecutive and np.any(np.diff(win) != 1):
            continue
        windows.append(win.copy())
    return windows


class RadarSequenceDataset(Dataset):
    """Radar sequence dataset with persistent preprocessing cache and split-safe windows."""

    def __init__(self, csv_path, config, split='train', prepared=None,
                 cache_path=None, rebuild_cache=False):
        self.csv_path = str(csv_path)
        self.cfg = config
        self.split = split
        if prepared is None:
            self.prepared = self._prepare(
                csv_path, config,
                cache_path=cache_path,
                rebuild_cache=rebuild_cache,
            )
        else:
            self.prepared = prepared

        self.groups = self.prepared['groups']
        self.feature_cols = self.prepared['feature_cols']
        self.feature_mean = self.prepared['feature_mean']
        self.feature_std = self.prepared['feature_std']
        self.samples = self.prepared['samples_by_split'].get(split, [])
        if split != 'all' and not self.samples:
            counts = {k: len(v) for k, v in self.prepared['samples_by_split'].items()}
            split_round_counts = self.prepared.get('split_round_counts', {})
            raise RuntimeError(
                f'No {split} samples built. Sample counts={counts}; split round counts={split_round_counts}. '
                '如果启用了严格无泄漏划分，则每个需要使用的数据集至少要有 sequence_length 圈。'
            )
        _log(f"[数据处理] {split} 数据集就绪：{len(self.samples):,} 个序列样本；特征数={len(self.feature_cols)}")

    @staticmethod
    def _prepare(csv_path, config, cache_path=None, rebuild_cache=False):
        started = time.perf_counter()
        cache_path = Path(cache_path) if cache_path else _default_cache_path(csv_path)
        signature = _cache_signature(csv_path, config)
        use_cache = bool(config.get('data', {}).get('cache_preprocessed', True))

        if use_cache and cache_path.exists() and not rebuild_cache:
            try:
                _log(f'[缓存] 正在读取预处理缓存：{cache_path}')
                with cache_path.open('rb') as f:
                    obj = pickle.load(f)
                if obj.get('signature') == signature:
                    prepared = obj['prepared']
                    _log(f'[缓存] 命中，有效缓存加载完成，耗时 {time.perf_counter() - started:.1f}s；无需重新处理 CSV。')
                    return prepared
                _log('[缓存] 配置或 CSV 已变化，缓存失效，将重新预处理。')
            except Exception as exc:
                _log(f'[缓存] 读取失败，将重新预处理：{exc}')

        df = _read_csv_with_progress(csv_path)
        cols = config['columns']
        azi_col = cols['azimuth']
        range_col = cols['range']
        label_col = cols['label']
        for c in [azi_col, range_col, label_col]:
            if c not in df.columns:
                raise KeyError(f'Required CSV column {c!r} not found. Available columns: {list(df.columns)}')

        _log('[数据处理 2/5] 正在检查字段、转换数值并生成标签...')
        df = df.copy()
        df['_row_order'] = np.arange(len(df), dtype=np.int64)
        df[azi_col] = _as_numeric(df[azi_col], azi_col) % 360.0
        df[range_col] = _as_numeric(df[range_col], range_col)

        round_col = cols.get('round_id')
        if round_col and round_col in df.columns:
            df['_round'] = pd.to_numeric(df[round_col], errors='raise').astype(np.int64)
        else:
            if round_col:
                _log(f"  提示：配置的圈号列 {round_col!r} 不存在，改为根据方位角回绕推断圈号。")
            df = df.sort_values('_row_order')
            df['_round'] = infer_round_ids(df[azi_col].to_numpy(), config['data'].get('wrap_drop_deg', 180.0))

        sector_width = float(config['data'].get('sector_width_deg', 30.0))
        if sector_width <= 0 or abs((360.0 / sector_width) - round(360.0 / sector_width)) > 1e-6:
            raise ValueError('sector_width_deg must be positive and divide 360 exactly in this implementation.')
        n_sectors = int(round(360.0 / sector_width))
        df['_sector'] = np.floor(df[azi_col] / sector_width).astype(np.int64).clip(0, n_sectors - 1)

        positives = set(str(v).strip() for v in config['data'].get('positive_label_values', [1, '1', True, 'true', 'target']))
        positives_lower = {v.lower() for v in positives}

        def to_binary_label(v):
            if pd.isna(v):
                return 0
            sv = str(v).strip()
            if sv in positives or sv.lower() in positives_lower:
                return 1
            try:
                return int(float(sv) == 1.0 and ('1' in positives or '1.0' in positives))
            except (ValueError, TypeError):
                return 0

        df['_label'] = df[label_col].map(to_binary_label).astype(np.int64)

        feature_cols = list(cols.get('features', [])) or [range_col, azi_col]
        for c in feature_cols:
            if c not in df.columns:
                raise KeyError(f'Feature column {c!r} not found in CSV. Available columns: {list(df.columns)}')
            df[c] = pd.to_numeric(df[c], errors='coerce')
        df[feature_cols] = df[feature_cols].replace([np.inf, -np.inf], np.nan)
        df[feature_cols] = df[feature_cols].fillna(df[feature_cols].median(numeric_only=True)).fillna(0.0)

        elev_col = cols.get('elevation')
        range_scale = float(config['data'].get('range_scale', 1000.0))
        az = np.deg2rad(df[azi_col].to_numpy(np.float32))
        rr = df[range_col].to_numpy(np.float32) / range_scale
        if elev_col and elev_col in df.columns:
            elev = np.deg2rad(pd.to_numeric(df[elev_col], errors='coerce').fillna(0).to_numpy(np.float32))
            xy = rr * np.cos(elev)
            df['_x'] = xy * np.cos(az)
            df['_y'] = xy * np.sin(az)
            df['_z'] = rr * np.sin(elev)
        else:
            df['_x'] = rr * np.cos(az)
            df['_y'] = rr * np.sin(az)
            df['_z'] = 0.0

        rounds = np.array(sorted(df['_round'].unique()), dtype=np.int64)
        seq_len = int(config['data'].get('sequence_length', 8))
        stride = int(config['data'].get('sequence_stride', 1))
        if seq_len < 1 or stride < 1:
            raise ValueError('sequence_length and sequence_stride must be >= 1.')

        # IMPORTANT: split rounds first, then build windows inside each split.
        # This prevents train/val/test windows from sharing the same rounds.
        train_ratio = float(config['split'].get('train_ratio', 0.7))
        val_ratio = float(config['split'].get('val_ratio', 0.15))
        if not (0 < train_ratio < 1) or not (0 <= val_ratio < 1) or train_ratio + val_ratio >= 1:
            raise ValueError('Require 0 < train_ratio < 1, 0 <= val_ratio < 1, and train_ratio + val_ratio < 1.')
        n_rounds = len(rounds)
        train_end = int(n_rounds * train_ratio)
        val_end = int(n_rounds * (train_ratio + val_ratio))
        split_rounds = {
            'train': rounds[:train_end],
            'val': rounds[train_end:val_end],
            'test': rounds[val_end:],
            'all': rounds,
        }
        split_round_counts = {k: len(v) for k, v in split_rounds.items()}
        _log('  圈次无泄漏划分：' + ', '.join(f'{k}={len(v)}圈' for k, v in split_rounds.items() if k != 'all'))

        # Normalize using TRAIN rounds only to avoid validation/test leakage.
        train_mask = df['_round'].isin(split_rounds['train'])
        if not train_mask.any():
            raise RuntimeError('Training split has no rows. Increase train_ratio or provide more rounds.')
        feature_mean = df.loc[train_mask, feature_cols].mean().to_numpy(np.float32)
        feature_std = df.loc[train_mask, feature_cols].std(ddof=0).to_numpy(np.float32)
        feature_std[feature_std < 1e-6] = 1.0

        _log(f"  字段处理完成：{len(df):,} 行；真实点={int(df['_label'].sum()):,}，负类点={int((df['_label'] == 0).sum()):,}")

        _log('[数据处理 3/5] 正在按圈号和扇区建立点集缓存...')
        groups = {}
        grouped = df.groupby(['_round', '_sector'], sort=False)
        for (r, s), g in tqdm(grouped, total=grouped.ngroups, desc='建立圈-扇区点集', unit='组', leave=True):
            xyz = g[['_x', '_y', '_z']].to_numpy(np.float32)
            feat = g[feature_cols].to_numpy(np.float32)
            feat = (feat - feature_mean) / feature_std
            lab = g['_label'].to_numpy(np.int64)
            groups[(int(r), int(s))] = (xyz, feat, lab)

        _log(f'[数据处理 4/5] 正在各数据划分内部构建序列窗口：总圈数={n_rounds}, L={seq_len}, stride={stride}...')
        require_consecutive = bool(config['data'].get('require_consecutive_round_ids', True))
        windows_by_split = {}
        for split_name, rs in split_rounds.items():
            windows_by_split[split_name] = _build_windows(rs, seq_len, stride, require_consecutive)
            if split_name != 'all' and len(rs) < seq_len:
                _log(f'  警告：{split_name} 只有 {len(rs)} 圈，小于 sequence_length={seq_len}，因此没有独立序列样本。')

        _log('[数据处理 5/5] 正在为各数据划分建立扇区样本索引...')
        samples_by_split = {}
        for split_name, split_windows in windows_by_split.items():
            samples = []
            for win in tqdm(split_windows, desc=f'{split_name} 样本索引', unit='窗', leave=True):
                for sector in range(n_sectors):
                    # Keep sector if it has points in at least one frame of this window.
                    if any((int(r), sector) in groups for r in win):
                        samples.append((win.copy(), sector))
            samples_by_split[split_name] = samples

        prepared = {
            'groups': groups,
            'feature_cols': feature_cols,
            'feature_mean': feature_mean,
            'feature_std': feature_std,
            'samples_by_split': samples_by_split,
            'split_round_counts': split_round_counts,
            'n_sectors': n_sectors,
            'sector_width_deg': sector_width,
            'sequence_length': seq_len,
            'sequence_stride': stride,
        }

        if use_cache:
            try:
                _log(f'[缓存] 正在保存预处理结果：{cache_path}')
                cache_path.parent.mkdir(parents=True, exist_ok=True)
                with cache_path.open('wb') as f:
                    pickle.dump({'signature': signature, 'prepared': prepared}, f, protocol=pickle.HIGHEST_PROTOCOL)
                _log('[缓存] 保存完成。后续使用相同 CSV 和配置训练时可直接加载。')
            except Exception as exc:
                _log(f'[缓存] 保存失败，但不影响本次训练：{exc}')

        elapsed = time.perf_counter() - started
        _log(f'[数据处理完成] 总耗时 {elapsed:.1f}s；样本数=' +
             ', '.join(f'{k}:{len(v):,}' for k, v in samples_by_split.items()))
        return prepared

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        rounds, sector = self.samples[idx]
        xyz_seq, feat_seq, label_seq = [], [], []
        max_points = int(self.cfg['data'].get('max_points_per_frame', 0) or 0)
        base_seed = int(self.cfg.get('train', {}).get('seed', 42))
        for r in rounds:
            item = self.groups.get((int(r), int(sector)))
            if item is None:
                xyz_seq.append(np.zeros((0, 3), np.float32))
                feat_seq.append(np.zeros((0, len(self.feature_cols)), np.float32))
                label_seq.append(np.zeros((0,), np.int64))
                continue

            xyz, feat, lab = item
            # Copy only when subsampling is needed; cached arrays themselves stay immutable.
            if max_points > 0 and len(xyz) > max_points:
                rng = np.random.default_rng(base_seed + int(r) * 1_000_003 + int(sector) * 9_176)
                pos = np.flatnonzero(lab == 1)
                neg = np.flatnonzero(lab == 0)
                if len(pos) >= max_points:
                    chosen = rng.choice(pos, size=max_points, replace=False)
                else:
                    n_neg = max_points - len(pos)
                    chosen_neg = rng.choice(neg, size=min(n_neg, len(neg)), replace=False) if len(neg) else np.empty(0, dtype=np.int64)
                    chosen = np.concatenate([pos, chosen_neg])
                chosen = np.sort(chosen)
                xyz_out, feat_out, lab_out = xyz[chosen], feat[chosen], lab[chosen]
            else:
                xyz_out, feat_out, lab_out = xyz, feat, lab

            xyz_seq.append(xyz_out)
            feat_seq.append(feat_out)
            label_seq.append(lab_out)

        return {
            'xyz': xyz_seq,
            'features': feat_seq,
            'labels': label_seq,
            'rounds': rounds.astype(np.int64),
            'sector': int(sector),
        }


def radar_collate_fn(batch):
    if batch is None or len(batch) == 0:
        raise ValueError('radar_collate_fn received an empty batch.')
    B = len(batch)
    required = {'xyz', 'features', 'labels', 'rounds', 'sector'}
    for bi, item in enumerate(batch):
        missing = required - set(item.keys())
        if missing:
            raise KeyError(f'batch[{bi}] missing keys: {sorted(missing)}')
        if not (len(item['xyz']) == len(item['features']) == len(item['labels'])):
            raise ValueError(
                f'batch[{bi}] sequence length mismatch: xyz={len(item["xyz"])}, '
                f'features={len(item["features"])}, labels={len(item["labels"])}'
            )
    L = len(batch[0]['xyz'])
    if L <= 0:
        raise ValueError('Sequence length L must be > 0.')
    if any(len(item['xyz']) != L for item in batch):
        raise ValueError('All samples in a batch must have the same sequence length L.')

    F = None
    for bi, item in enumerate(batch):
        for ti, (x, f, y) in enumerate(zip(item['xyz'], item['features'], item['labels'])):
            x = np.asarray(x)
            f = np.asarray(f)
            y = np.asarray(y)
            if x.ndim != 2 or x.shape[1] != 3:
                raise ValueError(f'batch[{bi}] frame[{ti}] xyz must be [n,3], got {x.shape}')
            if f.ndim != 2:
                raise ValueError(f'batch[{bi}] frame[{ti}] features must be [n,F], got {f.shape}')
            if y.ndim != 1:
                raise ValueError(f'batch[{bi}] frame[{ti}] labels must be [n], got {y.shape}')
            if not (len(x) == len(f) == len(y)):
                raise ValueError(
                    f'batch[{bi}] frame[{ti}] point-count mismatch: xyz={len(x)}, features={len(f)}, labels={len(y)}'
                )
            if F is None:
                F = f.shape[1]
            elif f.shape[1] != F:
                raise ValueError(f'Feature dimension mismatch: expected F={F}, got F={f.shape[1]} at sample={bi}, frame={ti}')
            if x.size and not np.isfinite(x).all():
                raise ValueError(f'NaN/Inf found in xyz at sample={bi}, frame={ti}')
            if f.size and not np.isfinite(f).all():
                raise ValueError(f'NaN/Inf found in features at sample={bi}, frame={ti}')
            if y.size:
                bad = y[(y != 0) & (y != 1)]
                if bad.size:
                    raise ValueError(f'Labels must be 0/1 before padding; found {np.unique(bad)[:20].tolist()} at sample={bi}, frame={ti}')
    if F is None or F <= 0:
        raise ValueError(f'Feature dimension F must be > 0, got {F}')

    T = max(max((len(frame) for frame in item['xyz']), default=0) for item in batch)
    if T <= 0:
        raise ValueError('Entire collated batch contains zero radar points. Check split/sector/sample construction.')
    xyz = torch.zeros(B, L, T, 3, dtype=torch.float32)
    features = torch.zeros(B, L, T, F, dtype=torch.float32)
    labels = torch.full((B, L, T), -100, dtype=torch.long)
    mask = torch.zeros(B, L, T, dtype=torch.bool)
    sectors = torch.tensor([b['sector'] for b in batch], dtype=torch.long)
    try:
        rounds = torch.stack([torch.from_numpy(np.asarray(b['rounds'], dtype=np.int64)) for b in batch])
    except Exception as exc:
        raise ValueError(f'Failed to stack round ids; all samples must have exactly L={L} rounds: {exc}') from exc

    for b, item in enumerate(batch):
        for t in range(L):
            n = len(item['xyz'][t])
            if n == 0:
                continue
            if n > T:
                raise RuntimeError(f'Internal collate error: n={n} exceeds allocated T={T} at sample={b}, frame={t}')
            xyz[b, t, :n] = torch.as_tensor(item['xyz'][t], dtype=torch.float32)
            features[b, t, :n] = torch.as_tensor(item['features'][t], dtype=torch.float32)
            labels[b, t, :n] = torch.as_tensor(item['labels'][t], dtype=torch.long)
            mask[b, t, :n] = True

    if not mask.any():
        raise ValueError('Entire collated batch is padding.')
    if not torch.isfinite(xyz).all() or not torch.isfinite(features).all():
        raise ValueError('NaN/Inf appeared after collate conversion.')
    if (labels[mask] < 0).any() or (labels[mask] > 1).any():
        raise ValueError(f'Valid labels after collate must be 0/1, got {torch.unique(labels[mask]).tolist()}')
    if not (labels[~mask] == -100).all():
        raise RuntimeError('Padding label invariant broken: all padding labels must be -100.')
    return {
        'xyz': xyz,
        'features': features,
        'labels': labels,
        'mask': mask,
        'rounds': rounds,
        'sector': sectors,
    }


def load_config(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)
