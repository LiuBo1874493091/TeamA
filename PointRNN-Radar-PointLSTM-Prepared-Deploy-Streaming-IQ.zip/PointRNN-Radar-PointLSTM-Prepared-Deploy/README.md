# PointRNN Radar PointLSTM — 流式预处理与在线增强版

基于用户提供的 `PointRNN-Radar-PointLSTM-Prepared-Deploy.zip` 修改。
本次交付日期：2026-10-29。**按用户最新要求，未运行构建、smoke test、训练、测试或部署；本版未经运行验证。**

本工程保持预处理、训练、测试、部署分离。新增分块 CSV 读取、磁盘暂存及分片缓存；在线增强替换为“整个样本统一旋转”和“四列 IQ 增强”，两类独立开关，仅训练时使用。

## 1. 字段与依赖

`radar_config.json` 已按以下字段配置，方位单位为度，距离单位与原始工程一致：

```json
"columns": {
  "range": "距离",
  "azimuth": "方位",
  "elevation": null,
  "round_id": "正北圈数",
  "label": "Label",
  "features": ["距离", "方位", "和I", "和Q", "方I", "方Q"]
}
```

依赖仍为 `requirements-radar.txt` 中的 PyTorch、NumPy、pandas、tqdm、matplotlib。雷达模型使用原有纯 PyTorch 实现；不需要编译旧版 Moving MNIST 的 CUDA 扩展。原始工程文件、扩展源码及历史说明一并保留，原仓库 README 见 `README_ORIGINAL.md`。

## 2. 分块预处理

以下命令是用户后续使用说明，本次交付未执行：

```powershell
python data_prepare.py --csv ./data/data.csv --config radar_config.json --output processed
```

处理流程：

1. 仅读表头，然后按 `data.csv_chunksize` 读取所需列。CSV 按时间顺序处理，不进行整表排序。
2. 按“圈次 + 扇区”追加临时磁盘文件；SQLite 保存帧计数。chunk 边界不会结束一圈，也不会丢失跨 chunk 的方位回绕。
3. 每帧使用目标优先的随机限点：先保留目标，剩余名额采杂波；目标超过上限时仅在目标中随机选点。原始点的相对顺序保持不变。
4. 根据原始圈/扇区的目标数量过滤全杂波窗口，然后进行 `sample` 或 `round_isolated` 划分。
5. 对划分后、限点后的样本统计目标/杂波数量；用可复现的流式全局随机下采样精确保留 `min(目标数, 杂波数)` 个杂波点，不建立全局杂波位置表。目标点不参与此步骤的删除。
6. 仅使用最终 train 样本统计 scaler。采用 float64 增量均值/方差；再重放相同采样过程、标准化并逐片保存三套缓存。

CSV 的 `round_id` 必须是按时间非递减的整数；出现回退时明确报错，不自动重排。缺少配置的圈次列时，沿用方位 `360→0` 回绕推断圈次，跨 chunk 保留前一方位及累计圈次。默认要求窗口内圈次连续；可由 `require_consecutive_round_ids` 控制。

距离/方位要求有限数值，距离非负；非法几何直接报错。非几何特征的缺失/无穷值使用**训练集均值**填充，不再使用全 CSV 中位数。若某列在训练集完全没有有效值，明确报错。近零方差列使用 std=1，避免放大数值误差。

### 内存与磁盘参数

| 参数（均位于 `data`） | 默认值 | 作用 |
| --- | ---: | --- |
| `csv_chunksize` | 100000 | 每次最多读取的 CSV 行数 |
| `csv_encoding` | `utf-8-sig` | 可按文件修改，如 `gb18030` |
| `max_points_per_frame` | 256 | 每圈每扇区的点数上限；0 表示不限点 |
| `prepare_memory_budget_mb` | 256 | 帧缓存、单样本及待写分片的各自容量约束，见下文 |
| `prepare_temp_dir` | null | null 使用系统临时目录；可设置到空闲磁盘 |
| `processed_shard_samples` | 128 | 单分片最多容纳的样本数量 |
| `processed_shard_points` | 200000 | 单分片点数目标上限；单个样本不拆分 |
| `processed_cache_shards` | 1 | 每个 Dataset/worker 的分片 LRU 数量；0 禁用常驻分片缓存 |

内存中保留一个 CSV chunk、有限帧缓存、当前样本和一个待写分片；**不会保留整个 DataFrame 或全部物化滑窗**。轻量圈次/窗口引用及分片索引仍随圈数/样本数增长。`prepare_memory_budget_mb` 不是整个进程 RSS 的硬上限：这些缓冲区可同时存在，pandas/PyTorch/元数据也有额外开销；`csv_chunksize` 需按可用内存调整。

单帧/单样本超过预算时会报错，提示降低 `max_points_per_frame` 或提高预算；0 不限点不等于单个超大样本也能无限制装入内存。大文件暂存需要额外磁盘空间，暂存目录在正常退出或 Python 异常退出时清理；进程被强制结束时可能留下临时目录。

## 3. 缓存与两种划分

输出结构：

```text
processed/
  train.pt                 # 新版：分片索引、scaler、统计和元数据
  val.pt                   # 无验证集时不存在
  test.pt
  shards/
    train_<generation>/000000.pt ...
    val_<generation>/000000.pt ...
    test_<generation>/000000.pt ...
  scaler.npz
  split_summary.json
  resolved_config.json
```

新版 `ProcessedRadarDataset` 按需加载分片，也能直接读取旧版含 `samples` 的单文件 `.pt`。旧缓存不必为了在线增强而重做；配置中的特征名称/顺序必须与缓存一致。**复制新版缓存时必须复制整个 processed 目录及 shards。** 不能只拿 `train.pt`，也不能继续在外部脚本中假设新版 `torch.load(train.pt)['samples']` 包含全部样本；请使用 Dataset 接口。

生成新缓存时使用新的分片目录，分片全部写好后再替换顶层索引。为保留旧缓存和并发读取者，不自动删除旧代分片；重新准备大量数据时建议输出到新目录，并在确认不再需要后手动整理旧目录。

`split.mode`：

- `auto`：`val_ratio>0` 使用 `sample`；`val_ratio=0` 使用 `round_isolated`。
- `sample`：先按圈次/扇区构建并过滤窗口，再按样本划分，可配置 `shuffle_samples`。重叠窗口可能共享原始圈次。
- `round_isolated`：先按时间把原始圈次分段，再各自在段内滑窗；不同集合不共享原始圈次。`split_summary.json` 记录 `round_partitions`。

train/val 保留杂波下采样；test 由 `split.sample_test_clutter` 控制，默认 false。默认删除全杂波窗口的行为仍保留，这也会影响测试集的覆盖范围。

仅需 train/test 时，将 `val_ratio` 设为 0，`mode` 保持 auto。不会生成 `val.pt`；同输出目录若有旧的 `val.pt` 会移除。训练只保存 `last.pth`，不以 test 选择最佳模型。

## 4. 两类在线增强

```json
"augmentation": {
  "enabled": true,
  "sample_rotation": {
    "enabled": true,
    "probability": 0.5,
    "angle_range_deg": [-180.0, 180.0]
  },
  "iq_augmentation": {
    "enabled": true,
    "probability": 0.5,
    "columns": ["和I", "和Q", "方I", "方Q"],
    "gaussian_noise_enabled": true,
    "noise_units": "train_std",
    "noise_std": 0.02,
    "amplitude_scale_enabled": true,
    "amplitude_scale_range": [0.95, 1.05]
  }
}
```

两个 `enabled` 和概率独立；外层 `enabled=false` 可总关闭。默认示例同时开启两类增强；也可仅开一种。

**sample_rotation**：对一个样本的所有帧、所有点只抽一次角度，绕 z 轴统一旋转。距离及距离特征不变，方位统一加角并 wrap 到 `[0,360)`，同步重算 xyz 的 x/y，z/俯仰保持不变；点数、点序、标签不变。缓存特征会在物理量与标准化尺度之间转换。旋转后的点不重新分扇区、不裁切回原扇区，因此保持整个样本的相对几何关系；`sector` 作为原样本来源元数据保持原值。

**iq_augmentation**：仅可选择“和I、和Q、方I、方Q”四列或其子集。先在原始物理幅度上做同一样本共享的幅值缩放，再逐点逐列加独立高斯噪声，最后按缓存 scaler 标准化；不修改 xyz、距离、方位、其他特征、标签或点数。

- `noise_units=train_std`：`noise_std=0.02` 表示噪声标准差为该列训练 std 的 2%。
- `noise_units=raw`：噪声标准差直接使用原始 IQ 单位。
- `noise_std` 可以是统一数字，也可以是按四列名称配置的对象；对象中未配置的列噪声为 0。
- 高斯噪声与幅值缩放各有开关；幅值乘数在配置区间内均匀抽样。

增强仅在 `ProcessedRadarDataset(..., split='train')` 读取样本时执行，每次读取可产生新结果；缓存文件保持基础样本。val/test/predict/deploy 均不增强。旧版逐点距离/方位抖动、杂波注入与点删除配置已被这两类增强替代，不再使用。

## 5. 后续使用命令

以下命令均未在本次交付中执行。

```powershell
# 训练：只读取 processed 缓存
python radar_train.py --data processed --config radar_config.json --output outputs/exp1

# 测试；无 val 时把 best.pth 改为 last.pth
python radar_test.py --data processed --config radar_config.json --checkpoint outputs/exp1/best.pth

# 部署模拟：CSV 最后一列写 predicted_label
python radar_deploy_sim.py --csv ./data/data.csv --config radar_config.json --processed processed --checkpoint outputs/exp1/best.pth --output deploy_prediction.csv

# 从缓存导出逐窗口点概率；train 也不增强
python radar_predict.py --data processed --config radar_config.json --checkpoint outputs/exp1/best.pth --split test --output radar_predictions.csv
```

逐点 recall、F1/loss/recall 曲线、mask/padding 检查、梯度裁剪及无 val 模式均保留。显式预热开关为 `train.cuda_warmup` 和 `train.model_warmup`，CPU 时直接跳过；CUDA 初始化及第一次模型前向会单独打印提示。

部署仍完全忽略 Label，不按标签过滤/下采样/限点，不执行在线增强；使用训练 scaler。首次满 L 圈写回这 L 圈，以后只写最新圈。部署模拟保留原来的整表回写结构；**本次的分块内存重构针对数据准备，不代表部署模拟器也已改为全程流式输出。**

变更明细和验证状态见 `STREAMING_AUGMENTATION_CHANGELOG.md`。
