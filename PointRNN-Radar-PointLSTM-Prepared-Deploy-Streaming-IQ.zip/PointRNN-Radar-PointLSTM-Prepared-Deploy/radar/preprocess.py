import numpy as np


def infer_round_ids(azimuth_deg, wrap_drop_deg=180.0):
    a = np.asarray(azimuth_deg, dtype=np.float64)
    out = np.zeros(len(a), dtype=np.int64)
    if len(a) > 1:
        out[1:] = np.cumsum((a[1:] - a[:-1]) < -abs(wrap_drop_deg))
    return out


def _windows(rounds, L, stride, consecutive=True):
    for i in range(0, max(0, len(rounds)-L+1), stride):
        w=np.asarray(rounds[i:i+L],dtype=np.int64)
        if len(w)!=L: continue
        if consecutive and np.any(np.diff(w)!=1): continue
        yield w


def _split_rounds(rounds, train_ratio, val_ratio):
    n=len(rounds)
    n_train=int(n*train_ratio)
    n_val=int(n*val_ratio)
    if n_train<=0 or n_train>=n: raise ValueError('round_isolated split leaves empty train/test.')
    if val_ratio>0 and n_val<=0: raise ValueError('val_ratio>0 but too few rounds for val split.')
    if n_train+n_val>=n: raise ValueError('round_isolated split leaves empty test split.')
    return {
        'train': np.asarray(rounds[:n_train]),
        'val': np.asarray(rounds[n_train:n_train+n_val]),
        'test': np.asarray(rounds[n_train+n_val:]),
    }


def _split_samples(samples, train_ratio, val_ratio, seed, shuffle):
    n=len(samples); idx=np.arange(n)
    if shuffle: np.random.default_rng(seed).shuffle(idx)
    n_train=int(n*train_ratio); n_val=int(n*val_ratio)
    if n>=2: n_train=max(1,min(n_train,n-(2 if val_ratio>0 and n>=3 else 1)))
    if val_ratio>0 and n>=3:
        n_val=max(1,n_val)
        if n_train+n_val>=n: n_val=max(1,n-n_train-1)
    else: n_val=0
    return {
        'train':[samples[int(i)] for i in idx[:n_train]],
        'val':[samples[int(i)] for i in idx[n_train:n_train+n_val]],
        'test':[samples[int(i)] for i in idx[n_train+n_val:]],
    }


def prepare_data(csv_path, config, output_dir):
    from .streaming_prepare import prepare_data_streaming
    return prepare_data_streaming(csv_path, config, output_dir)
