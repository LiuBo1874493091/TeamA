import argparse
from collections import deque
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from radar.dataset import load_config, radar_collate_fn
from radar.model import RadarPointLSTMClassifier
from radar.validation import validate_model_batch


def load_ck(path, device):
    try: return torch.load(path,map_location=device,weights_only=False)
    except TypeError: return torch.load(path,map_location=device)


def build_xyz(range_v, az_v, elev_v, range_scale):
    rr=np.asarray(range_v,np.float32)/float(range_scale); az=np.deg2rad(np.asarray(az_v,np.float32))
    if elev_v is None: return np.stack([rr*np.cos(az),rr*np.sin(az),np.zeros_like(rr)],1).astype(np.float32)
    el=np.deg2rad(np.asarray(elev_v,np.float32));xy=rr*np.cos(el);return np.stack([xy*np.cos(az),xy*np.sin(az),rr*np.sin(el)],1).astype(np.float32)


def main():
    ap=argparse.ArgumentParser(description='Simulate streaming deployment from chronological data.csv.')
    ap.add_argument('--csv',required=True);ap.add_argument('--config',default='radar_config.json');ap.add_argument('--checkpoint',required=True);ap.add_argument('--processed',default='processed');ap.add_argument('--output',default='deploy_prediction.csv');args=ap.parse_args()
    cfg=load_config(args.config);cols=cfg['columns'];dcfg=cfg['data'];depcfg=cfg.get('deployment',{}) or {}
    scaler=np.load(Path(args.processed)/'scaler.npz',allow_pickle=True);mean=np.asarray(scaler['feature_mean'],np.float32);std=np.asarray(scaler['feature_std'],np.float32);feature_cols=[str(x) for x in scaler['feature_cols'].tolist()]
    if feature_cols!=list(cols.get('features',[])):
        raise ValueError(f'Configured features {cols.get("features")} differ from prepared scaler features {feature_cols}')
    df=pd.read_csv(args.csv);df['_row_id']=np.arange(len(df),dtype=np.int64);df['predicted_label']=0
    for c in [cols['range'],cols['azimuth']]+feature_cols:
        if c not in df.columns: raise KeyError(f'Missing deployment CSV column {c!r}')
    L=int(dcfg.get('sequence_length',3));sector_w=float(dcfg.get('sector_width_deg',30.0));nsec=int(round(360/sector_w));rscale=float(dcfg.get('range_scale',1000.0));rcol=cols.get('round_id');ecol=cols.get('elevation')
    deploy_max=int(depcfg.get('max_points_per_frame',0) or 0)
    if deploy_max>0:
        raise ValueError('deployment.max_points_per_frame must be 0 in this simulator so every received point is actually evaluated by the model and receives a model-produced 0/1 label.')
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu');ck=load_ck(args.checkpoint,device);model=RadarPointLSTMClassifier(len(feature_cols),hidden_dims=tuple(cfg['model']['hidden_dims']),radius=tuple(cfg['model']['radius']),nsamples=tuple(cfg['model']['nsamples']),dropout=cfg['model'].get('dropout',0.1),knn_query_chunk_size=cfg['model'].get('knn_query_chunk_size',128)).to(device);model.load_state_dict(ck['model']);model.eval()
    window=deque(maxlen=L);first_full=True;current_round=None;current_rows=[];inferred_round=0;prev_az=None

    def flush_round(round_id, rows):
        nonlocal first_full
        if not rows:return
        window.append((int(round_id),rows.copy()))
        print(f'[stream] 完成圈 {round_id}，缓存 {len(window)}/{L} 圈',flush=True)
        if len(window)<L:return
        predict_window(list(window), predict_all=first_full)
        first_full=False

    def predict_window(win,predict_all=False):
        rounds=[r for r,_ in win]; samples=[]; mappings=[]
        # Pre-group each frame by sector while preserving chronological row order.
        grouped=[]
        for r,rows in win:
            per={s:[] for s in range(nsec)}
            for rid in rows:
                az=float(pd.to_numeric(df.at[rid,cols['azimuth']],errors='coerce'))%360.0
                per[min(nsec-1,int(np.floor(az/sector_w)))].append(rid)
            grouped.append(per)
        for s in range(nsec):
            xyz_seq=[];feat_seq=[];lab_seq=[];map_seq=[]
            anyp=False
            for ti in range(L):
                ids=np.asarray(grouped[ti][s],dtype=np.int64);map_seq.append(ids);anyp=anyp or len(ids)>0
                if len(ids)==0:
                    xyz_seq.append(np.zeros((0,3),np.float32));feat_seq.append(np.zeros((0,len(feature_cols)),np.float32));lab_seq.append(np.zeros((0,),np.int64));continue
                sub=df.loc[ids]
                rv=pd.to_numeric(sub[cols['range']],errors='coerce').fillna(0).to_numpy(np.float32);av=(pd.to_numeric(sub[cols['azimuth']],errors='coerce').fillna(0).to_numpy(np.float32)%360.0)
                ev=None
                if ecol and ecol in sub.columns: ev=pd.to_numeric(sub[ecol],errors='coerce').fillna(0).to_numpy(np.float32)
                xyz=build_xyz(rv,av,ev,rscale)
                raw=np.zeros((len(ids),len(feature_cols)),np.float32)
                for j,c in enumerate(feature_cols):
                    vals=pd.to_numeric(sub[c],errors='coerce').to_numpy(np.float32); vals=np.where(np.isfinite(vals),vals,mean[j]);raw[:,j]=vals
                feat=((raw-mean)/std).astype(np.float32)
                xyz_seq.append(xyz);feat_seq.append(feat);lab_seq.append(np.zeros(len(ids),np.int64))
            if anyp:
                samples.append({'xyz':xyz_seq,'features':feat_seq,'labels':lab_seq,'rounds':np.asarray(rounds,np.int64),'sector':s});mappings.append(map_seq)
        if not samples:return
        batch=radar_collate_fn(samples);xyz=batch['xyz'].to(device);feat=batch['features'].to(device);mask=batch['mask'].to(device);validate_model_batch(xyz,feat,mask,feature_dim=model.feature_dim,stage='deploy')
        with torch.no_grad(): logits=model(xyz,feat,mask);pred=logits.argmax(-1).cpu().numpy()
        for bi,map_seq in enumerate(mappings):
            target_frames=range(L) if predict_all else [L-1]
            for ti in target_frames:
                ids=map_seq[ti]
                if len(ids)==0:continue
                df.loc[ids,'predicted_label']=pred[bi,ti,:len(ids)].astype(np.int64)
        print(f'[infer] window={rounds}，写回 {"全部L圈" if predict_all else "最新圈"}',flush=True)

    print(f'开始逐行模拟接收：rows={len(df):,}, sequence_length={L}',flush=True)
    for rid,row in df.iterrows():
        az=float(pd.to_numeric(pd.Series([row[cols['azimuth']]]),errors='coerce').iloc[0])%360.0
        if rcol and rcol in df.columns:
            rr=int(row[rcol])
        else:
            if prev_az is not None and az-prev_az < -abs(float(dcfg.get('wrap_drop_deg',180.0))): inferred_round+=1
            rr=inferred_round;prev_az=az
        if current_round is None: current_round=rr
        if rr!=current_round:
            flush_round(current_round,current_rows);current_round=rr;current_rows=[]
        current_rows.append(int(rid))
    flush_round(current_round,current_rows)
    out=Path(args.output);out.parent.mkdir(parents=True,exist_ok=True);df.drop(columns=['_row_id']).to_csv(out,index=False,encoding='utf-8-sig')
    print(f'部署模拟完成：{out}；predicted_label 位于最后一列（1=目标，0=杂波）。',flush=True)

if __name__=='__main__':main()
