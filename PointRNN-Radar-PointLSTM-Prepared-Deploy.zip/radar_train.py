import argparse, csv, json, random, time
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm

from radar.dataset import ProcessedRadarDataset, radar_collate_fn, load_config, processed_paths
from radar.model import RadarPointLSTMClassifier
from radar.metrics import BinaryMetrics
from radar.validation import validate_model_batch, validate_logits


def load_ck(path, device):
    try: return torch.load(path,map_location=device,weights_only=False)
    except TypeError: return torch.load(path,map_location=device)


def seed_all(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)


def make_loader(ds,cfg,shuffle):
    return DataLoader(ds,batch_size=int(cfg['train'].get('batch_size',1)),shuffle=shuffle,
                      num_workers=int(cfg['train'].get('workers',0)),collate_fn=radar_collate_fn,
                      pin_memory=torch.cuda.is_available())


def run_epoch(model,loader,opt,device,class_weights,epoch,name):
    train=opt is not None; model.train(train); crit=nn.CrossEntropyLoss(weight=class_weights,ignore_index=-100)
    metrics=BinaryMetrics(); loss_sum=0.; nb=0; t0=time.perf_counter()
    bar=tqdm(loader,desc=f'{name} Epoch {epoch+1}',unit='batch',dynamic_ncols=True)
    for batch in bar:
        xyz=batch['xyz'].to(device,non_blocking=True); feat=batch['features'].to(device,non_blocking=True)
        labels=batch['labels'].to(device,non_blocking=True); mask=batch['mask'].to(device,non_blocking=True)
        validate_model_batch(xyz,feat,mask,labels=labels,feature_dim=model.feature_dim,stage=name)
        if train: opt.zero_grad(set_to_none=True)
        with torch.set_grad_enabled(train):
            logits=model(xyz,feat,mask); validate_logits(logits,labels,mask)
            loss=crit(logits.reshape(-1,2),labels.reshape(-1))
            if not torch.isfinite(loss): raise FloatingPointError(f'Non-finite loss: {loss.item()}')
            if train:
                loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),max_norm=10.0); opt.step()
        loss_sum+=float(loss.item()); nb+=1; metrics.update(logits.detach(),labels,mask)
        m=metrics.compute(); bar.set_postfix(loss=f'{loss_sum/nb:.4f}',R=f'{m["recall"]:.3f}',T=xyz.shape[2])
    out=metrics.compute(); out['loss']=loss_sum/max(nb,1); out['seconds']=time.perf_counter()-t0; return out


def save_history(rows,out):
    if not rows:return
    keys=list(rows[0].keys())
    with open(out/'train_history.csv','w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); w.writerows(rows)
    ep=[r['epoch'] for r in rows]
    plt.figure(); plt.plot(ep,[r['train_loss'] for r in rows],label='Train Loss')
    if 'val_loss' in rows[0]: plt.plot(ep,[r['val_loss'] for r in rows],label='Val Loss')
    plt.xlabel('Epoch');plt.ylabel('Loss');plt.legend();plt.tight_layout();plt.savefig(out/'loss_curve.png',dpi=150);plt.close()
    plt.figure(); plt.plot(ep,[r['train_recall'] for r in rows],label='Train Recall')
    if 'val_recall' in rows[0]: plt.plot(ep,[r['val_recall'] for r in rows],label='Val Recall')
    plt.xlabel('Epoch');plt.ylabel('Point Recall');plt.legend();plt.tight_layout();plt.savefig(out/'recall_curve.png',dpi=150);plt.close()
    plt.figure(); plt.plot(ep,[r['train_f1'] for r in rows],label='Train F1')
    if 'val_f1' in rows[0]: plt.plot(ep,[r['val_f1'] for r in rows],label='Val F1')
    plt.xlabel('Epoch');plt.ylabel('F1');plt.legend();plt.tight_layout();plt.savefig(out/'f1_curve.png',dpi=150);plt.close()


def main():
    ap=argparse.ArgumentParser(description='Train PointLSTM from preprocessed train.pt/val.pt.')
    ap.add_argument('--data',default='processed');ap.add_argument('--config',default='radar_config.json')
    ap.add_argument('--output',default='outputs/exp1');ap.add_argument('--resume',default='')
    args=ap.parse_args(); cfg=load_config(args.config); seed_all(int(cfg['train'].get('seed',42)))
    paths=processed_paths(args.data); out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    if not paths['train'].exists(): raise FileNotFoundError(f'{paths["train"]} not found. Run data_prepare.py first.')
    print('[1/3] 读取预处理数据（不再处理原始 CSV）...',flush=True)
    train_ds=ProcessedRadarDataset(paths['train'],cfg,'train'); train_loader=make_loader(train_ds,cfg,True)
    val_ds=ProcessedRadarDataset(paths['val'],cfg,'val') if paths['val'].exists() else None
    val_loader=make_loader(val_ds,cfg,False) if val_ds else None
    print(f'  train={len(train_ds):,} samples; val={len(val_ds) if val_ds else 0:,}; augmentation={bool(cfg.get("augmentation",{}).get("enabled",False))}',flush=True)
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'); print(f'[2/3] device={device}',flush=True)
    model=RadarPointLSTMClassifier(len(train_ds.feature_cols),hidden_dims=tuple(cfg['model']['hidden_dims']),radius=tuple(cfg['model']['radius']),nsamples=tuple(cfg['model']['nsamples']),dropout=cfg['model'].get('dropout',0.1),knn_query_chunk_size=cfg['model'].get('knn_query_chunk_size',128)).to(device)
    opt=torch.optim.AdamW(model.parameters(),lr=cfg['train']['lr'],weight_decay=cfg['train'].get('weight_decay',1e-4))
    weights=cfg['train'].get('class_weights'); cw=torch.tensor(weights,dtype=torch.float32,device=device) if weights else None
    start=0;best=-1.;best_metric=str(cfg['train'].get('best_metric','recall')).lower()
    if args.resume:
        ck=load_ck(args.resume,device);model.load_state_dict(ck['model']);opt.load_state_dict(ck['optimizer']);start=int(ck['epoch'])+1;best=float(ck.get('best_score',-1.))
    with open(out/'resolved_config.json','w',encoding='utf-8') as f: json.dump(cfg,f,ensure_ascii=False,indent=2)
    print('[3/3] 开始训练。',flush=True); hist=[]
    for epoch in range(start,int(cfg['train']['epochs'])):
        tr=run_epoch(model,train_loader,opt,device,cw,epoch,'train')
        va=run_epoch(model,val_loader,None,device,cw,epoch,'val') if val_loader else None
        row={'epoch':epoch+1,'train_loss':tr['loss'],'train_precision':tr['precision'],'train_recall':tr['recall'],'train_f1':tr['f1'],'epoch_seconds':tr['seconds']}
        if va: row.update({'val_loss':va['loss'],'val_precision':va['precision'],'val_recall':va['recall'],'val_f1':va['f1']})
        hist.append(row);save_history(hist,out)
        ck={'model':model.state_dict(),'optimizer':opt.state_dict(),'epoch':epoch,'best_score':best,'feature_cols':train_ds.feature_cols,'feature_mean':train_ds.feature_mean,'feature_std':train_ds.feature_std,'config':cfg}
        torch.save(ck,out/'last.pth')
        if va:
            score=va[best_metric]
            if score>best: best=score;ck['best_score']=best;torch.save(ck,out/'best.pth');print(f'  best.pth <- val {best_metric}={best:.4f}',flush=True)
            print(f'epoch {epoch+1}: train loss={tr["loss"]:.4f} R={tr["recall"]:.4f}; val loss={va["loss"]:.4f} R={va["recall"]:.4f} F1={va["f1"]:.4f}',flush=True)
        else:
            print(f'epoch {epoch+1}: train loss={tr["loss"]:.4f} R={tr["recall"]:.4f} F1={tr["f1"]:.4f}; 无验证集，仅保存 last.pth，不使用 test 选 best。',flush=True)

if __name__=='__main__': main()
