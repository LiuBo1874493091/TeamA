import json
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import Dataset

from .augmentation import RadarAugmenter


def load_config(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def load_processed_split(path):
    try:
        return torch.load(path, map_location='cpu', weights_only=False)
    except TypeError:
        return torch.load(path, map_location='cpu')


class ProcessedRadarDataset(Dataset):
    """Dataset backed by data_prepare.py output.

    Each stored sample contains variable-length frames before padding:
      xyz:      list[L] of FloatTensor[Ti,3]
      features: list[L] of FloatTensor[Ti,F]
      labels:   list[L] of LongTensor[Ti]
    Training-only online augmentation is optionally applied in __getitem__.
    """
    def __init__(self, split_file, config, split='train'):
        self.split_file = str(split_file)
        self.cfg = config
        self.split = split
        payload = load_processed_split(split_file)
        self.samples = payload['samples']
        self.feature_cols = list(payload['feature_cols'])
        self.feature_mean = np.asarray(payload['feature_mean'], dtype=np.float32)
        self.feature_std = np.asarray(payload['feature_std'], dtype=np.float32)
        self.stats = dict(payload.get('stats', {}))
        self.meta = dict(payload.get('meta', {}))
        self.augmenter = (
            RadarAugmenter(config, self.feature_cols, self.feature_mean, self.feature_std)
            if split == 'train' else None
        )
        if not self.samples:
            raise RuntimeError(f'Processed split is empty: {split_file}')

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        s = self.samples[idx]
        xyz_seq = [x.detach().cpu().numpy().astype(np.float32, copy=True) for x in s['xyz']]
        feat_seq = [x.detach().cpu().numpy().astype(np.float32, copy=True) for x in s['features']]
        lab_seq = [x.detach().cpu().numpy().astype(np.int64, copy=True) for x in s['labels']]
        if self.augmenter is not None and self.augmenter.enabled:
            xyz_seq, feat_seq, lab_seq = self.augmenter(
                xyz_seq, feat_seq, lab_seq, int(s['sector']), int(idx)
            )
        return {
            'xyz': xyz_seq,
            'features': feat_seq,
            'labels': lab_seq,
            'rounds': np.asarray(s['rounds'], dtype=np.int64),
            'sector': int(s['sector']),
        }


def radar_collate_fn(batch):
    if not batch:
        raise ValueError('radar_collate_fn received an empty batch.')
    B = len(batch)
    L = len(batch[0]['xyz'])
    if L <= 0 or any(len(b['xyz']) != L for b in batch):
        raise ValueError('All samples must have the same non-zero sequence length.')

    F = None
    T = 0
    for bi, item in enumerate(batch):
        if not (len(item['xyz']) == len(item['features']) == len(item['labels']) == L):
            raise ValueError(f'sample {bi}: sequence field length mismatch')
        for ti, (x, f, y) in enumerate(zip(item['xyz'], item['features'], item['labels'])):
            x = np.asarray(x); f = np.asarray(f); y = np.asarray(y)
            if x.ndim != 2 or x.shape[1] != 3:
                raise ValueError(f'sample={bi}, frame={ti}: xyz must be [n,3], got {x.shape}')
            if f.ndim != 2 or y.ndim != 1 or not (len(x) == len(f) == len(y)):
                raise ValueError(f'sample={bi}, frame={ti}: point count/shape mismatch')
            if F is None: F = f.shape[1]
            elif F != f.shape[1]: raise ValueError('Feature dimension mismatch in batch.')
            if x.size and not np.isfinite(x).all(): raise ValueError('NaN/Inf in xyz.')
            if f.size and not np.isfinite(f).all(): raise ValueError('NaN/Inf in features.')
            if y.size and np.any((y != 0) & (y != 1)): raise ValueError('Labels must be 0/1.')
            T = max(T, len(x))
    if T <= 0 or F is None or F <= 0:
        raise ValueError('Batch has no valid radar points/features.')

    xyz = torch.zeros(B, L, T, 3, dtype=torch.float32)
    features = torch.zeros(B, L, T, F, dtype=torch.float32)
    labels = torch.full((B, L, T), -100, dtype=torch.long)
    mask = torch.zeros(B, L, T, dtype=torch.bool)
    rounds = torch.stack([torch.as_tensor(b['rounds'], dtype=torch.long) for b in batch])
    sectors = torch.as_tensor([b['sector'] for b in batch], dtype=torch.long)

    for b, item in enumerate(batch):
        for t in range(L):
            n = len(item['xyz'][t])
            if n == 0: continue
            xyz[b,t,:n] = torch.as_tensor(item['xyz'][t], dtype=torch.float32)
            features[b,t,:n] = torch.as_tensor(item['features'][t], dtype=torch.float32)
            labels[b,t,:n] = torch.as_tensor(item['labels'][t], dtype=torch.long)
            mask[b,t,:n] = True
    if not mask.any(): raise ValueError('Entire batch is padding.')
    return {'xyz':xyz, 'features':features, 'labels':labels, 'mask':mask,
            'rounds':rounds, 'sector':sectors}


def processed_paths(processed_dir):
    p = Path(processed_dir)
    return {name: p / f'{name}.pt' for name in ('train','val','test')}
