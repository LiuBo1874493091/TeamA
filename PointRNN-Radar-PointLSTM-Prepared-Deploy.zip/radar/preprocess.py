import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from tqdm import tqdm


def _numeric(s, name):
    x = pd.to_numeric(s, errors='coerce')
    if x.isna().all():
        raise ValueError(f'Column {name!r} has no numeric values.')
    return x


def infer_round_ids(azimuth_deg, wrap_drop_deg=180.0):
    a = np.asarray(azimuth_deg, dtype=np.float64)
    out = np.zeros(len(a), dtype=np.int64)
    if len(a) > 1:
        out[1:] = np.cumsum((a[1:] - a[:-1]) < -abs(wrap_drop_deg))
    return out


def _binary_labels(series, positive_values):
    pos = {str(v).strip().lower() for v in positive_values}
    def conv(v):
        if pd.isna(v): return 0
        return int(str(v).strip().lower() in pos)
    return series.map(conv).astype(np.int64)


def _windows(rounds, L, stride, consecutive=True):
    out=[]
    for i in range(0, max(0, len(rounds)-L+1), stride):
        w=np.asarray(rounds[i:i+L],dtype=np.int64)
        if len(w)!=L: continue
        if consecutive and np.any(np.diff(w)!=1): continue
        out.append(w)
    return out


def _split_rounds(rounds, train_ratio, val_ratio):
    n=len(rounds)
    n_train=int(n*train_ratio)
    n_val=int(n*val_ratio)
    if n_train<=0 or n_train>=n: raise ValueError('round_isolated split leaves empty train/test.')
    if val_ratio>0 and n_val<=0: raise ValueError('val_ratio>0 but too few rounds for val split.')
    if n_train+n_val>=n: raise ValueError('round_isolated split leaves empty test split.')
    return {
        'train': np.asarray(rounds[:n_train]),
        'val': np.asarray(rounds[n_train:n_train+n_val]),
        'test': np.asarray(rounds[n_train+n_val:]),
    }


def _split_samples(samples, train_ratio, val_ratio, seed, shuffle):
    n=len(samples); idx=np.arange(n)
    if shuffle: np.random.default_rng(seed).shuffle(idx)
    n_train=int(n*train_ratio); n_val=int(n*val_ratio)
    if n>=2: n_train=max(1,min(n_train,n-1))
    if val_ratio>0 and n>=3:
        n_val=max(1,n_val)
        if n_train+n_val>=n: n_val=max(1,n-n_train-1)
    else: n_val=0
    return {
        'train':[samples[int(i)] for i in idx[:n_train]],
        'val':[samples[int(i)] for i in idx[n_train:n_train+n_val]],
        'test':[samples[int(i)] for i in idx[n_train+n_val:]],
    }


def _choose_points(labels, max_points, rng):
    n=len(labels)
    if max_points<=0 or n<=max_points: return np.arange(n,dtype=np.int64)
    pos=np.flatnonzero(labels==1); neg=np.flatnonzero(labels==0)
    if len(pos)>=max_points:
        return np.sort(rng.choice(pos,size=max_points,replace=False)).astype(np.int64)
    need=max_points-len(pos)
    negsel=rng.choice(neg,size=min(need,len(neg)),replace=False) if len(neg) else np.array([],dtype=np.int64)
    return np.sort(np.concatenate([pos,negsel])).astype(np.int64)


def _materialize_sample(sample_ref, groups, max_points, seed):
    rounds, sector = sample_ref
    xyz_seq=[]; feat_seq=[]; lab_seq=[]
    for r in rounds:
        item=groups.get((int(r),int(sector)))
        if item is None:
            xyz_seq.append(np.zeros((0,3),np.float32)); feat_seq.append(np.zeros((0,groups['_feature_dim']),np.float32)); lab_seq.append(np.zeros((0,),np.int64)); continue
        xyz,feat,lab=item
        rng=np.random.default_rng(int(seed)+int(r)*1000003+int(sector)*9176)
        ii=_choose_points(lab,max_points,rng)
        xyz_seq.append(xyz[ii].copy()); feat_seq.append(feat[ii].copy()); lab_seq.append(lab[ii].copy())
    return {'xyz':xyz_seq,'features':feat_seq,'labels':lab_seq,'rounds':np.asarray(rounds,dtype=np.int64),'sector':int(sector)}


def _balance_split(samples, seed, enabled):
    if not enabled or not samples: return samples
    positions=[]; total_pos=0; total_neg=0
    for si,s in enumerate(samples):
        for ti,y in enumerate(s['labels']):
            total_pos += int((y==1).sum())
            neg=np.flatnonzero(y==0)
            positions.extend((si,ti,int(j)) for j in neg)
            total_neg += len(neg)
    if total_pos<=0 or total_neg<=0: return samples
    keep_n=min(total_pos,total_neg)
    rng=np.random.default_rng(seed)
    chosen=set(rng.choice(len(positions),size=keep_n,replace=False).tolist())
    keep_map={}
    for k,(si,ti,j) in enumerate(positions):
        if k in chosen: keep_map.setdefault((si,ti),set()).add(j)
    out=[]
    for si,s in enumerate(samples):
        ns={'xyz':[],'features':[],'labels':[],'rounds':s['rounds'],'sector':s['sector']}
        for ti,(x,f,y) in enumerate(zip(s['xyz'],s['features'],s['labels'])):
            keep=(y==1)
            allowed=keep_map.get((si,ti),set())
            if allowed:
                negidx=np.fromiter(allowed,dtype=np.int64)
                keep[negidx]=True
            ns['xyz'].append(x[keep]); ns['features'].append(f[keep]); ns['labels'].append(y[keep])
        out.append(ns)
    return out


def _fit_scaler(samples, F):
    count=0; sm=np.zeros(F,np.float64); ss=np.zeros(F,np.float64)
    for s in samples:
        for f in s['features']:
            if len(f)==0: continue
            a=f.astype(np.float64); count+=len(a); sm+=a.sum(0); ss+=(a*a).sum(0)
    if count<=0: raise RuntimeError('No train feature points available for scaler.')
    mean=sm/count; var=np.maximum(ss/count-mean*mean,1e-12); std=np.sqrt(var)
    return mean.astype(np.float32),std.astype(np.float32)


def _apply_scaler(samples, mean, std):
    for s in samples:
        s['features']=[((f-mean)/std).astype(np.float32) if len(f) else f.astype(np.float32) for f in s['features']]


def _stats(samples):
    p=n=0
    for s in samples:
        for y in s['labels']:
            p+=int((y==1).sum()); n+=int((y==0).sum())
    return {'samples':len(samples),'target_points':p,'clutter_points':n,'valid_points':p+n,'target_ratio':(p/(p+n) if p+n else 0.0)}


def _to_torch_payload(samples, feature_cols, mean, std, stats, meta):
    out=[]
    for s in samples:
        out.append({
            'xyz':[torch.from_numpy(np.asarray(x,np.float32)) for x in s['xyz']],
            'features':[torch.from_numpy(np.asarray(f,np.float32)) for f in s['features']],
            'labels':[torch.from_numpy(np.asarray(y,np.int64)) for y in s['labels']],
            'rounds':torch.from_numpy(np.asarray(s['rounds'],np.int64)),
            'sector':int(s['sector']),
        })
    return {'samples':out,'feature_cols':feature_cols,'feature_mean':mean,'feature_std':std,'stats':stats,'meta':meta}


def prepare_data(csv_path, config, output_dir):
    outdir=Path(output_dir); outdir.mkdir(parents=True,exist_ok=True)
    cols=config['columns']; dcfg=config['data']; scfg=config['split']; seed=int(config.get('train',{}).get('seed',42))
    print(f'[1/7] 读取 CSV: {csv_path}',flush=True)
    df=pd.read_csv(csv_path)
    for c in [cols['range'],cols['azimuth'],cols['label']]:
        if c not in df.columns: raise KeyError(f'Missing CSV column {c!r}')
    df=df.copy(); df['_row_id']=np.arange(len(df),dtype=np.int64)
    df[cols['range']]=_numeric(df[cols['range']],cols['range'])
    df[cols['azimuth']]=_numeric(df[cols['azimuth']],cols['azimuth'])%360.0
    rcol=cols.get('round_id')
    if rcol and rcol in df.columns: df['_round']=pd.to_numeric(df[rcol],errors='raise').astype(np.int64)
    else: df['_round']=infer_round_ids(df[cols['azimuth']].to_numpy(),dcfg.get('wrap_drop_deg',180.0))
    posvals=dcfg.get('positive_label_values',[1,'1','true','target'])
    df['_label']=_binary_labels(df[cols['label']],posvals)
    feature_cols=list(cols.get('features') or [cols['range'],cols['azimuth']])
    for c in feature_cols:
        if c not in df.columns: raise KeyError(f'Missing feature column {c!r}')
        df[c]=pd.to_numeric(df[c],errors='coerce')
    df[feature_cols]=df[feature_cols].replace([np.inf,-np.inf],np.nan).fillna(df[feature_cols].median(numeric_only=True)).fillna(0.0)
    sector_width=float(dcfg.get('sector_width_deg',30.0)); nsec=int(round(360.0/sector_width))
    if sector_width<=0 or abs(nsec*sector_width-360.0)>1e-5: raise ValueError('sector_width_deg must divide 360 exactly.')
    df['_sector']=np.floor(df[cols['azimuth']]/sector_width).astype(int).clip(0,nsec-1)
    scale=float(dcfg.get('range_scale',1000.0)); rr=df[cols['range']].to_numpy(np.float32)/scale; az=np.deg2rad(df[cols['azimuth']].to_numpy(np.float32))
    ecol=cols.get('elevation')
    if ecol and ecol in df.columns:
        el=np.deg2rad(pd.to_numeric(df[ecol],errors='coerce').fillna(0).to_numpy(np.float32)); xy=rr*np.cos(el); xyz=np.stack([xy*np.cos(az),xy*np.sin(az),rr*np.sin(el)],1)
    else: xyz=np.stack([rr*np.cos(az),rr*np.sin(az),np.zeros_like(rr)],1)
    print('[2/7] 建立圈-扇区点集...',flush=True)
    groups={'_feature_dim':len(feature_cols)}
    for (r,s),g in tqdm(df.assign(_x=xyz[:,0],_y=xyz[:,1],_z=xyz[:,2]).groupby(['_round','_sector'],sort=False),desc='groups',unit='组'):
        groups[(int(r),int(s))]=(g[['_x','_y','_z']].to_numpy(np.float32),g[feature_cols].to_numpy(np.float32),g['_label'].to_numpy(np.int64))
    rounds=np.array(sorted(df['_round'].unique()),dtype=np.int64); L=int(dcfg.get('sequence_length',3)); stride=int(dcfg.get('sequence_stride',1)); cons=bool(dcfg.get('require_consecutive_round_ids',True))
    mode=str(scfg.get('mode','auto')).lower(); val_ratio=float(scfg.get('val_ratio',0.15)); train_ratio=float(scfg.get('train_ratio',0.7))
    if mode=='auto': mode='round_isolated' if val_ratio<=0 else 'sample'
    print(f'[3/7] 构造滑窗并划分，mode={mode}, L={L}, stride={stride}',flush=True)
    drop_clutter=bool(dcfg.get('drop_all_clutter_windows',True))
    def build_refs(round_subset):
        refs=[]; removed=0
        for w in _windows(round_subset,L,stride,cons):
            for s in range(nsec):
                anyp=False; pos=0
                for r in w:
                    item=groups.get((int(r),s))
                    if item is not None and len(item[2]): anyp=True; pos+=int((item[2]==1).sum())
                if not anyp: continue
                if drop_clutter and pos==0: removed+=1; continue
                refs.append((w.copy(),s))
        return refs,removed
    if mode=='sample':
        refs,removed=build_refs(rounds); refs_by_split=_split_samples(refs,train_ratio,val_ratio,seed,bool(scfg.get('shuffle_samples',True))); round_partitions=None
    elif mode=='round_isolated':
        round_partitions=_split_rounds(rounds,train_ratio,val_ratio); refs_by_split={}; removed=0
        for name,rrs in round_partitions.items():
            rfs,rm=build_refs(rrs); refs_by_split[name]=rfs; removed+=rm
    else: raise ValueError("split.mode must be 'auto', 'sample', or 'round_isolated'.")
    if not refs_by_split.get('train') or not refs_by_split.get('test'): raise RuntimeError('train/test split has no samples after filtering.')
    print('[4/7] 物化最终基础样本（max_points + 目标优先采样）...',flush=True)
    maxp=int(dcfg.get('max_points_per_frame',0) or 0); material={}
    for name in ('train','val','test'):
        refs=refs_by_split.get(name,[]); material[name]=[]
        for ref in tqdm(refs,desc=f'materialize {name}',unit='样本'):
            material[name].append(_materialize_sample(ref,groups,maxp,seed))
    print('[5/7] 点迹级杂波下采样...',flush=True)
    material['train']=_balance_split(material['train'],seed+101,True)
    if material['val']: material['val']=_balance_split(material['val'],seed+211,True)
    if bool(scfg.get('sample_test_clutter',False)): material['test']=_balance_split(material['test'],seed+307,True)
    print('[6/7] 仅用 train 拟合 feature scaler，并标准化三套数据...',flush=True)
    mean,std=_fit_scaler(material['train'],len(feature_cols))
    for name in ('train','val','test'): _apply_scaler(material[name],mean,std)
    np.savez(outdir/'scaler.npz',feature_mean=mean,feature_std=std,feature_cols=np.asarray(feature_cols,dtype=object))
    stats={name:_stats(material[name]) for name in ('train','val','test')}
    meta={'split_mode':mode,'sequence_length':L,'sequence_stride':stride,'sector_width_deg':sector_width,'max_points_per_frame':maxp,'pure_clutter_removed':removed,'source_csv':str(csv_path)}
    if round_partitions is not None: meta['round_partitions']={k:[int(x) for x in v.tolist()] for k,v in round_partitions.items()}
    print('[7/7] 写出 processed/*.pt ...',flush=True)
    for name in ('train','val','test'):
        if name=='val' and not material[name]:
            p=outdir/'val.pt'
            if p.exists(): p.unlink()
            continue
        torch.save(_to_torch_payload(material[name],feature_cols,mean,std,stats[name],meta),outdir/f'{name}.pt')
    summary={'meta':meta,'stats':stats}
    with open(outdir/'split_summary.json','w',encoding='utf-8') as f: json.dump(summary,f,ensure_ascii=False,indent=2)
    with open(outdir/'resolved_config.json','w',encoding='utf-8') as f: json.dump(config,f,ensure_ascii=False,indent=2)
    print('\n========== PREPARED DATA ==========',flush=True)
    for name in ('train','val','test'):
        s=stats[name]; print(f"{name:<5} samples={s['samples']:,} target={s['target_points']:,} clutter={s['clutter_points']:,} target_ratio={s['target_ratio']:.4f}",flush=True)
    print(f'输出目录: {outdir}',flush=True)
    return summary
