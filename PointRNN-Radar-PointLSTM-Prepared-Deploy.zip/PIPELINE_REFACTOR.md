# 数据处理 / 训练 / 测试 / 部署模拟重构

## 1. 数据处理只做一次

```bash
python data_prepare.py --csv ./data/data.csv --config radar_config.json --output processed
```

生成：
- `processed/train.pt`
- `processed/val.pt`（`val_ratio=0` 时不生成）
- `processed/test.pt`
- `processed/scaler.npz`
- `processed/split_summary.json`

训练与测试之后不再读取或重新处理原始 CSV。

## 2. split.mode

- `auto`：`val_ratio > 0` 时按滑窗样本划分；`val_ratio == 0` 时自动使用 `round_isolated`。
- `sample`：先生成全部滑窗、删除全杂波窗口，再按样本划 train/val/test。
- `round_isolated`：先把原始圈次切成互不重叠的 train/val/test 圈段，再分别在各段内部滑窗，避免原始圈泄漏。

当只使用 train/test 时建议：
```json
"split": {"mode": "auto", "train_ratio": 0.7, "val_ratio": 0.0}
```
此时自动启用圈隔离。

## 3. 训练

```bash
python radar_train.py --data processed --config radar_config.json --output outputs/exp1
```

有 `val.pt`：按 `train.best_metric` 保存 `best.pth`。  
无 `val.pt`：只保存 `last.pth`，绝不使用 test 选择最佳 epoch。

训练集可在读取 `train.pt` 后执行在线数据增强；val/test 不增强。

## 4. 测试

```bash
python radar_test.py --data processed --config radar_config.json --checkpoint outputs/exp1/best.pth
```

无验证集训练时通常使用 `last.pth`。

## 5. 部署模拟

```bash
python radar_deploy_sim.py --csv ./data/data.csv --config radar_config.json --processed processed --checkpoint outputs/exp1/best.pth --output deploy_prediction.csv
```

模拟行为：
1. 原始 CSV 按时间顺序逐行接收。
2. 凑满 `sequence_length` 圈才推理。
3. 第一次凑满 L 圈：给这 L 圈所有点写一次预测。
4. 之后新圈到达：窗口自动丢最旧圈，只给最新圈写预测，避免重复覆盖。
5. 每个 L 圈窗口仍按 `sector_width_deg` 切扇区后组成 `[B,L,T,N]`。
6. 部署完全忽略原始 `label`，不删除纯杂波窗口、不做正负下采样、不做数据增强。
7. 使用训练数据处理阶段保存的 `scaler.npz` 做相同标准化。
8. 输出 CSV 最后一列为 `predicted_label`：1=目标，0=杂波。

部署默认保留全部收到的点（`deployment.max_points_per_frame=0`），保证每一行都由模型获得预测。
