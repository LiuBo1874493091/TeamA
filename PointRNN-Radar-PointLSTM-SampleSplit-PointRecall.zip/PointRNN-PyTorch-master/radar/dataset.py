import hashlib
import json
import pickle
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
from tqdm import tqdm


def _log(message):
    print(message, flush=True)


def _read_csv_with_progress(csv_path, chunksize=200_000):
    """Read a large CSV in chunks so the user sees progress while parsing."""
    _log(f"[数据处理 1/6] 正在读取 CSV：{csv_path}")
    started = time.perf_counter()
    chunks = []
    reader = pd.read_csv(csv_path, chunksize=chunksize)
    total_rows = 0
    for chunk in tqdm(reader, desc="读取 CSV", unit="块", leave=True):
        chunks.append(chunk)
        total_rows += len(chunk)
    if not chunks:
        raise ValueError(f"CSV 文件为空：{csv_path}")
    df = pd.concat(chunks, ignore_index=True)
    _log(f"  已读取 {total_rows:,} 行，耗时 {time.perf_counter() - started:.1f}s")
    return df


def _as_numeric(series, name):
    x = pd.to_numeric(series, errors="coerce")
    if x.isna().all():
        raise ValueError(f"Column {name!r} has no numeric values.")
    return x


def infer_round_ids(azimuth_deg, wrap_drop_deg=180.0):
    """Infer scan-circle IDs from chronological azimuth values by 360->0 wrap."""
    a = np.asarray(azimuth_deg, dtype=np.float64)
    if len(a) == 0:
        return np.zeros(0, dtype=np.int64)
    wrap = (a[1:] - a[:-1]) < -abs(wrap_drop_deg)
    out = np.zeros(len(a), dtype=np.int64)
    out[1:] = np.cumsum(wrap)
    return out


def _cache_signature(csv_path, config):
    """Build a stable signature so stale preprocessing cache is not reused."""
    p = Path(csv_path)
    st = p.stat()
    relevant = {
        "columns": config.get("columns", {}),
        "data": config.get("data", {}),
        "split": config.get("split", {}),
        "train_seed": config.get("train", {}).get("seed", 42),
        "csv_size": st.st_size,
        "csv_mtime_ns": st.st_mtime_ns,
        "cache_version": 3,  # v3: build windows -> drop all-clutter -> sample-level split
    }
    text = json.dumps(relevant, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _default_cache_path(csv_path):
    p = Path(csv_path)
    return p.with_suffix(p.suffix + ".radar_cache.pkl")


def _build_windows(rounds, seq_len, stride, require_consecutive=True):
    windows = []
    if len(rounds) < seq_len:
        return windows
    for start_i in range(0, len(rounds) - seq_len + 1, stride):
        win = rounds[start_i : start_i + seq_len]
        if require_consecutive and np.any(np.diff(win) != 1):
            continue
        windows.append(win.copy())
    return windows


def _select_point_indices(labels, max_points, base_seed, round_id, sector):
    """Deterministic sampling: keep positive points first, then sample clutter."""
    labels = np.asarray(labels)
    n = len(labels)
    if max_points <= 0 or n <= max_points:
        return np.arange(n, dtype=np.int64)

    rng = np.random.default_rng(
        int(base_seed) + int(round_id) * 1_000_003 + int(sector) * 9_176
    )
    pos = np.flatnonzero(labels == 1)
    neg = np.flatnonzero(labels == 0)
    if len(pos) >= max_points:
        chosen = rng.choice(pos, size=max_points, replace=False)
    else:
        n_neg = max_points - len(pos)
        if len(neg):
            chosen_neg = rng.choice(neg, size=min(n_neg, len(neg)), replace=False)
        else:
            chosen_neg = np.empty(0, dtype=np.int64)
        chosen = np.concatenate([pos, chosen_neg])
    return np.sort(chosen.astype(np.int64, copy=False))


def _split_samples(samples, train_ratio, val_ratio, seed, shuffle=True):
    """Split AFTER window construction/filtering, at the sequence-sample level."""
    if not (0 < train_ratio < 1):
        raise ValueError("Require 0 < train_ratio < 1.")
    if not (0 <= val_ratio < 1):
        raise ValueError("Require 0 <= val_ratio < 1.")
    if train_ratio + val_ratio >= 1:
        raise ValueError("Require train_ratio + val_ratio < 1 so test split is non-empty by ratio.")

    n = len(samples)
    order = np.arange(n, dtype=np.int64)
    if shuffle:
        rng = np.random.default_rng(int(seed))
        rng.shuffle(order)

    n_train = int(n * train_ratio)
    n_val = int(n * val_ratio)

    # For sufficiently large datasets, avoid an accidentally empty requested split
    # caused only by floor rounding.
    requested = 1 + int(val_ratio > 0) + 1  # train + optional val + test
    if n >= requested:
        n_train = max(n_train, 1)
        if val_ratio > 0:
            n_val = max(n_val, 1)
        if n_train + n_val >= n:
            # leave at least one test sample
            overflow = n_train + n_val - (n - 1)
            if n_val > int(val_ratio > 0):
                take = min(overflow, n_val - 1)
                n_val -= take
                overflow -= take
            if overflow > 0 and n_train > 1:
                n_train -= min(overflow, n_train - 1)

    train_idx = order[:n_train]
    val_idx = order[n_train : n_train + n_val]
    test_idx = order[n_train + n_val :]

    return {
        "train": [samples[int(i)] for i in train_idx],
        "val": [samples[int(i)] for i in val_idx],
        "test": [samples[int(i)] for i in test_idx],
        "all": list(samples),
    }


def _sample_point_stats(samples, groups, max_points, base_seed):
    """Count points exactly as training sees them (after per-frame cap; padding excluded)."""
    group_count_cache = {}
    target = 0
    clutter = 0
    for rounds, sector in samples:
        for r in rounds:
            key = (int(r), int(sector))
            item = groups.get(key)
            if item is None:
                continue
            if key not in group_count_cache:
                labels = item[2]
                idx = _select_point_indices(labels, max_points, base_seed, key[0], key[1])
                chosen_labels = labels[idx]
                pos = int((chosen_labels == 1).sum())
                neg = int((chosen_labels == 0).sum())
                group_count_cache[key] = (pos, neg)
            pos, neg = group_count_cache[key]
            target += pos
            clutter += neg
    total = target + clutter
    return {
        "samples": int(len(samples)),
        "target_points": int(target),
        "clutter_points": int(clutter),
        "valid_points": int(total),
        "target_ratio": float(target / total) if total else 0.0,
    }


def _print_split_summary(prepared):
    stats = prepared.get("split_stats", {})
    if not stats:
        return
    _log("\n========== 数据集划分统计（按滑窗样本划分；点迹统计忽略 padding） ==========")
    for name in ("train", "val", "test"):
        s = stats.get(name, {})
        _log(
            f"  {name:<5} | 样本={s.get('samples', 0):,} | "
            f"目标点迹(label=1)={s.get('target_points', 0):,} | "
            f"杂波点迹(label=0)={s.get('clutter_points', 0):,} | "
            f"目标占比={100.0 * s.get('target_ratio', 0.0):.3f}%"
        )
    _log("  注意：相邻滑窗中的同一原始点迹会按其在各样本中的出现次数重复计数；这与训练实际看到的点迹次数一致。")
    _log("  Recall 为逐点迹 Recall = TP / (TP + FN)，不是按滑窗样本计算。")
    _log("=======================================================================\n")


class RadarSequenceDataset(Dataset):
    """Radar sequence dataset.

    Current split logic:
      1) Build ALL [L, sector] sliding-window samples from the complete round sequence.
      2) Remove samples whose valid points are all label=0.
      3) Randomly split the remaining samples into train/val/test.

    Metrics remain POINT-WISE; a sequence window is only a sample container.
    """

    def __init__(
        self,
        csv_path,
        config,
        split="train",
        prepared=None,
        cache_path=None,
        rebuild_cache=False,
    ):
        self.csv_path = str(csv_path)
        self.cfg = config
        self.split = split
        if prepared is None:
            self.prepared = self._prepare(
                csv_path,
                config,
                cache_path=cache_path,
                rebuild_cache=rebuild_cache,
            )
        else:
            self.prepared = prepared

        self.groups = self.prepared["groups"]
        self.feature_cols = self.prepared["feature_cols"]
        self.feature_mean = self.prepared["feature_mean"]
        self.feature_std = self.prepared["feature_std"]
        self.samples = self.prepared["samples_by_split"].get(split, [])
        if split != "all" and not self.samples:
            counts = {k: len(v) for k, v in self.prepared["samples_by_split"].items()}
            raise RuntimeError(
                f"No {split} samples built. Sample counts={counts}. "
                "请检查圈数、sequence_length、标签，以及纯杂波样本过滤后是否仍有足够样本。"
            )
        stat = self.prepared.get("split_stats", {}).get(split)
        if stat:
            _log(
                f"[数据处理] {split} 数据集就绪：{len(self.samples):,} 个序列样本；"
                f"目标点迹={stat['target_points']:,}；杂波点迹={stat['clutter_points']:,}；"
                f"特征数={len(self.feature_cols)}"
            )
        else:
            _log(f"[数据处理] {split} 数据集就绪：{len(self.samples):,} 个序列样本；特征数={len(self.feature_cols)}")

    @staticmethod
    def _prepare(csv_path, config, cache_path=None, rebuild_cache=False):
        started = time.perf_counter()
        cache_path = Path(cache_path) if cache_path else _default_cache_path(csv_path)
        signature = _cache_signature(csv_path, config)
        use_cache = bool(config.get("data", {}).get("cache_preprocessed", True))

        if use_cache and cache_path.exists() and not rebuild_cache:
            try:
                _log(f"[缓存] 正在读取预处理缓存：{cache_path}")
                with cache_path.open("rb") as f:
                    obj = pickle.load(f)
                if obj.get("signature") == signature:
                    prepared = obj["prepared"]
                    _log(
                        f"[缓存] 命中，有效缓存加载完成，耗时 {time.perf_counter() - started:.1f}s；无需重新处理 CSV。"
                    )
                    _print_split_summary(prepared)
                    return prepared
                _log("[缓存] 配置或 CSV 已变化，缓存失效，将重新预处理。")
            except Exception as exc:
                _log(f"[缓存] 读取失败，将重新预处理：{exc}")

        df = _read_csv_with_progress(csv_path)
        cols = config["columns"]
        azi_col = cols["azimuth"]
        range_col = cols["range"]
        label_col = cols["label"]
        for c in [azi_col, range_col, label_col]:
            if c not in df.columns:
                raise KeyError(
                    f"Required CSV column {c!r} not found. Available columns: {list(df.columns)}"
                )

        _log("[数据处理 2/6] 正在检查字段、转换数值并生成标签...")
        df = df.copy()
        df["_row_order"] = np.arange(len(df), dtype=np.int64)
        df[azi_col] = _as_numeric(df[azi_col], azi_col) % 360.0
        df[range_col] = _as_numeric(df[range_col], range_col)

        round_col = cols.get("round_id")
        if round_col and round_col in df.columns:
            df["_round"] = pd.to_numeric(df[round_col], errors="raise").astype(np.int64)
        else:
            if round_col:
                _log(f"  提示：配置的圈号列 {round_col!r} 不存在，改为根据方位角回绕推断圈号。")
            df = df.sort_values("_row_order")
            df["_round"] = infer_round_ids(
                df[azi_col].to_numpy(), config["data"].get("wrap_drop_deg", 180.0)
            )

        sector_width = float(config["data"].get("sector_width_deg", 30.0))
        if sector_width <= 0 or abs((360.0 / sector_width) - round(360.0 / sector_width)) > 1e-6:
            raise ValueError("sector_width_deg must be positive and divide 360 exactly in this implementation.")
        n_sectors = int(round(360.0 / sector_width))
        df["_sector"] = (
            np.floor(df[azi_col] / sector_width).astype(np.int64).clip(0, n_sectors - 1)
        )

        positives = set(
            str(v).strip()
            for v in config["data"].get(
                "positive_label_values", [1, "1", True, "true", "target"]
            )
        )
        positives_lower = {v.lower() for v in positives}

        def to_binary_label(v):
            if pd.isna(v):
                return 0
            sv = str(v).strip()
            if sv in positives or sv.lower() in positives_lower:
                return 1
            try:
                return int(float(sv) == 1.0 and ("1" in positives or "1.0" in positives))
            except (ValueError, TypeError):
                return 0

        df["_label"] = df[label_col].map(to_binary_label).astype(np.int64)

        feature_cols = list(cols.get("features", [])) or [range_col, azi_col]
        for c in feature_cols:
            if c not in df.columns:
                raise KeyError(
                    f"Feature column {c!r} not found in CSV. Available columns: {list(df.columns)}"
                )
            df[c] = pd.to_numeric(df[c], errors="coerce")
        df[feature_cols] = df[feature_cols].replace([np.inf, -np.inf], np.nan)
        # Missing-value filling is deterministic. Normalization itself is fitted on train samples below.
        df[feature_cols] = (
            df[feature_cols].fillna(df[feature_cols].median(numeric_only=True)).fillna(0.0)
        )

        elev_col = cols.get("elevation")
        range_scale = float(config["data"].get("range_scale", 1000.0))
        az = np.deg2rad(df[azi_col].to_numpy(np.float32))
        rr = df[range_col].to_numpy(np.float32) / range_scale
        if elev_col and elev_col in df.columns:
            elev = np.deg2rad(
                pd.to_numeric(df[elev_col], errors="coerce")
                .fillna(0)
                .to_numpy(np.float32)
            )
            xy = rr * np.cos(elev)
            df["_x"] = xy * np.cos(az)
            df["_y"] = xy * np.sin(az)
            df["_z"] = rr * np.sin(elev)
        else:
            df["_x"] = rr * np.cos(az)
            df["_y"] = rr * np.sin(az)
            df["_z"] = 0.0

        rounds = np.array(sorted(df["_round"].unique()), dtype=np.int64)
        seq_len = int(config["data"].get("sequence_length", 8))
        stride = int(config["data"].get("sequence_stride", 1))
        if seq_len < 1 or stride < 1:
            raise ValueError("sequence_length and sequence_stride must be >= 1.")

        _log(
            f"  字段处理完成：{len(df):,} 行；总圈数={len(rounds):,}；"
            f"真实点={int(df['_label'].sum()):,}，杂波点={int((df['_label'] == 0).sum()):,}"
        )

        _log("[数据处理 3/6] 正在按圈号和扇区建立原始点集缓存...")
        raw_groups = {}
        grouped = df.groupby(["_round", "_sector"], sort=False)
        for (r, s), g in tqdm(
            grouped, total=grouped.ngroups, desc="建立圈-扇区点集", unit="组", leave=True
        ):
            xyz = g[["_x", "_y", "_z"]].to_numpy(np.float32)
            feat = g[feature_cols].to_numpy(np.float32)
            lab = g["_label"].to_numpy(np.int64)
            raw_groups[(int(r), int(s))] = (xyz, feat, lab)

        _log(
            f"[数据处理 4/6] 先生成全部滑窗：L={seq_len}, stride={stride}, "
            f"扇区数={n_sectors}..."
        )
        require_consecutive = bool(config["data"].get("require_consecutive_round_ids", True))
        windows = _build_windows(rounds, seq_len, stride, require_consecutive)
        candidate_samples = []
        pure_clutter_removed = 0
        empty_removed = 0
        drop_all_clutter = bool(config["data"].get("drop_all_clutter_windows", True))

        for win in tqdm(windows, desc="生成/过滤滑窗样本", unit="窗", leave=True):
            for sector in range(n_sectors):
                has_any_point = False
                positive_count = 0
                for r in win:
                    item = raw_groups.get((int(r), sector))
                    if item is None:
                        continue
                    has_any_point = has_any_point or len(item[2]) > 0
                    positive_count += int((item[2] == 1).sum())
                if not has_any_point:
                    empty_removed += 1
                    continue
                if drop_all_clutter and positive_count == 0:
                    pure_clutter_removed += 1
                    continue
                candidate_samples.append((win.copy(), int(sector)))

        _log(
            f"  原始滑窗×扇区候选={len(windows) * n_sectors:,}；"
            f"空样本剔除={empty_removed:,}；纯杂波样本剔除={pure_clutter_removed:,}；"
            f"保留含目标样本={len(candidate_samples):,}"
        )
        if not candidate_samples:
            raise RuntimeError(
                "过滤纯杂波样本后没有剩余样本。请检查 label 配置、positive_label_values、"
                "sequence_length 或数据本身。"
            )

        _log("[数据处理 5/6] 对保留的滑窗样本进行 train/val/test 划分...")
        train_ratio = float(config["split"].get("train_ratio", 0.7))
        val_ratio = float(config["split"].get("val_ratio", 0.15))
        split_seed = int(config.get("train", {}).get("seed", 42))
        shuffle_samples = bool(config["split"].get("shuffle_samples", True))
        samples_by_split = _split_samples(
            candidate_samples,
            train_ratio=train_ratio,
            val_ratio=val_ratio,
            seed=split_seed,
            shuffle=shuffle_samples,
        )
        if not samples_by_split["train"]:
            raise RuntimeError("Training split is empty after sample-level split.")

        # Fit feature normalization using raw groups referenced by TRAIN samples.
        train_group_keys = set()
        for win, sector in samples_by_split["train"]:
            for r in win:
                key = (int(r), int(sector))
                if key in raw_groups:
                    train_group_keys.add(key)
        count = 0
        feat_sum = np.zeros(len(feature_cols), dtype=np.float64)
        feat_sumsq = np.zeros(len(feature_cols), dtype=np.float64)
        for key in train_group_keys:
            f = raw_groups[key][1].astype(np.float64, copy=False)
            if len(f) == 0:
                continue
            feat_sum += f.sum(axis=0)
            feat_sumsq += np.square(f).sum(axis=0)
            count += len(f)
        if count <= 0:
            raise RuntimeError("Training samples contain no valid feature points.")
        feature_mean = (feat_sum / count).astype(np.float32)
        variance = np.maximum(feat_sumsq / count - np.square(feature_mean.astype(np.float64)), 0.0)
        feature_std = np.sqrt(variance).astype(np.float32)
        feature_std[feature_std < 1e-6] = 1.0

        groups = {}
        for key, (xyz, feat, lab) in raw_groups.items():
            feat_norm = ((feat - feature_mean) / feature_std).astype(np.float32)
            groups[key] = (xyz, feat_norm, lab)

        _log("[数据处理 6/6] 正在统计各数据集实际参与训练的目标/杂波点迹数...")
        max_points = int(config["data"].get("max_points_per_frame", 0) or 0)
        base_seed = int(config.get("train", {}).get("seed", 42))
        split_stats = {}
        for name in ("train", "val", "test"):
            split_stats[name] = _sample_point_stats(
                samples_by_split[name], groups, max_points, base_seed
            )

        prepared = {
            "groups": groups,
            "feature_cols": feature_cols,
            "feature_mean": feature_mean,
            "feature_std": feature_std,
            "samples_by_split": samples_by_split,
            "split_stats": split_stats,
            "n_sectors": n_sectors,
            "sector_width_deg": sector_width,
            "sequence_length": seq_len,
            "sequence_stride": stride,
            "filter_stats": {
                "raw_windows": int(len(windows)),
                "raw_window_sector_candidates": int(len(windows) * n_sectors),
                "empty_removed": int(empty_removed),
                "pure_clutter_removed": int(pure_clutter_removed),
                "kept_samples": int(len(candidate_samples)),
            },
            "split_policy": "build_all_windows_then_drop_all_clutter_then_split_samples",
        }

        _print_split_summary(prepared)

        if use_cache:
            try:
                _log(f"[缓存] 正在保存预处理结果：{cache_path}")
                cache_path.parent.mkdir(parents=True, exist_ok=True)
                with cache_path.open("wb") as f:
                    pickle.dump(
                        {"signature": signature, "prepared": prepared},
                        f,
                        protocol=pickle.HIGHEST_PROTOCOL,
                    )
                _log("[缓存] 保存完成。后续使用相同 CSV 和配置训练时可直接加载。")
            except Exception as exc:
                _log(f"[缓存] 保存失败，但不影响本次训练：{exc}")

        elapsed = time.perf_counter() - started
        _log(
            f"[数据处理完成] 总耗时 {elapsed:.1f}s；样本数="
            + ", ".join(
                f"{k}:{len(v):,}" for k, v in samples_by_split.items() if k != "all"
            )
        )
        return prepared

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        rounds, sector = self.samples[idx]
        xyz_seq, feat_seq, label_seq = [], [], []
        max_points = int(self.cfg["data"].get("max_points_per_frame", 0) or 0)
        base_seed = int(self.cfg.get("train", {}).get("seed", 42))
        for r in rounds:
            item = self.groups.get((int(r), int(sector)))
            if item is None:
                xyz_seq.append(np.zeros((0, 3), np.float32))
                feat_seq.append(np.zeros((0, len(self.feature_cols)), np.float32))
                label_seq.append(np.zeros((0,), np.int64))
                continue

            xyz, feat, lab = item
            chosen = _select_point_indices(lab, max_points, base_seed, int(r), int(sector))
            xyz_out, feat_out, lab_out = xyz[chosen], feat[chosen], lab[chosen]
            xyz_seq.append(xyz_out)
            feat_seq.append(feat_out)
            label_seq.append(lab_out)

        # Defensive invariant: all retained samples must still contain >=1 positive point
        # after max_points sampling (the sampler preserves positives first).
        if sum(int((y == 1).sum()) for y in label_seq) <= 0:
            raise RuntimeError(
                f"Internal invariant broken: retained sample idx={idx}, sector={sector}, rounds={rounds.tolist()} "
                "contains no positive points after sampling."
            )

        return {
            "xyz": xyz_seq,
            "features": feat_seq,
            "labels": label_seq,
            "rounds": rounds.astype(np.int64),
            "sector": int(sector),
        }


def radar_collate_fn(batch):
    if batch is None or len(batch) == 0:
        raise ValueError("radar_collate_fn received an empty batch.")
    B = len(batch)
    required = {"xyz", "features", "labels", "rounds", "sector"}
    for bi, item in enumerate(batch):
        missing = required - set(item.keys())
        if missing:
            raise KeyError(f"batch[{bi}] missing keys: {sorted(missing)}")
        if not (len(item["xyz"]) == len(item["features"]) == len(item["labels"])):
            raise ValueError(
                f"batch[{bi}] sequence length mismatch: xyz={len(item['xyz'])}, "
                f"features={len(item['features'])}, labels={len(item['labels'])}"
            )
    L = len(batch[0]["xyz"])
    if L <= 0:
        raise ValueError("Sequence length L must be > 0.")
    if any(len(item["xyz"]) != L for item in batch):
        raise ValueError("All samples in a batch must have the same sequence length L.")

    F = None
    for bi, item in enumerate(batch):
        for ti, (x, f, y) in enumerate(zip(item["xyz"], item["features"], item["labels"])):
            x = np.asarray(x)
            f = np.asarray(f)
            y = np.asarray(y)
            if x.ndim != 2 or x.shape[1] != 3:
                raise ValueError(f"batch[{bi}] frame[{ti}] xyz must be [n,3], got {x.shape}")
            if f.ndim != 2:
                raise ValueError(f"batch[{bi}] frame[{ti}] features must be [n,F], got {f.shape}")
            if y.ndim != 1:
                raise ValueError(f"batch[{bi}] frame[{ti}] labels must be [n], got {y.shape}")
            if not (len(x) == len(f) == len(y)):
                raise ValueError(
                    f"batch[{bi}] frame[{ti}] point-count mismatch: xyz={len(x)}, features={len(f)}, labels={len(y)}"
                )
            if F is None:
                F = f.shape[1]
            elif f.shape[1] != F:
                raise ValueError(
                    f"Feature dimension mismatch: expected F={F}, got F={f.shape[1]} at sample={bi}, frame={ti}"
                )
            if x.size and not np.isfinite(x).all():
                raise ValueError(f"NaN/Inf found in xyz at sample={bi}, frame={ti}")
            if f.size and not np.isfinite(f).all():
                raise ValueError(f"NaN/Inf found in features at sample={bi}, frame={ti}")
            if y.size:
                bad = y[(y != 0) & (y != 1)]
                if bad.size:
                    raise ValueError(
                        f"Labels must be 0/1 before padding; found {np.unique(bad)[:20].tolist()} at sample={bi}, frame={ti}"
                    )
    if F is None or F <= 0:
        raise ValueError(f"Feature dimension F must be > 0, got {F}")

    T = max(max((len(frame) for frame in item["xyz"]), default=0) for item in batch)
    if T <= 0:
        raise ValueError("Entire collated batch contains zero radar points. Check split/sector/sample construction.")
    xyz = torch.zeros(B, L, T, 3, dtype=torch.float32)
    features = torch.zeros(B, L, T, F, dtype=torch.float32)
    labels = torch.full((B, L, T), -100, dtype=torch.long)
    mask = torch.zeros(B, L, T, dtype=torch.bool)
    sectors = torch.tensor([b["sector"] for b in batch], dtype=torch.long)
    try:
        rounds = torch.stack(
            [torch.from_numpy(np.asarray(b["rounds"], dtype=np.int64)) for b in batch]
        )
    except Exception as exc:
        raise ValueError(
            f"Failed to stack round ids; all samples must have exactly L={L} rounds: {exc}"
        ) from exc

    for b, item in enumerate(batch):
        for t in range(L):
            n = len(item["xyz"][t])
            if n == 0:
                continue
            if n > T:
                raise RuntimeError(
                    f"Internal collate error: n={n} exceeds allocated T={T} at sample={b}, frame={t}"
                )
            xyz[b, t, :n] = torch.as_tensor(item["xyz"][t], dtype=torch.float32)
            features[b, t, :n] = torch.as_tensor(item["features"][t], dtype=torch.float32)
            labels[b, t, :n] = torch.as_tensor(item["labels"][t], dtype=torch.long)
            mask[b, t, :n] = True

    if not mask.any():
        raise ValueError("Entire collated batch is padding.")
    if not torch.isfinite(xyz).all() or not torch.isfinite(features).all():
        raise ValueError("NaN/Inf appeared after collate conversion.")
    if (labels[mask] < 0).any() or (labels[mask] > 1).any():
        raise ValueError(
            f"Valid labels after collate must be 0/1, got {torch.unique(labels[mask]).tolist()}"
        )
    if not (labels[~mask] == -100).all():
        raise RuntimeError("Padding label invariant broken: all padding labels must be -100.")
    return {
        "xyz": xyz,
        "features": features,
        "labels": labels,
        "mask": mask,
        "rounds": rounds,
        "sector": sectors,
    }


def load_config(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)
