from __future__ import annotations

import itertools
import threading
import queue

from matplotlib.figure import Figure

from .buffer import SlidingRoundBuffer
from .config import ViewerConfig


class RadarTrackViewer:
    def __init__(self, buffer: SlidingRoundBuffer, config: ViewerConfig):
        self.buffer = buffer
        self.config = config
        # 不依赖 pyplot/IDE 选择的后端；由 Tk 主循环持有独立窗口。
        import tkinter as tk
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk

        try:
            self.root = tk.Tk()
        except tk.TclError as exc:
            raise RuntimeError("无法创建桌面窗口。请在本机桌面终端运行；使用 python -m tkinter 检查 Tk。") from exc
        self.root.title("Radar Track Viewer")
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.fig = Figure(figsize=config.figure_size)
        self.ax = self.fig.add_subplot(111)
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.root)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        self.toolbar = NavigationToolbar2Tk(self.canvas, self.root)
        self.toolbar.update()
        tk.Label(self.root, text="Terminal: Enter = next | p + Enter = previous | q + Enter = quit").pack()
        self._busy = False
        self._closed = False
        self._commands = queue.Queue(maxsize=1)
        self._handled = threading.Event()

    def run(self) -> None:
        try:
            print("正在读取首个窗口，请稍候……", flush=True)
            if not self.buffer.initialize():
                raise ValueError(f"有效圈数不足 {self.config.window_size} 圈，无法形成窗口")
            self._draw()
            self.canvas.draw()
            print("请切回终端输入；p 回看，q 退出。", flush=True)
            threading.Thread(target=self._read_input, daemon=True).start()
            self.root.after(50, self._poll_input)
            self.root.mainloop()
        finally:
            self.close()

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._handled.set()
        try:
            self.root.quit()
            self.root.destroy()
        finally:
            close = getattr(self.buffer.round_iter, "close", None)
            if close:
                close()

    def _read_input(self) -> None:
        # input 会阻塞，因此放在线程中；所有绘图及 CSV 操作留在主线程。
        while not self._closed:
            try:
                command = input("按 Enter 查看下一窗口...").strip().lower()
            except (EOFError, OSError):
                print("\n输入已结束，正在退出。", flush=True)
                command = "q"
            self._handled.clear()
            self._commands.put(command)
            self._handled.wait()
            if command in ("q", "quit", "exit"):
                return

    def _poll_input(self) -> None:
        if self._closed:
            return
        try:
            command = self._commands.get_nowait()
        except queue.Empty:
            pass
        else:
            try:
                if command in ("q", "quit", "exit"):
                    self.close()
                elif command in ("", "n", "next"):
                    self._navigate(True)
                elif command in ("p", "prev", "previous"):
                    self._navigate(False)
                else:
                    print("无效输入：直接 Enter 前进，p + Enter 回看，q + Enter 退出。", flush=True)
            finally:
                self._handled.set()
        if not self._closed:
            self.root.after(50, self._poll_input)

    def _navigate(self, forward: bool) -> None:
        if self._closed or self._busy:
            return
        self._busy = True
        try:
            moved = self.buffer.next_window() if forward else self.buffer.previous_window()
            if moved:
                self._draw()
            else:
                self._show_status("已到文件末尾" if forward else "已到缓存最早位置")
        except Exception:
            import logging
            from tkinter import messagebox
            logging.exception("滑动窗口失败")
            messagebox.showerror("读取失败", "滑动窗口失败，详细原因见 error.log", parent=self.root)
        finally:
            self._busy = False

    def _show_status(self, message: str) -> None:
        print(message, flush=True)
        self.ax.set_xlabel(message)
        self.fig.canvas.draw_idle()

    def _draw(self) -> None:
        window = self.buffer.current_window()
        if not window:
            return

        # 保留用户缩放/平移后的视野会让翻页后更方便对比。
        old_xlim = self.ax.get_xlim()
        old_ylim = self.ax.get_ylim()
        had_data = self.ax.has_data()

        self.ax.clear()

        markers = itertools.cycle(["o", "^", "s", "D", "x", "+", "v", "<", ">"])
        n = len(window)
        total_points = 0

        for i, round_data in enumerate(window):
            x, y = round_data.xy()
            total_points += round_data.point_count

            # 越新的圈越明显。颜色交给 Matplotlib 默认色循环处理。
            alpha = 0.25 + 0.75 * (i + 1) / n
            self.ax.scatter(
                x,
                y,
                s=self.config.point_size,
                alpha=alpha,
                marker=next(markers),
                label=f"圈 {round_data.round_id} ({round_data.point_count} 点)",
            )

        print("当前窗口圈号：" + ", ".join(str(r.round_id) for r in window), flush=True)
        first_id = window[0].round_id
        last_id = window[-1].round_id
        self.ax.set_title(
            f"雷达点迹滑动窗口 | 圈 {first_id} → {last_id} | "
            f"{n} 圈 / {total_points} 点"
        )
        self.ax.set_xlabel("X")
        self.ax.set_ylabel("Y")
        self.ax.legend(loc="best")
        self.ax.grid(self.config.show_grid)

        if self.config.equal_axis:
            self.ax.set_aspect("equal", adjustable="datalim")

        if had_data:
            self.ax.set_xlim(old_xlim)
            self.ax.set_ylim(old_ylim)

        self.fig.canvas.draw_idle()
