# 雷达点迹查看器：终端 input 版

修改 config.json 的 csv_path，列号默认：距离15、角度16、圈数45（从1开始）。
CSV 第一行标题，按圈顺序排列。默认3圈窗口、缓存20圈，均可配置。

## 运行

```bash
python -m pip install -r requirements.txt
python main.py
```

Windows 也可双击 start_windows.bat。建议在终端运行；使用 IDE 时，请选择支持标准输入的运行控制台。

显示独立 Matplotlib 图形窗口后，切回终端：

- 直接按 Enter：下一窗口。
- 输入 p 再 Enter：缓存内上一窗口。
- 输入 q 再 Enter：退出。
- 到达文件末尾后继续显示最后窗口，仍可回看或退出。
- 关闭图形窗口也可退出。

程序实际调用 input("按 Enter 查看下一窗口...")，输入等待在线程中执行，
Tk 主线程维持图形刷新和缩放平移。只有收到前进命令才向后读取数据。
不依赖 pyplot 或 IDE 默认绘图后端。

依赖 Python 3.10+ 及 Tcl/Tk（可运行 python -m tkinter 检查）。
如缺失 Tk，使用 Python 安装器补装 Tcl/Tk；不要 pip install tkinter。
异常信息见终端及程序目录 error.log。

## 验证

跨 chunk 拼圈、滑窗、缓存及终端命令分发测试已通过。
当前环境无可连接桌面服务，未实测 Windows Tk 图形窗口。

```bash
python -m unittest discover -s tests
```
