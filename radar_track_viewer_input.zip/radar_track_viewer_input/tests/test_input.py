import queue
import threading
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch
from test_core import build_csv
from radar_viewer.config import ViewerConfig
from radar_viewer.reader import RadarCSVReader
from radar_viewer.buffer import SlidingRoundBuffer
from radar_viewer.viewer import RadarTrackViewer

class InputTest(unittest.TestCase):
    def test_input_producer(self):
        v = RadarTrackViewer.__new__(RadarTrackViewer)
        v._closed = False
        v._commands = queue.Queue(maxsize=1)
        v._handled = threading.Event()
        with patch('builtins.input', side_effect=['', 'p', 'q']) as ask:
            worker = threading.Thread(target=v._read_input, daemon=True)
            worker.start()
            for expected in ['', 'p', 'q']:
                self.assertEqual(v._commands.get(timeout=2), expected)
                v._handled.set()
            worker.join(timeout=2)
            self.assertFalse(worker.is_alive())
            ask.assert_called_with('按 Enter 查看下一窗口...')

    def test_eof(self):
        v = RadarTrackViewer.__new__(RadarTrackViewer)
        v._closed = False
        v._commands = queue.Queue(maxsize=1)
        v._handled = threading.Event()
        with patch('builtins.input', side_effect=EOFError):
            worker = threading.Thread(target=v._read_input, daemon=True)
            worker.start()
            self.assertEqual(v._commands.get(timeout=2), 'q')
            v._handled.set()
            worker.join(timeout=2)
            self.assertFalse(worker.is_alive())

    def test_commands_cache_and_eof(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'sample.csv'
            build_csv(path)
            cfg = ViewerConfig(csv_path=path, chunksize=4, cache_rounds=4)
            v = RadarTrackViewer.__new__(RadarTrackViewer)
            v.buffer = SlidingRoundBuffer(RadarCSVReader(cfg).iter_rounds(),3,4)
            self.assertTrue(v.buffer.initialize())
            v._closed = v._busy = False
            v._commands = queue.Queue(maxsize=1)
            v._handled = threading.Event()
            v.root = Mock()
            v._draw = Mock()
            v._show_status = Mock()
            for command, ids in [('',[2,3,4]),('p',[1,2,3]),('',[2,3,4]),
                                 ('',[3,4,5]),('',[4,5,6]),('',[4,5,6]),
                                 ('p',[3,4,5]),('p',[3,4,5]),('bad',[3,4,5])]:
                v._commands.put(command)
                v._poll_input()
                self.assertEqual([int(r.round_id) for r in v.buffer.current_window()],ids)
            v._commands.put('q')
            v._poll_input()
            self.assertTrue(v._closed)
            v.root.destroy.assert_called_once()
