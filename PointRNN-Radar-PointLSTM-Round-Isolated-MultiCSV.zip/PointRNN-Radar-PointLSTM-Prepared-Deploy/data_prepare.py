import argparse
from radar.dataset import load_config
from radar.preprocess import prepare_data

if __name__=='__main__':
    ap=argparse.ArgumentParser(description='Prepare train/val/test radar sequence files once.')
    ap.add_argument('--input', '--csv', dest='csv', required=True)
    ap.add_argument('--config',default='radar_config.json')
    ap.add_argument('--output',default='processed')
    args=ap.parse_args()
    prepare_data(args.csv,load_config(args.config),args.output)
