from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json


@dataclass(frozen=True)
class ViewerConfig:
    csv_path: Path
    chunksize: int = 100_000
    window_size: int = 3
    cache_rounds: int = 20

    # 这里按“人类习惯的第N列”填写，内部会转换为0-based。
    distance_col_index: int = 15
    azimuth_col_index: int = 16
    round_col_index: int = 45

    encoding: str = "utf-8-sig"
    delimiter: str = ","
    skip_bad_rows: bool = True
    drop_invalid_points: bool = True

    figure_size: tuple[float, float] = (10.0, 10.0)
    point_size: float = 10.0
    equal_axis: bool = True
    show_grid: bool = True

    @property
    def distance_idx0(self) -> int:
        return self.distance_col_index - 1

    @property
    def azimuth_idx0(self) -> int:
        return self.azimuth_col_index - 1

    @property
    def round_idx0(self) -> int:
        return self.round_col_index - 1

    @property
    def required_max_index0(self) -> int:
        return max(self.distance_idx0, self.azimuth_idx0, self.round_idx0)

    @staticmethod
    def from_json(path: str | Path) -> "ViewerConfig":
        path = Path(path).resolve()
        raw = json.loads(path.read_text(encoding="utf-8"))
        raw["csv_path"] = (path.parent / raw["csv_path"]).resolve()
        if "figure_size" in raw:
            raw["figure_size"] = tuple(raw["figure_size"])
        cfg = ViewerConfig(**raw)
        cfg.validate()
        return cfg

    def validate(self) -> None:
        if self.chunksize <= 0:
            raise ValueError("chunksize 必须 > 0")
        if self.window_size <= 0:
            raise ValueError("window_size 必须 > 0")
        if self.cache_rounds < self.window_size:
            raise ValueError("cache_rounds 必须 >= window_size")
        for name, value in (
            ("distance_col_index", self.distance_col_index),
            ("azimuth_col_index", self.azimuth_col_index),
            ("round_col_index", self.round_col_index),
        ):
            if value <= 0:
                raise ValueError(f"{name} 必须从 1 开始计数")
