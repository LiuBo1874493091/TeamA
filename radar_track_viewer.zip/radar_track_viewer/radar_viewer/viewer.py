from __future__ import annotations

import itertools
import threading

import matplotlib.pyplot as plt

from .buffer import SlidingRoundBuffer
from .config import ViewerConfig


class RadarTrackViewer:
    def __init__(self, buffer: SlidingRoundBuffer, config: ViewerConfig):
        self.buffer = buffer
        self.config = config
        self.fig, self.ax = plt.subplots(figsize=config.figure_size)
        self._busy = False
        self._closed = False

        self.fig.canvas.mpl_connect("key_press_event", self._on_key)
        self.fig.canvas.mpl_connect("close_event", self._on_close)

    def run(self) -> None:
        if not self.buffer.initialize():
            raise ValueError(
                f"完整有效圈数不足 {self.config.window_size} 圈，无法形成一个滑动窗口"
            )
        self._draw()
        plt.show()

    def _on_close(self, _event) -> None:
        self._closed = True

    def _on_key(self, event) -> None:
        if self._closed or self._busy:
            return

        key = (event.key or "").lower()

        if key in ("q", "escape"):
            plt.close(self.fig)
            return

        if key in ("enter", "right"):
            self._busy = True
            try:
                moved = self.buffer.next_window()
                if moved:
                    self._draw()
                else:
                    self._show_status("已经到达文件末尾，无法继续向后滑动")
            finally:
                self._busy = False
            return

        if key == "left":
            self._busy = True
            try:
                moved = self.buffer.previous_window()
                if moved:
                    self._draw()
                else:
                    self._show_status("已到当前缓存最早位置，无法继续向前回退")
            finally:
                self._busy = False

    def _show_status(self, message: str) -> None:
        self.ax.set_xlabel(message)
        self.fig.canvas.draw_idle()

    def _draw(self) -> None:
        window = self.buffer.current_window()
        if not window:
            return

        # 保留用户缩放/平移后的视野会让翻页后更方便对比。
        old_xlim = self.ax.get_xlim()
        old_ylim = self.ax.get_ylim()
        had_data = self.ax.has_data()

        self.ax.clear()

        markers = itertools.cycle(["o", "^", "s", "D", "x", "+", "v", "<", ">"])
        n = len(window)
        total_points = 0

        for i, round_data in enumerate(window):
            x, y = round_data.xy()
            total_points += round_data.point_count

            # 越新的圈越明显。颜色交给 Matplotlib 默认色循环处理。
            alpha = 0.25 + 0.75 * (i + 1) / n
            self.ax.scatter(
                x,
                y,
                s=self.config.point_size,
                alpha=alpha,
                marker=next(markers),
                label=f"圈 {round_data.round_id} ({round_data.point_count} 点)",
            )

        first_id = window[0].round_id
        last_id = window[-1].round_id
        self.ax.set_title(
            f"雷达点迹滑动窗口 | 圈 {first_id} → {last_id} | "
            f"{n} 圈 / {total_points} 点"
        )
        self.ax.set_xlabel("X")
        self.ax.set_ylabel("Y")
        self.ax.legend(loc="best")
        self.ax.grid(self.config.show_grid)

        if self.config.equal_axis:
            self.ax.set_aspect("equal", adjustable="datalim")

        if had_data:
            self.ax.set_xlim(old_xlim)
            self.ax.set_ylim(old_ylim)

        self.fig.canvas.manager.set_window_title("Radar Track Viewer")
        self.fig.canvas.draw_idle()
