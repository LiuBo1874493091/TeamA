from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterator, Optional

import numpy as np
import pandas as pd

from .config import ViewerConfig


@dataclass
class RoundData:
    round_id: object
    distance: np.ndarray
    azimuth_deg: np.ndarray

    @property
    def point_count(self) -> int:
        return int(self.distance.size)

    def xy(self) -> tuple[np.ndarray, np.ndarray]:
        rad = np.deg2rad(self.azimuth_deg)
        x = self.distance * np.cos(rad)
        y = self.distance * np.sin(rad)
        return x, y


class RadarCSVReader:
    """
    流式读取 CSV，并把可能跨 chunk 的同一圈重新拼接成完整 RoundData。

    重要假设：
    1. CSV 第一行为标题。
    2. 文件已经按 round 列排序。
    3. 同一个 round 的行在文件中连续出现。
    """

    def __init__(self, config: ViewerConfig):
        self.config = config

    def _check_header(self) -> None:
        csv_path = self.config.csv_path
        if not csv_path.exists():
            raise FileNotFoundError(f"CSV 文件不存在: {csv_path}")
        if csv_path.stat().st_size == 0:
            raise ValueError("CSV 文件为空")

        header = pd.read_csv(
            csv_path,
            nrows=0,
            encoding=self.config.encoding,
            sep=self.config.delimiter,
        )
        if len(header.columns) <= self.config.required_max_index0:
            raise ValueError(
                f"CSV 只有 {len(header.columns)} 列，但配置至少需要 "
                f"{self.config.required_max_index0 + 1} 列"
            )

    @staticmethod
    def _same_round(a: object, b: object) -> bool:
        if pd.isna(a) or pd.isna(b):
            return False
        return a == b

    def iter_rounds(self) -> Iterator[RoundData]:
        self._check_header()

        on_bad_lines = "skip" if self.config.skip_bad_rows else "error"

        usecols = [
            self.config.distance_idx0,
            self.config.azimuth_idx0,
            self.config.round_idx0,
        ]

        reader = pd.read_csv(
            self.config.csv_path,
            usecols=usecols,
            chunksize=self.config.chunksize,
            encoding=self.config.encoding,
            sep=self.config.delimiter,
            on_bad_lines=on_bad_lines,
            low_memory=True,
        )

        carry: Optional[pd.DataFrame] = None
        last_emitted_round = None

        for chunk in reader:
            if chunk.empty:
                continue

            chunk.columns = ["distance", "azimuth", "round_id"]

            if carry is not None and not carry.empty:
                chunk = pd.concat([carry, chunk], ignore_index=True)
                carry = None

            # round_id 为空无法可靠判断边界，直接丢弃。
            chunk = chunk[chunk["round_id"].notna()]
            if chunk.empty:
                continue

            # 文件已按圈排序，因此最后一圈可能是不完整圈，保留到下一个 chunk。
            last_round = chunk["round_id"].iloc[-1]
            mask_last = chunk["round_id"].eq(last_round)
            carry = chunk.loc[mask_last].copy()
            complete = chunk.loc[~mask_last]

            if not complete.empty:
                for round_id, group in complete.groupby("round_id", sort=False):
                    if last_emitted_round is not None and round_id == last_emitted_round:
                        # 理论上不应出现；保护性处理。
                        continue
                    rd = self._group_to_round(round_id, group)
                    if rd is not None:
                        yield rd
                        last_emitted_round = round_id

        if carry is not None and not carry.empty:
            round_id = carry["round_id"].iloc[0]
            rd = self._group_to_round(round_id, carry)
            if rd is not None:
                yield rd

    def _group_to_round(self, round_id: object, group: pd.DataFrame) -> Optional[RoundData]:
        distance = pd.to_numeric(group["distance"], errors="coerce")
        azimuth = pd.to_numeric(group["azimuth"], errors="coerce")

        valid = np.isfinite(distance.to_numpy(dtype=float, na_value=np.nan))
        valid &= np.isfinite(azimuth.to_numpy(dtype=float, na_value=np.nan))

        if self.config.drop_invalid_points:
            distance = distance[valid]
            azimuth = azimuth[valid]
        elif not valid.all():
            raise ValueError(f"圈 {round_id} 中存在非法距离/角度值")

        if len(distance) == 0:
            return None

        azimuth_np = np.mod(azimuth.to_numpy(dtype=np.float64), 360.0)
        distance_np = distance.to_numpy(dtype=np.float64)

        return RoundData(
            round_id=round_id,
            distance=distance_np,
            azimuth_deg=azimuth_np,
        )
