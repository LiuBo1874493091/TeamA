from __future__ import annotations

from collections import deque
from typing import Deque, Iterator, List, Optional

from .reader import RoundData


class SlidingRoundBuffer:
    """
    方案B：
    - 只从 CSV 顺序向前读取；
    - 内存缓存最近 cache_rounds 圈；
    - 当前窗口大小为 window_size；
    - 可以在缓存范围内向前/向后浏览。
    """

    def __init__(
        self,
        round_iter: Iterator[RoundData],
        window_size: int,
        cache_rounds: int,
    ):
        self.round_iter = round_iter
        self.window_size = window_size
        self.cache_rounds = cache_rounds
        self.cache: Deque[RoundData] = deque()
        self.window_start = 0
        self.exhausted = False

    def initialize(self) -> bool:
        while len(self.cache) < self.window_size and not self.exhausted:
            self._read_one()
        self.window_start = 0
        return len(self.cache) >= self.window_size

    def current_window(self) -> List[RoundData]:
        end = self.window_start + self.window_size
        if end > len(self.cache):
            return []
        data = list(self.cache)
        return data[self.window_start:end]

    def next_window(self) -> bool:
        desired_start = self.window_start + 1
        desired_end = desired_start + self.window_size

        while desired_end > len(self.cache) and not self.exhausted:
            self._read_one()

        if desired_end <= len(self.cache):
            self.window_start = desired_start
            self._trim_left_if_needed()
            return True
        return False

    def previous_window(self) -> bool:
        if self.window_start > 0:
            self.window_start -= 1
            return True
        return False

    @property
    def can_previous(self) -> bool:
        return self.window_start > 0

    @property
    def can_next_cached_or_stream(self) -> bool:
        if self.window_start + self.window_size < len(self.cache):
            return True
        return not self.exhausted

    def _read_one(self) -> Optional[RoundData]:
        if self.exhausted:
            return None
        try:
            item = next(self.round_iter)
        except StopIteration:
            self.exhausted = True
            return None
        self.cache.append(item)
        return item

    def _trim_left_if_needed(self) -> None:
        """
        保证最多缓存 cache_rounds 圈。
        删除左侧旧圈时同步调整 window_start。
        当前窗口绝不会被删掉。
        """
        while len(self.cache) > self.cache_rounds:
            if self.window_start <= 0:
                break
            self.cache.popleft()
            self.window_start -= 1
