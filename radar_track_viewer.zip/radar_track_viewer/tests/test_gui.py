"""桌面环境运行：python -m unittest discover -s tests -p test_gui.py"""
import os
import tempfile
import unittest
from pathlib import Path
from test_core import build_csv
from radar_viewer.config import ViewerConfig
from radar_viewer.reader import RadarCSVReader
from radar_viewer.buffer import SlidingRoundBuffer
from radar_viewer.viewer import RadarTrackViewer

class GuiTest(unittest.TestCase):
    def test_native_keys_and_mainloop(self):
        os.environ['MPLBACKEND'] = 'Agg'
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'test.csv'
            build_csv(path)
            cfg = ViewerConfig(csv_path=path, chunksize=4, cache_rounds=4)
            buf = SlidingRoundBuffer(RadarCSVReader(cfg).iter_rounds(), 3, 4)
            viewer = RadarTrackViewer(buf, cfg)
            failures = []
            def ids():
                return [int(x.round_id) for x in buf.current_window()]
            def verify_keys():
                try:
                    self.assertEqual(ids(), [1, 2, 3])
                    widget = viewer.canvas.get_tk_widget()
                    widget.focus_force()
                    viewer.root.update()
                    for key, expected in [('Return', [2,3,4]), ('Left', [1,2,3]),
                                          ('Right', [2,3,4]), ('Right', [3,4,5]),
                                          ('Right', [4,5,6]), ('Right', [4,5,6]),
                                          ('Left', [3,4,5]), ('Left', [3,4,5])]:
                        widget.event_generate('<KeyPress>', keysym=key)
                        viewer.root.update()
                        self.assertEqual(ids(), expected, key)
                    widget.event_generate('<KeyPress>', keysym='q')
                    self.assertTrue(viewer._closed)
                except BaseException as exc:
                    failures.append(exc)
                    viewer.close()
            viewer.root.after(300, verify_keys)
            viewer.run()
            if failures:
                raise failures[0]
            self.assertTrue(viewer._closed)

if __name__ == '__main__':
    unittest.main()
