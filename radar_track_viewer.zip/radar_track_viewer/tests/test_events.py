import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.backend_bases import KeyEvent
from test_core import build_csv
from radar_viewer.config import ViewerConfig
from radar_viewer.reader import RadarCSVReader
from radar_viewer.buffer import SlidingRoundBuffer
from radar_viewer.viewer import RadarTrackViewer

class EventTest(unittest.TestCase):
    def test_callback_sliding_cache_eof_and_quit(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'sample.csv'
            build_csv(path)
            cfg = ViewerConfig(csv_path=path, chunksize=4, cache_rounds=4)
            v = RadarTrackViewer.__new__(RadarTrackViewer)
            v.config = cfg
            v.buffer = SlidingRoundBuffer(RadarCSVReader(cfg).iter_rounds(), 3, 4)
            v.root = Mock()
            v._closed = v._busy = False
            v.fig = Figure()
            v.canvas = FigureCanvasAgg(v.fig)
            v.canvas.get_tk_widget = Mock(return_value=Mock())
            v.ax = v.fig.add_subplot()
            v.canvas.mpl_connect('key_press_event', v._on_key)
            self.assertTrue(v.buffer.initialize())
            v._draw()
            for key, expected in [('enter',[2,3,4]), ('left',[1,2,3]),
                                  ('right',[2,3,4]), ('right',[3,4,5]),
                                  ('right',[4,5,6]), ('right',[4,5,6]),
                                  ('left',[3,4,5]), ('left',[3,4,5])]:
                v.canvas.callbacks.process('key_press_event', KeyEvent('key_press_event', v.canvas, key))
                self.assertEqual([int(r.round_id) for r in v.buffer.current_window()], expected)
            v.canvas.callbacks.process('key_press_event', KeyEvent('key_press_event', v.canvas, 'q'))
            self.assertTrue(v._closed)
            v.root.destroy.assert_called_once()
