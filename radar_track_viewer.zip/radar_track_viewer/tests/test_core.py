from pathlib import Path
import json
import tempfile

import pandas as pd

from radar_viewer.config import ViewerConfig
from radar_viewer.reader import RadarCSVReader
from radar_viewer.buffer import SlidingRoundBuffer


def build_csv(path: Path):
    cols = [f"c{i}" for i in range(1, 46)]
    rows = []
    for round_id in range(1, 7):
        for p in range(3):
            row = [0] * 45
            row[14] = 100 + round_id * 10 + p     # 第15列 distance
            row[15] = round_id * 5 + p            # 第16列 azimuth
            row[44] = round_id                    # 第45列 round
            rows.append(row)
    pd.DataFrame(rows, columns=cols).to_csv(path, index=False)


def test_cross_chunk_and_sliding():
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        csv_path = td / "test.csv"
        build_csv(csv_path)

        cfg = ViewerConfig(
            csv_path=csv_path,
            chunksize=4,      # 故意切断圈边界
            window_size=3,
            cache_rounds=5,
        )
        reader = RadarCSVReader(cfg)
        rounds = list(reader.iter_rounds())

        assert [int(r.round_id) for r in rounds] == [1, 2, 3, 4, 5, 6]
        assert [r.point_count for r in rounds] == [3, 3, 3, 3, 3, 3]

        buf = SlidingRoundBuffer(iter(rounds), window_size=3, cache_rounds=5)
        assert buf.initialize()
        assert [int(x.round_id) for x in buf.current_window()] == [1, 2, 3]

        assert buf.next_window()
        assert [int(x.round_id) for x in buf.current_window()] == [2, 3, 4]

        assert buf.next_window()
        assert [int(x.round_id) for x in buf.current_window()] == [3, 4, 5]

        assert buf.previous_window()
        assert [int(x.round_id) for x in buf.current_window()] == [2, 3, 4]


if __name__ == "__main__":
    test_cross_chunk_and_sliding()
    print("OK")
