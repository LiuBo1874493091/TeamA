from __future__ import annotations

import argparse
import sys

from radar_viewer.buffer import SlidingRoundBuffer
from radar_viewer.config import ViewerConfig
from radar_viewer.reader import RadarCSVReader
from radar_viewer.viewer import RadarTrackViewer


def parse_args():
    parser = argparse.ArgumentParser(description="雷达点迹滑动窗口查看器")
    parser.add_argument(
        "--config",
        default="config.json",
        help="配置文件路径，默认 config.json",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    try:
        cfg = ViewerConfig.from_json(args.config)
        reader = RadarCSVReader(cfg)
        buffer = SlidingRoundBuffer(
            round_iter=reader.iter_rounds(),
            window_size=cfg.window_size,
            cache_rounds=cfg.cache_rounds,
        )
        viewer = RadarTrackViewer(buffer, cfg)
        viewer.run()
        return 0
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        print(f"[错误] {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
