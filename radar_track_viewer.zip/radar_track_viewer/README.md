# Radar Track Viewer（独立窗口修复版）

## 本次修复与启动方式

旧版依赖 `pyplot.show()` 和环境默认后端，IDE 绘图模式可能接管显示。
新版直接使用 `FigureCanvasTkAgg` 将 Matplotlib 嵌入独立 Tk 窗口，通过
`root.mainloop()` 保持窗口与键盘事件循环，不导入 `matplotlib.pyplot`。
无需修改 IDE 的绘图后端设置。推荐使用 IDE 的“运行 Python 文件”，或在终端启动。

1. 修改 `config.json` 中的 `csv_path`。
2. 安装依赖：`python -m pip install -r requirements.txt`。
3. 运行 `python main.py`；Windows 也可双击 `start_windows.bat`。
4. 点击绘图区获取键盘焦点，再按 Enter / 右方向键前进、左方向键回退。
   也可点击窗口底部 Previous / Next 按钮。
5. Q / Esc 或关闭窗口退出。

Python 需要包含 Tk。可运行 `python -m tkinter` 检查，正常会弹出测试窗口。
Windows 官方 Python 安装器可通过 Modify 安装 Tcl/Tk 支持；不要用 pip 安装 tkinter。
启动失败会打印原因并记录 `error.log`；Windows 启动脚本在失败时暂停，避免错误一闪而过。
默认配置路径已改为相对 main.py，不再依赖 IDE 的工作目录。

### 验证情况

- 核心跨 chunk 拼圈、滑窗、缓存测试通过。
- Matplotlib 事件分发测试通过：Enter/左右方向键、文件末尾、缓存边界、Q 退出。
- 编译检查通过。
- 当前验证环境没有可连接的桌面显示服务，未完成真实 Tk 窗口键盘测试，也未在 Windows IDE 实测。
  `tests/test_gui.py` 提供真实 Tk 窗口事件测试，可在本机桌面终端执行：
  `python -m unittest discover -s tests -p test_gui.py`。



一个用于人工观察雷达点迹是否在连续多圈之间形成航迹的 Python 小工具。

## 主要特性

- **不会一次性读取整个 CSV**
  - 使用 `pandas.read_csv(..., chunksize=...)` 流式读取。
  - 正确处理“同一圈被切在两个 chunk 中”的情况。
- **滑动窗口观察**
  - 默认同时观察 3 圈，可通过 `window_size` 修改。
  - 下一窗口示例：`[1,2,3] -> [2,3,4] -> [3,4,5]`。
- **方案 B：最近 N 圈缓存**
  - 默认缓存最近 20 圈，可通过 `cache_rounds` 修改。
  - 在缓存范围内可以按左方向键回看。
- **空间显示**
  - 使用距离 `range` + 方位角 `azimuth` 转换为二维 `x/y`：
    - `x = r * cos(theta)`
    - `y = r * sin(theta)`
  - 不同圈使用不同 marker 和透明度。
- **交互浏览**
  - `Enter` / `→`：下一窗口
  - `←`：上一窗口（只能回到仍在缓存中的圈）
  - `Q` / `Esc`：退出
  - Matplotlib 工具栏仍可用于缩放、平移等操作。

---

## 1. CSV 数据假设

程序假设：

1. 第一行为标题。
2. CSV 已经按照“圈数”排序。
3. 同一圈的所有记录在文件中连续出现。
4. 第 15 列：距离。
5. 第 16 列：角度，单位为度，正常范围为 0~360°。
6. 第 45 列：圈数。

注意：配置文件中的列号按照日常习惯从 **1** 开始计数，程序内部会自动转换为 Python 的 0-based 下标。

---

## 2. 项目结构

```text
radar_track_viewer/
├─ main.py
├─ config.json
├─ requirements.txt
├─ README.md
└─ radar_viewer/
   ├─ __init__.py
   ├─ config.py
   ├─ reader.py
   ├─ buffer.py
   └─ viewer.py
```

---

## 3. 安装

建议 Python 3.10+。

```bash
pip install -r requirements.txt
```

---

## 4. 配置

修改 `config.json`：

```json
{
  "csv_path": "data/radar.csv",
  "chunksize": 100000,
  "window_size": 3,
  "cache_rounds": 20,
  "distance_col_index": 15,
  "azimuth_col_index": 16,
  "round_col_index": 45
}
```

### 参数说明

- `csv_path`
  - 雷达 CSV 文件路径。
  - 相对路径以 `config.json` 所在目录为基准。
- `chunksize`
  - 每次从 CSV 读取多少行。
  - 这个参数影响磁盘读取效率和瞬时内存占用。
  - 它不会改变“按圈处理”的逻辑。
- `window_size`
  - 同时显示多少圈。
  - 默认 3。
- `cache_rounds`
  - 内存中最多保留最近多少圈。
  - 必须 >= `window_size`。
  - 例如设为 20，就可以在最近 20 圈范围内向前回看。
- `distance_col_index`
  - 距离所在列，从 1 开始。
- `azimuth_col_index`
  - 方位角所在列，从 1 开始。
- `round_col_index`
  - 圈数所在列，从 1 开始。

---

## 5. 运行

把 CSV 放到：

```text
data/radar.csv
```

或者修改 `config.json` 中的 `csv_path`。

运行：

```bash
python main.py
```

也可以指定其他配置文件：

```bash
python main.py --config my_config.json
```

---

## 6. 浏览逻辑

假设：

```text
window_size = 3
```

第一次：

```text
圈 1 + 圈 2 + 圈 3
```

按 `Enter` 或 `→`：

```text
圈 2 + 圈 3 + 圈 4
```

再按：

```text
圈 3 + 圈 4 + 圈 5
```

程序不会为了翻页把整个 CSV 预先读入内存，而是在需要下一圈时继续向后读取。

---

## 7. 为什么不会因为大文件直接爆内存

程序内存主要由两部分组成：

```text
当前 pandas chunk
+
最近 cache_rounds 圈
```

而不是：

```text
整个 CSV
```

比如 CSV 有几十 GB，只要单个 chunk 和最近 20 圈可以放入内存，就可以继续浏览。

---

## 8. 关于跨 chunk 的同一圈

例如：

```text
chunk 1:
圈 100
圈 101
圈 102 的前半部分

chunk 2:
圈 102 的后半部分
圈 103
圈 104
```

程序不会把圈 102 错误拆成两个圈。

它会把 chunk 最后一圈暂存下来，与下一 chunk 开头拼接，再形成完整的 `RoundData`。

---

## 9. 异常数据处理

当前版本做了以下防御：

- CSV 文件不存在
- CSV 为空
- CSV 列数不足
- 非法距离值
- 非法角度值
- 圈数为空
- 最后不足 `window_size` 圈
- 同一圈跨 chunk
- 浏览到文件末尾
- 浏览到缓存最前端
- 重复快速按键
- 关闭 Matplotlib 窗口

默认情况下，无法转换为数字的距离/角度点会被丢弃。

---

## 10. 一个需要注意的行为

方案 B 只缓存最近 `cache_rounds` 圈。

例如：

```text
cache_rounds = 20
```

当你已经向后浏览很远以后，更早的数据会从内存中释放。

因此左方向键只能回到**仍然存在于缓存中的最早窗口**。

如果未来希望可以跳回 CSV 中任意历史圈，需要进一步增加“圈号 -> 文件偏移”的磁盘索引功能。
