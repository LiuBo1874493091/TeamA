import csv
from pathlib import Path


# =========================
# 配置
# =========================

# 输入 CSV
INPUT_CSV = r"D:\data\radar_points.csv"

# 输出 CSV
OUTPUT_CSV = r"D:\data\radar_real_points.csv"

# 杂波标志所在列
# 第45列 -> Python索引44
CLUTTER_COLUMN_INDEX = 44

# 真实点对应的标志值
# 假设：0 = 杂波，1 = 真实点
REAL_POINT_FLAG = "1"

# 每处理多少行打印一次进度
PRINT_INTERVAL = 100_000


def extract_real_points(
    input_csv: str,
    output_csv: str,
    clutter_column_index: int = 44,
    real_point_flag: str = "1",
):
    """
    从雷达点迹CSV中提取真实点。

    参数：
        input_csv:
            原始CSV文件路径

        output_csv:
            真实点输出CSV文件路径

        clutter_column_index:
            杂波标志列的Python索引。
            第45列对应索引44。

        real_point_flag:
            表示真实点的值。
    """

    input_path = Path(input_csv)
    output_path = Path(output_csv)

    if not input_path.exists():
        raise FileNotFoundError(
            f"输入文件不存在：{input_path}"
        )

    # 如果输出目录不存在，自动创建
    output_path.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    total_count = 0
    real_count = 0
    invalid_count = 0

    print("=" * 60)
    print("开始处理雷达点迹 CSV")
    print(f"输入文件：{input_path}")
    print(f"输出文件：{output_path}")
    print(f"杂波标志：第 {clutter_column_index + 1} 列")
    print(f"真实点标志：{real_point_flag}")
    print("=" * 60)

    # newline="" 防止 Windows 下出现多余空行
    # utf-8-sig 可以兼容带 BOM 的 CSV
    with open(
        input_path,
        "r",
        encoding="utf-8-sig",
        newline=""
    ) as fin, open(
        output_path,
        "w",
        encoding="utf-8-sig",
        newline=""
    ) as fout:

        reader = csv.reader(fin)
        writer = csv.writer(fout)

        # -------------------------
        # 读取标题
        # -------------------------
        try:
            header = next(reader)
        except StopIteration:
            print("CSV 文件为空。")
            return

        # 检查是否至少有45列
        if len(header) <= clutter_column_index:
            raise ValueError(
                f"CSV只有 {len(header)} 列，"
                f"但指定的杂波标志位于第 "
                f"{clutter_column_index + 1} 列。"
            )

        # 将原始标题完整写入输出文件
        writer.writerow(header)

        print(f"CSV列数：{len(header)}")
        print(
            f"第45列标题："
            f"{header[clutter_column_index]}"
        )
        print()

        # -------------------------
        # 逐行读取
        # -------------------------
        for row in reader:
            total_count += 1

            # 防止某些异常行列数不足
            if len(row) <= clutter_column_index:
                invalid_count += 1
                continue

            flag = row[clutter_column_index].strip()

            # 只保存真实点
            if flag == real_point_flag:
                writer.writerow(row)
                real_count += 1

            # 打印处理进度
            if total_count % PRINT_INTERVAL == 0:
                print(
                    f"已处理 {total_count:,} 行，"
                    f"真实点 {real_count:,} 行，"
                    f"异常行 {invalid_count:,} 行"
                )

    # -------------------------
    # 最终统计
    # -------------------------
    clutter_count = total_count - real_count - invalid_count

    print()
    print("=" * 60)
    print("处理完成")
    print(f"总点迹数：   {total_count:,}")
    print(f"真实点数：   {real_count:,}")
    print(f"杂波点数：   {clutter_count:,}")
    print(f"异常行数：   {invalid_count:,}")

    if total_count > 0:
        print(
            f"真实点比例： "
            f"{real_count / total_count * 100:.4f}%"
        )

    print(f"结果文件：   {output_path}")
    print("=" * 60)


if __name__ == "__main__":
    extract_real_points(
        input_csv=INPUT_CSV,
        output_csv=OUTPUT_CSV,
        clutter_column_index=CLUTTER_COLUMN_INDEX,
        real_point_flag=REAL_POINT_FLAG,
    )