# 数据划分与逐点 Recall 更新

## 当前数据构造顺序

本版本按照以下顺序构造训练/验证/测试数据：

1. 对完整雷达圈序列先生成所有连续滑窗。每个样本对应“固定方位扇区 + 连续 L 圈”。
2. 对每个滑窗检查其中全部有效点迹的标签。
3. 如果一个滑窗中所有有效点迹都是 `label=0`，即整个窗口没有任何目标点，则删除这个纯杂波样本。
4. 对剩余的含目标滑窗样本进行样本级随机划分：
   - `train_ratio`
   - `val_ratio`
   - `test_ratio = 1 - train_ratio - val_ratio`
5. 随机划分由 `train.seed` 固定，因此相同 CSV、配置和 seed 会得到相同的数据划分。

> 注意：这是“先生成滑窗，再按滑窗样本划分”的逻辑。相邻滑窗可能共享原始圈次/点迹，这是当前需求明确采用的行为。

## 纯杂波过滤

`radar_config.json`：

```json
"data": {
  "drop_all_clutter_windows": true
}
```

保持为 `true` 时，一个样本只有在至少包含一个 `label=1` 的有效点迹时才会保留。

## 样本级划分

```json
"split": {
  "train_ratio": 0.7,
  "val_ratio": 0.15,
  "shuffle_samples": true
}
```

测试集比例自动为：

```text
test_ratio = 1 - train_ratio - val_ratio
```

默认即 70% / 15% / 15%。

## 划分统计

预处理结束后程序会输出：

```text
train | 样本=... | 目标点迹(label=1)=... | 杂波点迹(label=0)=...
val   | 样本=... | 目标点迹(label=1)=... | 杂波点迹(label=0)=...
test  | 样本=... | 目标点迹(label=1)=... | 杂波点迹(label=0)=...
```

这里的目标/杂波点迹数：

- 已考虑 `max_points_per_frame`；
- 不包含 padding；
- 按点迹在滑窗样本中的实际出现次数统计；
- 因此相邻滑窗共享的原始点迹可能被重复统计，这与模型实际看到它的次数一致。

训练输出目录同时保存：

```text
dataset_split_summary.json
```

用于后续核对数据划分。

## Recall 是逐点迹 Recall

本任务不是“窗口样本二分类”。模型对每个有效点迹预测：

```text
0 = 杂波点
1 = 目标点
```

因此 Recall 为：

```text
Recall = TP / (TP + FN)
```

其中 TP/FN 都是“点迹数量”，不是“滑窗样本数量”。padding 不参与统计。

测试程序会直接输出：

```text
recall(point, positive class)
TP/FP/TN/FN
```

## 最佳模型

因为当前任务重点关注目标点的召回率，默认配置：

```json
"train": {
  "best_metric": "recall"
}
```

因此 `best.pth` 默认按照验证集逐点 Recall 最高保存。

如果后续希望兼顾 Precision，可改为：

```json
"best_metric": "f1"
```

## 训练曲线

训练目录会生成：

```text
loss_curve.png
f1_curve.png
recall_curve.png
train_history.csv
```

`recall_curve.png` 显示 train/val 的逐点正类 Recall 随 epoch 的变化。

## 缓存

由于数据划分逻辑已经改变，缓存版本已升级。旧的 `.radar_cache.pkl` 会自动判定失效并重新生成。

如需强制重建：

```bash
python radar_train.py --csv ./data/data.csv --config radar_config.json --rebuild-cache
```
