import torch


class BinaryMetrics:
    def __init__(self): self.reset()
    def reset(self): self.tp=self.fp=self.tn=self.fn=0
    @torch.no_grad()
    def update(self, logits, labels, mask):
        pred = logits.argmax(-1)
        p = pred[mask].view(-1)
        y = labels[mask].view(-1)
        self.tp += int(((p==1)&(y==1)).sum())
        self.fp += int(((p==1)&(y==0)).sum())
        self.tn += int(((p==0)&(y==0)).sum())
        self.fn += int(((p==0)&(y==1)).sum())
    def compute(self):
        eps=1e-12
        acc=(self.tp+self.tn)/(self.tp+self.tn+self.fp+self.fn+eps)
        prec=self.tp/(self.tp+self.fp+eps)
        rec=self.tp/(self.tp+self.fn+eps)
        f1=2*prec*rec/(prec+rec+eps)
        return {'accuracy':acc,'precision':prec,'recall':rec,'f1':f1,
                'tp':self.tp,'fp':self.fp,'tn':self.tn,'fn':self.fn}
