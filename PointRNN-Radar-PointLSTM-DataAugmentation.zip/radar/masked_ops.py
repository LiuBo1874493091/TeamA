import torch
from .validation import require_ndim, require_finite, require_same_device, require_mask


def _validate_knn_inputs(query_xyz, key_xyz, key_mask, k, radius, query_chunk_size):
    require_ndim('query_xyz', query_xyz, 3)
    require_ndim('key_xyz', key_xyz, 3)
    require_ndim('key_mask', key_mask, 2)
    if query_xyz.shape[-1] != 3 or key_xyz.shape[-1] != 3:
        raise ValueError(f'KNN xyz last dim must be 3: query={tuple(query_xyz.shape)}, key={tuple(key_xyz.shape)}')
    if query_xyz.shape[0] != key_xyz.shape[0]:
        raise ValueError(f'KNN batch mismatch: query B={query_xyz.shape[0]}, key B={key_xyz.shape[0]}')
    require_mask('key_mask', key_mask, key_xyz.shape[:2])
    require_same_device(('query_xyz', query_xyz), ('key_xyz', key_xyz), ('key_mask', key_mask))
    require_finite('query_xyz', query_xyz)
    require_finite('key_xyz', key_xyz)
    if query_xyz.shape[1] <= 0:
        raise ValueError('KNN query set is empty (N=0). Padding should be represented with mask, not T=0.')
    if key_xyz.shape[1] <= 0:
        raise ValueError('KNN key set is empty (M=0). Padding should be represented with mask, not T=0.')
    if int(k) <= 0:
        raise ValueError(f'KNN k must be > 0, got {k}')
    if int(query_chunk_size) <= 0:
        raise ValueError(f'query_chunk_size must be > 0, got {query_chunk_size}')
    if radius is not None and float(radius) <= 0:
        raise ValueError(f'radius must be > 0 or None, got {radius}')


def masked_knn(query_xyz, key_xyz, key_mask, k, radius=None, query_chunk_size=128):
    """Mask-aware radius-KNN, chunked to bound peak distance-matrix memory.

    query_xyz: [B,N,3], key_xyz: [B,M,3], key_mask: [B,M]
    returns idx [B,N,K], valid [B,N,K], squared distances [B,N,K]
    """
    _validate_knn_inputs(query_xyz, key_xyz, key_mask, k, radius, query_chunk_size)
    B, N, _ = query_xyz.shape
    M = key_xyz.shape[1]
    k = int(k)
    k_eff = min(k, M)
    chunk = int(query_chunk_size)
    all_idx, all_valid, all_vals = [], [], []
    for start in range(0, N, chunk):
        q = query_xyz[:, start:start + chunk]
        if q.shape[1] == 0:
            continue
        d2 = torch.cdist(q, key_xyz, p=2).square()
        if tuple(d2.shape) != (B, q.shape[1], M):
            raise RuntimeError(f'Unexpected cdist shape {tuple(d2.shape)}; expected {(B, q.shape[1], M)}')
        d2 = d2.masked_fill(~key_mask[:, None, :], float('inf'))
        vals, idx = torch.topk(d2, k=k_eff, dim=-1, largest=False, sorted=False)
        if idx.numel():
            i_min, i_max = int(idx.min().item()), int(idx.max().item())
            if i_min < 0 or i_max >= M:
                raise IndexError(f'KNN generated out-of-range indices [{i_min}, {i_max}] for M={M}')
        valid = torch.isfinite(vals)
        if radius is not None:
            valid = valid & (vals <= float(radius) * float(radius))
        if k_eff < k:
            pad = k - k_eff
            idx = torch.cat([idx, torch.zeros(B, q.shape[1], pad, dtype=idx.dtype, device=idx.device)], dim=-1)
            vals = torch.cat([vals, torch.full((B, q.shape[1], pad), float('inf'), device=vals.device, dtype=vals.dtype)], dim=-1)
            valid = torch.cat([valid, torch.zeros(B, q.shape[1], pad, dtype=torch.bool, device=valid.device)], dim=-1)
        all_idx.append(idx)
        all_valid.append(valid)
        all_vals.append(vals)
    if not all_idx:
        raise RuntimeError(f'KNN produced no chunks: B={B}, N={N}, M={M}, chunk={chunk}')
    idx = torch.cat(all_idx, dim=1)
    valid = torch.cat(all_valid, dim=1)
    vals = torch.cat(all_vals, dim=1)
    expected = (B, N, k)
    if tuple(idx.shape) != expected or tuple(valid.shape) != expected or tuple(vals.shape) != expected:
        raise RuntimeError(f'KNN output shape mismatch: idx={tuple(idx.shape)}, valid={tuple(valid.shape)}, vals={tuple(vals.shape)}, expected={expected}')
    return idx, valid, vals


def gather_neighbors(features, idx):
    """features [B,M,C], idx [B,N,K] -> [B,N,K,C]."""
    require_ndim('features', features, 3)
    require_ndim('idx', idx, 3)
    if idx.dtype != torch.long:
        raise TypeError(f'idx must be torch.long, got {idx.dtype}')
    require_same_device(('features', features), ('idx', idx))
    B, M, C = features.shape
    if B != idx.shape[0]:
        raise ValueError(f'gather batch mismatch: features B={B}, idx B={idx.shape[0]}')
    if M <= 0:
        raise ValueError('Cannot gather from empty key dimension M=0.')
    if C <= 0:
        raise ValueError('Cannot gather features with channel dimension C=0.')
    if idx.numel():
        i_min, i_max = int(idx.min().item()), int(idx.max().item())
        if i_min < 0 or i_max >= M:
            raise IndexError(f'gather_neighbors index out of bounds: min={i_min}, max={i_max}, allowed=[0,{M-1}]')
    N, K = idx.shape[1], idx.shape[2]
    expanded = features[:, None, :, :].expand(B, N, M, C)
    gather_idx = idx[..., None].expand(B, N, K, C)
    out = torch.gather(expanded, 2, gather_idx)
    require_finite('gathered_neighbors', out)
    return out


def masked_max(x, valid, dim=2):
    """Masked max where all-invalid rows return zeros."""
    require_ndim('x', x, 4)
    require_ndim('valid', valid, 3)
    if valid.dtype != torch.bool:
        raise TypeError(f'valid mask must be bool, got {valid.dtype}')
    if tuple(x.shape[:3]) != tuple(valid.shape):
        raise ValueError(f'masked_max shape mismatch: x={tuple(x.shape)}, valid={tuple(valid.shape)}')
    require_same_device(('x', x), ('valid', valid))
    require_finite('masked_max input', x)
    fill = torch.finfo(x.dtype).min
    y = x.masked_fill(~valid[..., None], fill)
    out = y.max(dim=dim).values
    any_valid = valid.any(dim=dim)
    out = torch.where(any_valid[..., None], out, torch.zeros_like(out))
    require_finite('masked_max output', out)
    return out
