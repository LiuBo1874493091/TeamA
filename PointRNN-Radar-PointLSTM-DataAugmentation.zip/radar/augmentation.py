import numpy as np
import torch


class RadarAugmenter:
    """Point-wise radar augmentation for TRAIN samples only.

    Augmentation is applied after clutter undersampling and before padding/collate.
    All operations work on valid points only. New synthetic clutter points use label=0.
    """

    def __init__(self, config, feature_cols, feature_mean, feature_std):
        self.cfg = config.get("augmentation", {}) or {}
        self.enabled = bool(self.cfg.get("enabled", False))
        self.apply_probability = float(self.cfg.get("apply_probability", 1.0))
        if not 0.0 <= self.apply_probability <= 1.0:
            raise ValueError("augmentation.apply_probability must be in [0,1]")

        self.feature_cols = list(feature_cols)
        self.feature_mean = np.asarray(feature_mean, dtype=np.float32)
        self.feature_std = np.asarray(feature_std, dtype=np.float32)
        self.col_to_idx = {c: i for i, c in enumerate(self.feature_cols)}

        cols = config.get("columns", {})
        data_cfg = config.get("data", {})
        self.range_col = cols.get("range")
        self.azimuth_col = cols.get("azimuth")
        self.elevation_col = cols.get("elevation")
        self.range_scale = float(data_cfg.get("range_scale", 1000.0))
        self.sector_width = float(data_cfg.get("sector_width_deg", 30.0))

        self.range_jitter_std_m = float(self.cfg.get("range_jitter_std_m", 0.0))
        self.azimuth_jitter_std_deg = float(self.cfg.get("azimuth_jitter_std_deg", 0.0))
        self.feature_noise_std = dict(self.cfg.get("feature_gaussian_noise_std", {}) or {})
        self.point_dropout_probability = float(self.cfg.get("point_dropout_probability", 0.0))
        self.dropout_target_points = bool(self.cfg.get("dropout_target_points", False))
        self.clutter_injection_ratio = float(self.cfg.get("clutter_injection_ratio", 0.0))
        self.clutter_injection_max_per_frame = int(self.cfg.get("clutter_injection_max_per_frame", 0) or 0)

        for name, value in (
            ("range_jitter_std_m", self.range_jitter_std_m),
            ("azimuth_jitter_std_deg", self.azimuth_jitter_std_deg),
            ("point_dropout_probability", self.point_dropout_probability),
            ("clutter_injection_ratio", self.clutter_injection_ratio),
        ):
            if value < 0:
                raise ValueError(f"augmentation.{name} must be >= 0")
        if self.point_dropout_probability > 1.0:
            raise ValueError("augmentation.point_dropout_probability must be <= 1")
        if self.clutter_injection_max_per_frame < 0:
            raise ValueError("augmentation.clutter_injection_max_per_frame must be >= 0")
        for col, std in self.feature_noise_std.items():
            if float(std) < 0:
                raise ValueError(f"augmentation.feature_gaussian_noise_std[{col!r}] must be >= 0")
            if col not in self.col_to_idx:
                raise KeyError(
                    f"Augmentation noise column {col!r} is not in columns.features={self.feature_cols}"
                )

    def _rng(self, sample_idx):
        # torch.initial_seed() differs across DataLoader workers. np.random adds
        # variation across repeated __getitem__ calls/epochs when workers=0.
        seed = (
            int(torch.initial_seed())
            + int(sample_idx) * 1_000_003
            + int(np.random.randint(0, 2**31 - 1))
        ) % (2**63 - 1)
        return np.random.default_rng(seed)

    def _xyz_to_physical(self, xyz):
        xyz = np.asarray(xyz, dtype=np.float32)
        radius_scaled = np.linalg.norm(xyz, axis=1)
        range_m = radius_scaled * self.range_scale
        azimuth_deg = (np.degrees(np.arctan2(xyz[:, 1], xyz[:, 0])) + 360.0) % 360.0
        horizontal = np.sqrt(np.square(xyz[:, 0]) + np.square(xyz[:, 1]))
        elevation_rad = np.arctan2(xyz[:, 2], horizontal)
        return range_m.astype(np.float32), azimuth_deg.astype(np.float32), elevation_rad.astype(np.float32)

    def _physical_to_xyz(self, range_m, azimuth_deg, elevation_rad):
        rr = np.asarray(range_m, dtype=np.float32) / self.range_scale
        az = np.deg2rad(np.asarray(azimuth_deg, dtype=np.float32))
        el = np.asarray(elevation_rad, dtype=np.float32)
        xy = rr * np.cos(el)
        return np.stack(
            [xy * np.cos(az), xy * np.sin(az), rr * np.sin(el)], axis=1
        ).astype(np.float32)

    def _denormalize_features(self, feat):
        return feat.astype(np.float32, copy=True) * self.feature_std + self.feature_mean

    def _normalize_features(self, feat_raw):
        return ((feat_raw - self.feature_mean) / self.feature_std).astype(np.float32)

    def _sync_geometry_features(self, feat_raw, range_m, azimuth_deg, elevation_rad):
        if self.range_col in self.col_to_idx:
            feat_raw[:, self.col_to_idx[self.range_col]] = range_m
        if self.azimuth_col in self.col_to_idx:
            feat_raw[:, self.col_to_idx[self.azimuth_col]] = azimuth_deg
        if self.elevation_col and self.elevation_col in self.col_to_idx:
            # CSV elevation is assumed to be in degrees, matching preprocessing.
            feat_raw[:, self.col_to_idx[self.elevation_col]] = np.degrees(elevation_rad)
        return feat_raw

    def _drop_points(self, xyz, feat_raw, labels, rng):
        n = len(labels)
        if n == 0 or self.point_dropout_probability <= 0:
            return xyz, feat_raw, labels
        candidates = labels == 0 if not self.dropout_target_points else np.ones(n, dtype=bool)
        drop = candidates & (rng.random(n) < self.point_dropout_probability)
        if self.dropout_target_points and (labels == 1).any():
            pos_idx = np.flatnonzero(labels == 1)
            if np.all(drop[pos_idx]):
                drop[int(rng.choice(pos_idx))] = False
        keep = ~drop
        return xyz[keep], feat_raw[keep], labels[keep]

    def _inject_clutter(self, xyz, feat_raw, labels, sector, rng):
        n = len(labels)
        if n == 0 or self.clutter_injection_ratio <= 0:
            return xyz, feat_raw, labels
        add_n = int(round(n * self.clutter_injection_ratio))
        if self.clutter_injection_max_per_frame > 0:
            add_n = min(add_n, self.clutter_injection_max_per_frame)
        if add_n <= 0:
            return xyz, feat_raw, labels

        range_m, _, elevation_rad = self._xyz_to_physical(xyz)
        r_min, r_max = float(range_m.min()), float(range_m.max())
        if r_max <= r_min:
            r_max = r_min + max(1.0, abs(r_min) * 0.01)
        new_range = rng.uniform(r_min, r_max, size=add_n).astype(np.float32)
        sector_start = float(sector) * self.sector_width
        sector_end = sector_start + self.sector_width
        new_az = rng.uniform(sector_start, sector_end, size=add_n).astype(np.float32) % 360.0
        el_min, el_max = float(elevation_rad.min()), float(elevation_rad.max())
        if el_max > el_min:
            new_el = rng.uniform(el_min, el_max, size=add_n).astype(np.float32)
        else:
            new_el = np.full(add_n, el_min, dtype=np.float32)
        new_xyz = self._physical_to_xyz(new_range, new_az, new_el)

        # Preserve realistic feature scale by bootstrapping existing clutter features.
        source = np.flatnonzero(labels == 0)
        if len(source) == 0:
            source = np.arange(n)
        src_idx = rng.choice(source, size=add_n, replace=True)
        new_feat_raw = feat_raw[src_idx].copy()
        new_feat_raw = self._sync_geometry_features(new_feat_raw, new_range, new_az, new_el)
        new_labels = np.zeros(add_n, dtype=np.int64)

        return (
            np.concatenate([xyz, new_xyz], axis=0),
            np.concatenate([feat_raw, new_feat_raw], axis=0),
            np.concatenate([labels, new_labels], axis=0),
        )

    def __call__(self, xyz_seq, feat_seq, label_seq, sector, sample_idx):
        if not self.enabled:
            return xyz_seq, feat_seq, label_seq
        rng = self._rng(sample_idx)
        if rng.random() > self.apply_probability:
            return xyz_seq, feat_seq, label_seq

        out_xyz, out_feat, out_lab = [], [], []
        for xyz, feat, labels in zip(xyz_seq, feat_seq, label_seq):
            xyz = np.asarray(xyz, dtype=np.float32).copy()
            feat = np.asarray(feat, dtype=np.float32).copy()
            labels = np.asarray(labels, dtype=np.int64).copy()
            if len(labels) == 0:
                out_xyz.append(xyz)
                out_feat.append(feat)
                out_lab.append(labels)
                continue

            feat_raw = self._denormalize_features(feat)
            range_m, azimuth_deg, elevation_rad = self._xyz_to_physical(xyz)

            if self.range_jitter_std_m > 0:
                range_m += rng.normal(0.0, self.range_jitter_std_m, size=len(range_m)).astype(np.float32)
                range_m = np.maximum(range_m, 0.0)
            if self.azimuth_jitter_std_deg > 0:
                azimuth_deg = (
                    azimuth_deg
                    + rng.normal(0.0, self.azimuth_jitter_std_deg, size=len(azimuth_deg)).astype(np.float32)
                ) % 360.0

            xyz = self._physical_to_xyz(range_m, azimuth_deg, elevation_rad)
            feat_raw = self._sync_geometry_features(feat_raw, range_m, azimuth_deg, elevation_rad)

            for col, std in self.feature_noise_std.items():
                std = float(std)
                if std > 0:
                    j = self.col_to_idx[col]
                    feat_raw[:, j] += rng.normal(0.0, std, size=len(labels)).astype(np.float32)

            xyz, feat_raw, labels = self._drop_points(xyz, feat_raw, labels, rng)
            xyz, feat_raw, labels = self._inject_clutter(xyz, feat_raw, labels, sector, rng)
            feat = self._normalize_features(feat_raw)

            if not np.isfinite(xyz).all() or not np.isfinite(feat).all():
                raise RuntimeError("Data augmentation produced NaN/Inf values.")
            if np.any((labels != 0) & (labels != 1)):
                raise RuntimeError("Data augmentation produced labels outside {0,1}.")

            out_xyz.append(xyz.astype(np.float32, copy=False))
            out_feat.append(feat.astype(np.float32, copy=False))
            out_lab.append(labels.astype(np.int64, copy=False))
        return out_xyz, out_feat, out_lab
