import torch


def tensor_brief(name, x):
    if not isinstance(x, torch.Tensor):
        return f'{name}=<{type(x).__name__}>'
    return f'{name}: shape={tuple(x.shape)}, dtype={x.dtype}, device={x.device}'


def require_tensor(name, x):
    if not isinstance(x, torch.Tensor):
        raise TypeError(f'{name} must be torch.Tensor, got {type(x).__name__}')


def require_ndim(name, x, ndim):
    require_tensor(name, x)
    if x.ndim != ndim:
        raise ValueError(f'{name} must be {ndim}D, got {tensor_brief(name, x)}')


def require_nonempty_dim(name, x, dims=None):
    require_tensor(name, x)
    dims = range(x.ndim) if dims is None else dims
    bad = [d for d in dims if x.shape[d] <= 0]
    if bad:
        raise ValueError(f'{name} has empty dimension(s) {bad}: {tensor_brief(name, x)}')


def require_finite(name, x):
    require_tensor(name, x)
    if not torch.is_floating_point(x):
        return
    finite = torch.isfinite(x)
    if not bool(finite.all()):
        bad = (~finite).nonzero(as_tuple=False)
        first = bad[0].tolist() if bad.numel() else None
        raise ValueError(f'{name} contains NaN/Inf; first bad index={first}; {tensor_brief(name, x)}')


def require_same_device(*named_tensors):
    items = [(n, x) for n, x in named_tensors if isinstance(x, torch.Tensor)]
    if not items:
        return
    d0 = items[0][1].device
    mismatch = [(n, str(x.device)) for n, x in items if x.device != d0]
    if mismatch:
        raise RuntimeError(f'Tensors are on different devices; expected {d0}, mismatches={mismatch}')


def require_mask(name, mask, expected_shape):
    require_tensor(name, mask)
    if tuple(mask.shape) != tuple(expected_shape):
        raise ValueError(f'{name} shape mismatch: expected {tuple(expected_shape)}, got {tuple(mask.shape)}')
    if mask.dtype != torch.bool:
        # 0/1 integer masks are accepted but converted by callers only when explicit.
        vals = torch.unique(mask.detach().cpu()) if mask.numel() else torch.tensor([])
        raise TypeError(f'{name} must be bool, got dtype={mask.dtype}, unique={vals.tolist()[:10]}')


def require_binary_labels(labels, mask=None, ignore_index=-100):
    require_tensor('labels', labels)
    if labels.dtype != torch.long:
        raise TypeError(f'labels must be torch.long, got {labels.dtype}')
    if mask is not None:
        require_mask('mask', mask, labels.shape)
        active = labels[mask]
        padding = labels[~mask]
        if padding.numel() and not bool((padding == ignore_index).all()):
            bad = padding[padding != ignore_index][:10].detach().cpu().tolist()
            raise ValueError(f'Padding labels must equal ignore_index={ignore_index}; found examples={bad}')
    else:
        active = labels[labels != ignore_index]
    if active.numel() == 0:
        raise ValueError('Batch contains zero valid labels (all points are padding).')
    ok = (active == 0) | (active == 1)
    if not bool(ok.all()):
        bad = torch.unique(active[~ok].detach().cpu()).tolist()[:20]
        raise ValueError(f'Valid labels must be 0/1 only; found {bad}')


def validate_model_batch(xyz, features, mask, labels=None, feature_dim=None, stage='model input'):
    require_ndim('xyz', xyz, 4)
    require_ndim('features', features, 4)
    require_ndim('mask', mask, 3)
    require_nonempty_dim('xyz', xyz, dims=(0, 1, 2, 3))
    require_nonempty_dim('features', features, dims=(0, 1, 2, 3))
    if xyz.shape[-1] != 3:
        raise ValueError(f'{stage}: xyz last dimension must be 3, got {tuple(xyz.shape)}')
    if xyz.shape[:3] != features.shape[:3]:
        raise ValueError(f'{stage}: xyz/features B,L,T mismatch: {tuple(xyz.shape)} vs {tuple(features.shape)}')
    require_mask('mask', mask, xyz.shape[:3])
    if feature_dim is not None and features.shape[-1] != int(feature_dim):
        raise ValueError(f'{stage}: feature dim mismatch: model expects {feature_dim}, batch has {features.shape[-1]}')
    require_same_device(('xyz', xyz), ('features', features), ('mask', mask), ('labels', labels))
    require_finite('xyz', xyz)
    require_finite('features', features)
    valid_count = int(mask.sum().item())
    if valid_count <= 0:
        raise ValueError(f'{stage}: entire batch is padding; xyz={tuple(xyz.shape)}')
    if labels is not None:
        require_ndim('labels', labels, 3)
        if tuple(labels.shape) != tuple(mask.shape):
            raise ValueError(f'{stage}: labels shape must equal mask shape; got {tuple(labels.shape)} vs {tuple(mask.shape)}')
        require_binary_labels(labels, mask)


def validate_logits(logits, labels, mask):
    require_ndim('logits', logits, 4)
    if logits.shape[-1] != 2:
        raise ValueError(f'logits last dimension must be 2 classes, got {tuple(logits.shape)}')
    if tuple(logits.shape[:3]) != tuple(labels.shape):
        raise ValueError(f'logits/labels mismatch: logits={tuple(logits.shape)}, labels={tuple(labels.shape)}')
    require_finite('logits', logits)
    require_binary_labels(labels, mask)
