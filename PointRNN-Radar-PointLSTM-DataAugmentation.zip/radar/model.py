import torch
import torch.nn as nn
from .masked_ops import masked_knn, gather_neighbors, masked_max
from .validation import (
    require_ndim,
    require_finite,
    require_same_device,
    require_mask,
    validate_model_batch,
)


class MaskedSpatioTemporalCorrelation(nn.Module):
    """Padding-aware PointLSTM spatial-temporal correlation block."""
    def __init__(self, radius, nsamples, in_channels, out_channels, query_chunk_size=128):
        super().__init__()
        self.radius = float(radius)
        self.nsamples = int(nsamples)
        self.in_channels = int(in_channels)
        self.out_channels = int(out_channels)
        self.query_chunk_size = int(query_chunk_size)
        if self.radius <= 0:
            raise ValueError(f'radius must be > 0, got {self.radius}')
        if self.nsamples <= 0:
            raise ValueError(f'nsamples must be > 0, got {self.nsamples}')
        if self.in_channels < 0 or self.out_channels <= 0:
            raise ValueError(f'Invalid channels: in={self.in_channels}, out={self.out_channels}')
        self.net = nn.Sequential(
            nn.Linear(in_channels + out_channels + 3, out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, p1, p2, x1, s2, mask1, mask2, neighbor_info=None):
        require_ndim('p1', p1, 3)
        require_ndim('p2', p2, 3)
        require_ndim('s2', s2, 3)
        require_mask('mask1', mask1, p1.shape[:2])
        require_mask('mask2', mask2, p2.shape[:2])
        require_same_device(('p1', p1), ('p2', p2), ('x1', x1), ('s2', s2), ('mask1', mask1), ('mask2', mask2))
        if p1.shape[-1] != 3 or p2.shape[-1] != 3:
            raise ValueError(f'p1/p2 last dim must be 3: p1={tuple(p1.shape)}, p2={tuple(p2.shape)}')
        if p1.shape[0] != p2.shape[0] or p1.shape[0] != s2.shape[0]:
            raise ValueError(f'Batch mismatch in correlation: p1={tuple(p1.shape)}, p2={tuple(p2.shape)}, s2={tuple(s2.shape)}')
        if p2.shape[:2] != s2.shape[:2]:
            raise ValueError(f'p2/s2 point dimensions mismatch: p2={tuple(p2.shape)}, s2={tuple(s2.shape)}')
        if s2.shape[-1] != self.out_channels:
            raise ValueError(f's2 hidden dim mismatch: expected {self.out_channels}, got {s2.shape[-1]}')
        if self.in_channels > 0:
            if x1 is None:
                raise ValueError('x1 is required when in_channels > 0')
            require_ndim('x1', x1, 3)
            if x1.shape[:2] != p1.shape[:2] or x1.shape[-1] != self.in_channels:
                raise ValueError(f'x1 shape mismatch: expected [B,N,{self.in_channels}] matching p1, got {tuple(x1.shape)}')
        elif x1 is not None:
            raise ValueError('x1 must be None when in_channels == 0')
        require_finite('p1', p1)
        require_finite('p2', p2)
        require_finite('s2', s2)
        if x1 is not None:
            require_finite('x1', x1)

        if neighbor_info is None:
            idx, neigh_valid, _ = masked_knn(
                p1, p2, mask2, self.nsamples, self.radius, self.query_chunk_size
            )
        else:
            if not isinstance(neighbor_info, (tuple, list)) or len(neighbor_info) != 2:
                raise TypeError('neighbor_info must be (idx, neigh_valid)')
            idx, neigh_valid = neighbor_info
            require_ndim('neighbor idx', idx, 3)
            require_ndim('neighbor valid', neigh_valid, 3)
            if idx.shape != neigh_valid.shape:
                raise ValueError(f'neighbor idx/valid shape mismatch: {tuple(idx.shape)} vs {tuple(neigh_valid.shape)}')
            if idx.shape[:2] != p1.shape[:2]:
                raise ValueError(f'neighbor query dims mismatch: idx={tuple(idx.shape)}, p1={tuple(p1.shape)}')

        p2g = gather_neighbors(p2, idx)
        s2g = gather_neighbors(s2, idx)
        disp = p2g - p1[:, :, None, :]
        parts = [s2g]
        if self.in_channels > 0:
            parts.append(x1[:, :, None, :].expand(-1, -1, idx.shape[-1], -1))
        parts.append(disp)
        corr = torch.cat(parts, dim=-1)
        expected_in = self.net[0].in_features
        if corr.shape[-1] != expected_in:
            raise ValueError(f'Linear input dim mismatch in correlation: expected {expected_in}, got {corr.shape[-1]}, corr={tuple(corr.shape)}')
        require_finite('corr', corr)
        out = self.net(corr)
        require_finite('correlation linear output', out)
        out = masked_max(out, neigh_valid, dim=2)
        out = out * mask1[..., None].to(out.dtype)
        require_finite('correlation output', out)
        return out


class MaskedPointLSTMCell(nn.Module):
    """PointLSTM cell with explicit masks for current and previous point sets."""
    def __init__(self, radius, nsamples, in_channels, out_channels, query_chunk_size=128):
        super().__init__()
        self.nsamples = int(nsamples)
        self.radius = float(radius)
        self.in_channels = int(in_channels)
        self.out_channels = int(out_channels)
        self.query_chunk_size = int(query_chunk_size)
        self.i_corr = MaskedSpatioTemporalCorrelation(radius, nsamples, in_channels, out_channels, query_chunk_size)
        self.f_corr = MaskedSpatioTemporalCorrelation(radius, nsamples, in_channels, out_channels, query_chunk_size)
        self.o_corr = MaskedSpatioTemporalCorrelation(radius, nsamples, in_channels, out_channels, query_chunk_size)
        self.c_new = MaskedSpatioTemporalCorrelation(radius, nsamples, in_channels, out_channels, query_chunk_size)
        self.c_old = MaskedSpatioTemporalCorrelation(radius, nsamples, 0, out_channels, query_chunk_size)

    def _validate_state(self, state, batch_size):
        if state is None:
            return
        if not isinstance(state, (tuple, list)) or len(state) != 4:
            raise TypeError('PointLSTM state must be (p, h, c, mask)')
        p2, h2, c2, mask2 = state
        require_ndim('state.p', p2, 3)
        require_ndim('state.h', h2, 3)
        require_ndim('state.c', c2, 3)
        if p2.shape[0] != batch_size or h2.shape[0] != batch_size or c2.shape[0] != batch_size:
            raise ValueError(f'State batch mismatch: p={tuple(p2.shape)}, h={tuple(h2.shape)}, c={tuple(c2.shape)}, expected B={batch_size}')
        if p2.shape[-1] != 3:
            raise ValueError(f'State p last dim must be 3, got {tuple(p2.shape)}')
        if p2.shape[:2] != h2.shape[:2] or p2.shape[:2] != c2.shape[:2]:
            raise ValueError(f'State point dims mismatch: p={tuple(p2.shape)}, h={tuple(h2.shape)}, c={tuple(c2.shape)}')
        if h2.shape[-1] != self.out_channels or c2.shape[-1] != self.out_channels:
            raise ValueError(f'State hidden dim mismatch: expected {self.out_channels}, h={h2.shape[-1]}, c={c2.shape[-1]}')
        require_mask('state.mask', mask2, p2.shape[:2])
        require_same_device(('state.p', p2), ('state.h', h2), ('state.c', c2), ('state.mask', mask2))
        require_finite('state.p', p2)
        require_finite('state.h', h2)
        require_finite('state.c', c2)

    def forward(self, p1, x1, mask1, state=None):
        require_ndim('cell p1', p1, 3)
        require_ndim('cell x1', x1, 3)
        require_mask('cell mask1', mask1, p1.shape[:2])
        require_same_device(('p1', p1), ('x1', x1), ('mask1', mask1))
        if p1.shape[-1] != 3:
            raise ValueError(f'cell p1 last dim must be 3, got {tuple(p1.shape)}')
        if p1.shape[:2] != x1.shape[:2] or x1.shape[-1] != self.in_channels:
            raise ValueError(f'cell x1 mismatch: expected [B,N,{self.in_channels}] matching p1; p1={tuple(p1.shape)}, x1={tuple(x1.shape)}')
        require_finite('cell p1', p1)
        require_finite('cell x1', x1)
        self._validate_state(state, p1.size(0))

        if state is None:
            p2 = p1
            mask2 = mask1
            h2 = torch.zeros(p1.size(0), p1.size(1), self.out_channels, device=p1.device, dtype=p1.dtype)
            c2 = torch.zeros_like(h2)
        else:
            p2, h2, c2, mask2 = state
            if p2.device != p1.device or h2.device != p1.device or c2.device != p1.device or mask2.device != p1.device:
                raise RuntimeError(f'Current/state device mismatch: current={p1.device}, state p/h/c/m={p2.device}/{h2.device}/{c2.device}/{mask2.device}')
            no_prev = ~mask2.any(dim=1)
            if no_prev.any():
                if p2.shape[1] != p1.shape[1]:
                    raise ValueError(
                        'Cannot replace an all-padding previous state with current points because T changed between time steps: '
                        f'prev T={p2.shape[1]}, current T={p1.shape[1]}. Collate should use one fixed T within a batch.'
                    )
                sel = no_prev[:, None, None]
                p2 = torch.where(sel, p1, p2)
                h2 = torch.where(sel, torch.zeros_like(h2), h2)
                c2 = torch.where(sel, torch.zeros_like(c2), c2)
                mask2 = torch.where(no_prev[:, None], mask1, mask2)

        idx, neigh_valid, _ = masked_knn(
            p1, p2, mask2, self.nsamples, self.radius, self.query_chunk_size
        )
        neighbor_info = (idx, neigh_valid)
        i = torch.sigmoid(self.i_corr(p1, p2, x1, h2, mask1, mask2, neighbor_info))
        f = torch.sigmoid(self.f_corr(p1, p2, x1, h2, mask1, mask2, neighbor_info))
        o = torch.sigmoid(self.o_corr(p1, p2, x1, h2, mask1, mask2, neighbor_info))
        c_new = torch.tanh(self.c_new(p1, p2, x1, h2, mask1, mask2, neighbor_info))
        c_old = self.c_old(p1, p2, None, c2, mask1, mask2, neighbor_info)
        c1 = f * c_old + i * c_new
        h1 = o * torch.tanh(c1)
        m = mask1[..., None].to(h1.dtype)
        h1, c1 = h1 * m, c1 * m
        require_finite('cell c1', c1)
        require_finite('cell h1', h1)
        return p1, h1, c1, mask1


class RadarPointLSTMClassifier(nn.Module):
    """Input xyz/features/mask [B,L,T,*], output point logits [B,L,T,2]."""
    def __init__(self, feature_dim, hidden_dims=(32, 64, 64), radius=(0.08, 0.16, 0.24),
                 nsamples=(8, 8, 8), dropout=0.1, knn_query_chunk_size=128):
        super().__init__()
        self.feature_dim = int(feature_dim)
        if self.feature_dim <= 0:
            raise ValueError(f'feature_dim must be > 0, got {feature_dim}')
        if not hidden_dims or any(int(x) <= 0 for x in hidden_dims):
            raise ValueError(f'hidden_dims must contain positive integers, got {hidden_dims}')
        if isinstance(radius, (int, float)):
            radius = (radius,) * len(hidden_dims)
        if isinstance(nsamples, int):
            nsamples = (nsamples,) * len(hidden_dims)
        if not (len(hidden_dims) == len(radius) == len(nsamples)):
            raise ValueError(f'hidden_dims/radius/nsamples length mismatch: {len(hidden_dims)}/{len(radius)}/{len(nsamples)}')
        if any(float(r) <= 0 for r in radius):
            raise ValueError(f'All radius values must be > 0, got {radius}')
        if any(int(k) <= 0 for k in nsamples):
            raise ValueError(f'All nsamples values must be > 0, got {nsamples}')
        self.input_embed = nn.Sequential(
            nn.Linear(self.feature_dim, hidden_dims[0]), nn.ReLU(inplace=True),
            nn.LayerNorm(hidden_dims[0])
        )
        cells = []
        in_c = hidden_dims[0]
        for h, r, k in zip(hidden_dims, radius, nsamples):
            cells.append(MaskedPointLSTMCell(r, k, in_c, h, knn_query_chunk_size))
            in_c = h
        self.cells = nn.ModuleList(cells)
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dims[-1], hidden_dims[-1]),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(hidden_dims[-1], 2),
        )

    def forward(self, xyz, features, mask):
        validate_model_batch(xyz, features, mask, feature_dim=self.feature_dim, stage='RadarPointLSTMClassifier.forward')
        B, L, T, _ = xyz.shape
        states = [None for _ in self.cells]
        outputs = []
        for t in range(L):
            p = xyz[:, t]
            m = mask[:, t]
            feat_t = features[:, t]
            if feat_t.shape[-1] != self.input_embed[0].in_features:
                raise ValueError(
                    f't={t}: input_embed expects F={self.input_embed[0].in_features}, got F={feat_t.shape[-1]}'
                )
            x = self.input_embed(feat_t)
            require_finite(f't={t} input_embed output', x)
            x = x * m[..., None].to(x.dtype)
            for i, cell in enumerate(self.cells):
                try:
                    states[i] = cell(p, x, m, states[i])
                except Exception as exc:
                    raise type(exc)(f'PointLSTM layer={i}, time={t} failed: {exc}') from exc
                x = states[i][1]
            logits = self.classifier(x)
            if tuple(logits.shape) != (B, T, 2):
                raise RuntimeError(f't={t}: classifier output shape {tuple(logits.shape)} != expected {(B, T, 2)}')
            require_finite(f't={t} logits', logits)
            logits = logits * m[..., None].to(logits.dtype)
            outputs.append(logits)
        if len(outputs) != L:
            raise RuntimeError(f'Expected {L} time-step outputs, got {len(outputs)}')
        out = torch.stack(outputs, dim=1)
        if tuple(out.shape) != (B, L, T, 2):
            raise RuntimeError(f'Final output shape mismatch: got {tuple(out.shape)}, expected {(B, L, T, 2)}')
        require_finite('model output', out)
        return out
