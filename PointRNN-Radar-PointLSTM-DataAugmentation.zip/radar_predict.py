import argparse, csv
from pathlib import Path
import torch
from torch.utils.data import DataLoader
from radar.dataset import RadarSequenceDataset, radar_collate_fn, load_config
from radar.model import RadarPointLSTMClassifier


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--csv',required=True); ap.add_argument('--config',default='radar_config.json')
    ap.add_argument('--checkpoint',required=True); ap.add_argument('--output',default='radar_predictions.csv'); ap.add_argument('--split',default='all',choices=['train','val','test','all'])
    args=ap.parse_args(); cfg=load_config(args.config); ds=RadarSequenceDataset(args.csv,cfg,args.split)
    loader=DataLoader(ds,batch_size=cfg['train']['batch_size'],shuffle=False,num_workers=0,collate_fn=radar_collate_fn)
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'); ck=torch.load(args.checkpoint,map_location=device)
    model=RadarPointLSTMClassifier(len(ds.feature_cols),tuple(cfg['model']['hidden_dims']),tuple(cfg['model']['radius']),tuple(cfg['model']['nsamples']),cfg['model'].get('dropout',0.1)).to(device)
    model.load_state_dict(ck['model']); model.eval(); rows=[]
    with torch.no_grad():
        for batch in loader:
            logits=model(batch['xyz'].to(device),batch['features'].to(device),batch['mask'].to(device))
            prob=logits.softmax(-1)[...,1].cpu(); pred=logits.argmax(-1).cpu()
            for b in range(prob.size(0)):
                for t in range(prob.size(1)):
                    valid=torch.where(batch['mask'][b,t])[0]
                    for j in valid.tolist():
                        rows.append([int(batch['rounds'][b,t]),int(batch['sector'][b]),t,j,float(prob[b,t,j]),int(pred[b,t,j]),int(batch['labels'][b,t,j])])
    with open(args.output,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f); w.writerow(['round_id','sector_id','sequence_t','point_index_in_frame','target_probability','pred_label','gt_label']); w.writerows(rows)
    print(f'wrote {len(rows)} point predictions to {args.output}')
if __name__=='__main__': main()
