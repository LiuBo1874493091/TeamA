import argparse
import json
import os
import random
import time
import csv
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader
from tqdm import tqdm

from radar.dataset import RadarSequenceDataset, radar_collate_fn, load_config
from radar.model import RadarPointLSTMClassifier
from radar.metrics import BinaryMetrics
from radar.validation import validate_model_batch, validate_logits


def load_checkpoint_compat(path, map_location):
    """Load our own training checkpoint across PyTorch <2.6 and >=2.6."""
    try:
        return torch.load(path, map_location=map_location, weights_only=False)
    except TypeError:
        # Older PyTorch versions do not have weights_only.
        return torch.load(path, map_location=map_location)


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def make_loader(ds, cfg, shuffle=False):
    return DataLoader(
        ds,
        batch_size=cfg['train']['batch_size'],
        shuffle=shuffle,
        num_workers=cfg['train'].get('workers', 0),
        collate_fn=radar_collate_fn,
        pin_memory=torch.cuda.is_available(),
        persistent_workers=cfg['train'].get('workers', 0) > 0,
    )


def _gpu_memory_text(device):
    if device.type != 'cuda' or not torch.cuda.is_available():
        return ''
    allocated = torch.cuda.memory_allocated(device) / (1024 ** 2)
    reserved = torch.cuda.memory_reserved(device) / (1024 ** 2)
    return f'GPU {allocated:.0f}/{reserved:.0f} MiB alloc/reserved'


def run_epoch(model, loader, optimizer, device, class_weights=None, epoch=0, phase='train'):
    train = optimizer is not None
    model.train(train)
    criterion = nn.CrossEntropyLoss(weight=class_weights, ignore_index=-100)
    metrics = BinaryMetrics()
    total_loss = 0.0
    total_batches = 0
    start = time.perf_counter()
    bar = tqdm(loader, desc=f'{phase} Epoch {epoch + 1}', unit='batch', dynamic_ncols=True, leave=False)

    for step, batch in enumerate(bar):
        xyz = batch['xyz'].to(device, non_blocking=True)
        feat = batch['features'].to(device, non_blocking=True)
        labels = batch['labels'].to(device, non_blocking=True)
        mask = batch['mask'].to(device, non_blocking=True)
        if step == 0:
            valid_counts = mask.sum(dim=-1)
            print(
                f'[{phase} epoch {epoch + 1}] 首批张量：xyz={tuple(xyz.shape)}, '
                f'features={tuple(feat.shape)}, labels={tuple(labels.shape)}, '
                f'mask有效点={int(mask.sum())}/{mask.numel()}, '
                f'单帧点数范围={int(valid_counts.min())}~{int(valid_counts.max())}; '
                f'device={device}; {_gpu_memory_text(device)}',
                flush=True,
            )
        validate_model_batch(
            xyz, feat, mask, labels=labels, feature_dim=model.feature_dim,
            stage=f'{phase} epoch={epoch + 1} batch={step}'
        )

        with torch.set_grad_enabled(train):
            try:
                logits = model(xyz, feat, mask)
            except RuntimeError as exc:
                if 'CUBLAS_STATUS_EXECUTION_FAILED' in str(exc) or 'CUDA' in str(exc):
                    raise RuntimeError(
                        f'Model forward failed on {device}. Batch shapes: xyz={tuple(xyz.shape)}, '
                        f'features={tuple(feat.shape)}, mask={tuple(mask.shape)}, '
                        f'valid_points={int(mask.sum())}. Try batch_size=1, '
                        f'max_points_per_frame=128/256, smaller hidden_dims, or run with --debug-cuda. '
                        f'Original error: {exc}'
                    ) from exc
                raise
            validate_logits(logits, labels, mask)
            if logits.numel() == 0:
                raise RuntimeError(f'{phase} epoch={epoch + 1} batch={step}: model returned an empty logits tensor.')
            loss = criterion(logits.reshape(-1, 2), labels.reshape(-1))
            if not torch.isfinite(loss):
                raise RuntimeError('Loss is NaN/Inf. Check labels, class_weights, and valid-point counts.')
            if train:
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                bad_grad = []
                for name, p in model.named_parameters():
                    if p.grad is not None and not torch.isfinite(p.grad).all():
                        bad_grad.append(name)
                if bad_grad:
                    raise RuntimeError(
                        f'NaN/Inf gradient detected at {phase} epoch={epoch + 1} batch={step}; '
                        f'parameters={bad_grad[:20]}'
                    )
                grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                if not torch.isfinite(torch.as_tensor(grad_norm)):
                    raise RuntimeError(f'Gradient norm is NaN/Inf at epoch={epoch + 1}, batch={step}: {grad_norm}')
                optimizer.step()
                bad_param = []
                for name, p in model.named_parameters():
                    if not torch.isfinite(p).all():
                        bad_param.append(name)
                if bad_param:
                    raise RuntimeError(
                        f'NaN/Inf parameter detected after optimizer.step at epoch={epoch + 1}, batch={step}; '
                        f'parameters={bad_param[:20]}'
                    )

        loss_value = float(loss.detach().item())
        total_loss += loss_value
        total_batches += 1
        metrics.update(logits.detach(), labels, mask)
        postfix = {'loss': f'{total_loss / total_batches:.4f}', 'T': xyz.shape[2]}
        if device.type == 'cuda':
            postfix['GPU MiB'] = int(torch.cuda.memory_allocated(device) / (1024 ** 2))
        bar.set_postfix(postfix)

    elapsed = time.perf_counter() - start
    out = metrics.compute()
    out['loss'] = total_loss / max(total_batches, 1)
    out['seconds'] = elapsed
    return out



def save_history_and_curves(history, out_dir):
    """Persist epoch-level metrics and overwrite curves after every epoch."""
    if not history:
        return
    out_dir = Path(out_dir)
    csv_path = out_dir / 'train_history.csv'
    fields = ['epoch', 'train_loss', 'val_loss', 'train_precision', 'train_recall', 'train_f1', 'val_precision', 'val_recall', 'val_f1', 'epoch_seconds']
    with csv_path.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(history)

    epochs = [x['epoch'] for x in history]
    plt.figure(figsize=(8, 5))
    plt.plot(epochs, [x['train_loss'] for x in history], marker='o', label='Train Loss')
    plt.plot(epochs, [x['val_loss'] for x in history], marker='o', label='Val Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training / Validation Loss')
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_dir / 'loss_curve.png', dpi=160)
    plt.close()

    plt.figure(figsize=(8, 5))
    plt.plot(epochs, [x['train_f1'] for x in history], marker='o', label='Train F1')
    plt.plot(epochs, [x['val_f1'] for x in history], marker='o', label='Val F1')
    plt.xlabel('Epoch')
    plt.ylabel('F1')
    plt.title('Training / Validation F1')
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_dir / 'f1_curve.png', dpi=160)
    plt.close()

    plt.figure(figsize=(8, 5))
    plt.plot(epochs, [x['train_recall'] for x in history], marker='o', label='Train Point Recall')
    plt.plot(epochs, [x['val_recall'] for x in history], marker='o', label='Val Point Recall')
    plt.xlabel('Epoch')
    plt.ylabel('Recall')
    plt.title('Point-wise Positive-class Recall')
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_dir / 'recall_curve.png', dpi=160)
    plt.close()


def main():
    ap = argparse.ArgumentParser(description='Train radar point-wise PointLSTM classifier')
    ap.add_argument('--csv', required=True)
    ap.add_argument('--config', default='radar_config.json')
    ap.add_argument('--output', default='outputs/radar_pointlstm')
    ap.add_argument('--resume', default='')
    ap.add_argument('--cache-path', default='', help='Persistent preprocessing cache path. Default: <csv>.radar_cache.pkl')
    ap.add_argument('--rebuild-cache', action='store_true', help='Ignore and rebuild persistent preprocessing cache.')
    ap.add_argument('--debug-cuda', action='store_true', help='Set CUDA_LAUNCH_BLOCKING=1 for a more precise CUDA traceback.')
    args = ap.parse_args()
    if args.debug_cuda:
        os.environ['CUDA_LAUNCH_BLOCKING'] = '1'

    cfg = load_config(args.config)
    seed_all(cfg['train'].get('seed', 42))
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)

    print('[1/4] 准备数据集（CSV 只预处理一次，train/val 共享结果）...', flush=True)
    cache_path = args.cache_path or None
    train_ds = RadarSequenceDataset(args.csv, cfg, 'train', cache_path=cache_path, rebuild_cache=args.rebuild_cache)
    val_ds = RadarSequenceDataset(args.csv, cfg, 'val', prepared=train_ds.prepared)
    test_samples = len(train_ds.prepared['samples_by_split'].get('test', []))
    train_loader = make_loader(train_ds, cfg, True)
    val_loader = make_loader(val_ds, cfg, False)
    print(f'[2/4] DataLoader 就绪：train={len(train_ds):,} samples/{len(train_loader):,} batches; '
          f'val={len(val_ds):,} samples/{len(val_loader):,} batches; test={test_samples:,} samples; '
          f'batch_size={cfg["train"]["batch_size"]}', flush=True)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'[3/4] 初始化模型，device={device}; CUDA available={torch.cuda.is_available()}', flush=True)
    model = RadarPointLSTMClassifier(
        len(train_ds.feature_cols),
        hidden_dims=tuple(cfg['model']['hidden_dims']),
        radius=tuple(cfg['model']['radius']),
        nsamples=tuple(cfg['model']['nsamples']),
        dropout=cfg['model'].get('dropout', 0.1),
        knn_query_chunk_size=cfg['model'].get('knn_query_chunk_size', 128),
    ).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=cfg['train']['lr'],
                            weight_decay=cfg['train'].get('weight_decay', 1e-4))
    start_epoch = 0
    best = -1.0
    best_metric = str(cfg['train'].get('best_metric', 'recall')).lower()
    if best_metric not in ('recall', 'f1'):
        raise ValueError(f"train.best_metric must be 'recall' or 'f1', got {best_metric!r}")
    if args.resume:
        ck = load_checkpoint_compat(args.resume, device)
        model.load_state_dict(ck['model'])
        opt.load_state_dict(ck['optimizer'])
        start_epoch = ck['epoch'] + 1
        best = ck.get('best_score', ck.get('best_f1', -1.0))
        print(f'从 checkpoint 恢复：epoch={start_epoch}', flush=True)
    weights = cfg['train'].get('class_weights')
    if weights is not None:
        if not isinstance(weights, (list, tuple)) or len(weights) != 2:
            raise ValueError(f'train.class_weights must be null or [weight_for_0, weight_for_1], got {weights}')
        if any(float(w) <= 0 for w in weights):
            raise ValueError(f'train.class_weights must be positive, got {weights}')
    class_weights = torch.tensor(weights, dtype=torch.float32, device=device) if weights else None
    with open(out / 'resolved_config.json', 'w', encoding='utf-8') as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    with open(out / 'dataset_split_summary.json', 'w', encoding='utf-8') as f:
        json.dump({
            'split_policy': train_ds.prepared.get('split_policy'),
            'filter_stats': train_ds.prepared.get('filter_stats', {}),
            'split_stats': train_ds.prepared.get('split_stats', {}),
        }, f, ensure_ascii=False, indent=2)

    print('[4/4] 开始训练。每个 epoch 都会显示 batch 进度条；Ctrl+C 可中断，已保存的 checkpoint 不受影响。', flush=True)
    history = []
    history_path = out / 'train_history.csv'
    if history_path.exists() and start_epoch > 0:
        try:
            import pandas as pd
            history = pd.read_csv(history_path).to_dict('records')
            required_history = {
                'epoch', 'train_loss', 'val_loss', 'train_precision', 'train_recall',
                'train_f1', 'val_precision', 'val_recall', 'val_f1', 'epoch_seconds'
            }
            if history and not required_history.issubset(history[0].keys()):
                print('旧版 train_history.csv 缺少逐点 Recall 字段，将从本次续训开始重新记录曲线。', flush=True)
                history = []
        except Exception:
            history = []
    for epoch in range(start_epoch, cfg['train']['epochs']):
        epoch_start = time.perf_counter()
        tr = run_epoch(model, train_loader, opt, device, class_weights, epoch, 'train')
        va = run_epoch(model, val_loader, None, device, class_weights, epoch, 'val')
        print(
            f'epoch={epoch + 1:03d}/{cfg["train"]["epochs"]} '
            f'train loss={tr["loss"]:.4f} pointR={tr["recall"]:.4f} f1={tr["f1"]:.4f} ({tr["seconds"]:.1f}s) | '
            f'val loss={va["loss"]:.4f} pointR={va["recall"]:.4f} f1={va["f1"]:.4f} '
            f'P={va["precision"]:.4f} R={va["recall"]:.4f} ({va["seconds"]:.1f}s) | '
            f'epoch total={time.perf_counter() - epoch_start:.1f}s', flush=True
        )
        epoch_seconds = time.perf_counter() - epoch_start
        history.append({
            'epoch': epoch + 1,
            'train_loss': tr['loss'],
            'val_loss': va['loss'],
            'train_precision': tr['precision'],
            'train_recall': tr['recall'],
            'train_f1': tr['f1'],
            'val_precision': va['precision'],
            'val_recall': va['recall'],
            'val_f1': va['f1'],
            'epoch_seconds': epoch_seconds,
        })
        save_history_and_curves(history, out)
        print(f'  曲线已更新：loss/F1/point-recall；历史数据：{out / "train_history.csv"}', flush=True)
        current_score = va[best_metric]
        ck = {
            'model': model.state_dict(), 'optimizer': opt.state_dict(), 'epoch': epoch,
            'best_score': max(best, current_score), 'best_metric': best_metric,
            'best_f1': va['f1'], 'best_recall': va['recall'],
            'feature_cols': train_ds.feature_cols,
            'feature_mean': train_ds.feature_mean, 'feature_std': train_ds.feature_std, 'config': cfg,
        }
        torch.save(ck, out / 'last.pth')
        if current_score > best:
            best = current_score
            torch.save(ck, out / 'best.pth')
            print(
                f'  新的最佳模型已保存：{out / "best.pth"} '
                f'(val point {best_metric}={best:.4f})', flush=True
            )


if __name__ == '__main__':
    main()
