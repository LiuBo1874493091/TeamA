# Defensive checks added for CUDA / CUBLAS debugging

This version adds explicit CPU/Python-side validation so common data/model bugs fail before CUDA reports a vague `CUBLAS_STATUS_EXECUTION_FAILED`.

## Main checks

- Empty batch / empty sequence / empty T / empty feature dimension.
- Entire batch is padding (zero valid points).
- `xyz`, `features`, `mask`, `labels` dimensional consistency.
- `xyz[...,3]` and model feature dimension consistency.
- Mask must be `torch.bool` and match `[B,L,T]`.
- Labels at valid points must be only 0/1; padding labels must be -100.
- NaN/Inf checks for input, hidden states, correlations, logits, loss, gradients, and parameters.
- Tensor device consistency checks.
- PointLSTM hidden-state shape/channel checks.
- KNN arguments `k`, `radius`, `query_chunk_size` validation.
- KNN/gather neighbor index lower/upper-bound checks before `torch.gather`.
- KNN output shape checks.
- Linear input-channel checks before calling the linear layer.
- Final model output must be exactly `[B,L,T,2]`.
- Error messages include PointLSTM layer and time-step where possible.

## Files changed

- `radar/validation.py` (new)
- `radar/dataset.py`
- `radar/masked_ops.py`
- `radar/model.py`
- `radar_train.py`
- `radar_test.py`

## CUDA debugging

Use the existing synchronous CUDA debug mode when a CUDA error remains:

```bat
python radar_train.py --csv .\data\data.csv --config radar_config.json --output outputs\exp1 --debug-cuda
```

The defensive checks are intended to catch logic/data errors. They cannot prevent CUDA driver, PyTorch/CUDA version, hardware, or genuine out-of-memory failures.
