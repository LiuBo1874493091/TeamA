import argparse
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm

from radar.dataset import RadarSequenceDataset, radar_collate_fn, load_config
from radar.model import RadarPointLSTMClassifier
from radar.metrics import BinaryMetrics
from radar.validation import validate_model_batch, validate_logits


def load_checkpoint_compat(path, map_location):
    """Load our own training checkpoint across PyTorch <2.6 and >=2.6."""
    try:
        return torch.load(path, map_location=map_location, weights_only=False)
    except TypeError:
        # Older PyTorch versions do not have weights_only.
        return torch.load(path, map_location=map_location)


def main():
    ap = argparse.ArgumentParser(description='Evaluate the fixed test split with a trained checkpoint')
    ap.add_argument('--csv', required=True)
    ap.add_argument('--config', default='radar_config.json')
    ap.add_argument('--checkpoint', required=True)
    ap.add_argument('--cache-path', default='')
    args = ap.parse_args()

    cfg = load_config(args.config)
    ds = RadarSequenceDataset(args.csv, cfg, 'test', cache_path=args.cache_path or None)
    loader = DataLoader(
        ds,
        batch_size=cfg['train']['batch_size'],
        shuffle=False,
        num_workers=cfg['train'].get('workers', 0),
        collate_fn=radar_collate_fn,
        pin_memory=torch.cuda.is_available(),
    )

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    ck = load_checkpoint_compat(args.checkpoint, device)
    model = RadarPointLSTMClassifier(
        len(ds.feature_cols),
        hidden_dims=tuple(cfg['model']['hidden_dims']),
        radius=tuple(cfg['model']['radius']),
        nsamples=tuple(cfg['model']['nsamples']),
        dropout=cfg['model'].get('dropout', 0.1),
        knn_query_chunk_size=cfg['model'].get('knn_query_chunk_size', 128),
    ).to(device)
    model.load_state_dict(ck['model'])
    model.eval()

    weights = cfg['train'].get('class_weights')
    if weights is not None:
        if not isinstance(weights, (list, tuple)) or len(weights) != 2:
            raise ValueError(f'train.class_weights must be null or [weight_for_0, weight_for_1], got {weights}')
        if any(float(w) <= 0 for w in weights):
            raise ValueError(f'train.class_weights must be positive, got {weights}')
    class_weights = torch.tensor(weights, dtype=torch.float32, device=device) if weights else None
    criterion = nn.CrossEntropyLoss(weight=class_weights, ignore_index=-100)
    metrics = BinaryMetrics()
    loss_sum = 0.0
    n_batches = 0

    with torch.no_grad():
        for batch in tqdm(loader, desc='test', unit='batch', dynamic_ncols=True):
            xyz = batch['xyz'].to(device, non_blocking=True)
            feat = batch['features'].to(device, non_blocking=True)
            labels = batch['labels'].to(device, non_blocking=True)
            mask = batch['mask'].to(device, non_blocking=True)
            validate_model_batch(xyz, feat, mask, labels=labels, feature_dim=model.feature_dim, stage='test')
            logits = model(xyz, feat, mask)
            validate_logits(logits, labels, mask)
            loss = criterion(logits.reshape(-1, 2), labels.reshape(-1))
            loss_sum += float(loss.item())
            n_batches += 1
            metrics.update(logits, labels, mask)

    result = metrics.compute()
    result['loss'] = loss_sum / max(n_batches, 1)
    print('\n===== TEST RESULT =====')
    print(f"samples   : {len(ds)}")
    stat = ds.prepared.get('split_stats', {}).get('test', {})
    print(f"target pts: {stat.get('target_points', 0)}")
    print(f"clutter pts: {stat.get('clutter_points', 0)}")
    print(f"loss      : {result['loss']:.6f}")
    print(f"accuracy  : {result['accuracy']:.6f}")
    print(f"precision : {result['precision']:.6f}")
    print(f"recall(point, positive class): {result['recall']:.6f}")
    print(f"f1        : {result['f1']:.6f}")
    print(f"TP/FP/TN/FN: {result['tp']}/{result['fp']}/{result['tn']}/{result['fn']}")


if __name__ == '__main__':
    main()
