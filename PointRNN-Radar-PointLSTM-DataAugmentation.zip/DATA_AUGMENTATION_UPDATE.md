# 雷达点迹数据增强更新

## 1. 启用方式

`radar_config.json` 新增 `augmentation`：

```json
"augmentation": {
  "enabled": false,
  "apply_probability": 1.0,
  "range_jitter_std_m": 5.0,
  "azimuth_jitter_std_deg": 0.05,
  "feature_gaussian_noise_std": {
    "I": 0.01,
    "Q": 0.01,
    "phase": 0.01,
    "SNR": 0.2
  },
  "point_dropout_probability": 0.0,
  "dropout_target_points": false,
  "clutter_injection_ratio": 0.0,
  "clutter_injection_max_per_frame": 32
}
```

把 `enabled` 改为 `true` 即可启用。增强只作用于训练集，验证集和测试集不增强。

## 2. 执行顺序

完整流程：

1. 生成全部滑窗；
2. 删除全杂波窗口；
3. 划分 train/val/test；
4. train/val（以及可配置的 test）进行杂波下采样；
5. `train.__getitem__` 读取样本；
6. 对训练样本在线数据增强；
7. collate + padding + mask；
8. 输入 PointLSTM。

因此数据增强不会写回缓存，每个 epoch 可以产生不同扰动，也不会污染 val/test。

## 3. 参数说明

- `enabled`：是否启用训练数据增强。
- `apply_probability`：一个训练样本执行增强的概率，范围 0~1。
- `range_jitter_std_m`：距离高斯扰动标准差，单位米。
- `azimuth_jitter_std_deg`：方位角高斯扰动标准差，单位度。
- `feature_gaussian_noise_std`：按 CSV 特征原始单位添加高斯噪声。键必须存在于 `columns.features`。
- `point_dropout_probability`：有效点随机丢弃概率。
- `dropout_target_points`：false 时只随机丢弃杂波点；true 时目标点也可丢弃，但代码保证原本含目标的样本不会把所有目标全部删掉。
- `clutter_injection_ratio`：每一帧新增杂波点数约等于当前有效点数乘该比例。
- `clutter_injection_max_per_frame`：每帧最多新增多少个杂波点，0 表示不额外限制。

## 4. 几何一致性

距离/方位增强先作用于物理量，再重新计算 xyz。若 `features` 中包含配置的 range/azimuth/elevation 列，这些 feature 会同步更新，因此不会出现“xyz 变了但 range/azimuth 还是旧值”的问题。

## 5. 建议初始配置

先只开启轻微几何和观测噪声：

```json
"enabled": true,
"apply_probability": 0.8,
"range_jitter_std_m": 3.0,
"azimuth_jitter_std_deg": 0.03,
"feature_gaussian_noise_std": {
  "I": 0.01,
  "Q": 0.01,
  "phase": 0.01,
  "SNR": 0.2
},
"point_dropout_probability": 0.0,
"clutter_injection_ratio": 0.0
```

等基线稳定后，再逐步加入点丢弃和杂波注入做消融实验。
