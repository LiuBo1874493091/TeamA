# Radar PointLSTM — 30°扇区、多圈序列、逐点二分类

本分支在原 PointRNN-PyTorch 项目基础上新增雷达点迹任务，不再做“未来点云位置预测”，而是做“跨圈点集序列中的逐点真/假分类”。

## 1. 张量定义

- 输入 `xyz`: `[B, L, T, 3]`
- 输入 `features`: `[B, L, T, F]`
- 输入 `mask`: `[B, L, T]`，`True` 表示真实点，`False` 表示 padding
- 标签 `labels`: `[B, L, T]`，真实点=1，虚假点=0，padding=-100
- 输出 `logits`: `[B, L, T, 2]`

如果外部接口必须使用 `[B,T,L,2]`，仅在输出处执行：
`logits = logits.permute(0, 2, 1, 3)`。

## 2. 30°样本组织

360°划为 12 个扇区：0~30、30~60、...、330~360°。同一扇区的连续 L 圈组成一个样本，并按 `sequence_stride` 滑窗。

圈号有两种来源：
1. CSV 存在圈号列：在 `radar_config.json -> columns.round_id` 填列名；
2. 没有圈号列：保持 CSV 行按采集时间排序，程序检测“方位角突然从大值跳回小值”自动判定新的一圈。

## 3. Padding mask 是真正进入模型内部的

这版没有仅在 loss 阶段忽略 padding。新增 `radar/masked_ops.py`：所有跨时刻邻域搜索都只允许 `mask=True` 的历史点成为邻居；padding 不进入 PointLSTM 时空相关计算。分类 loss 同时使用 `ignore_index=-100` 二次屏蔽 padding。

为保证这一点，雷达模型使用纯 PyTorch 的 masked KNN/radius query，不依赖原仓库 PointNet++ CUDA 扩展。代价是点数很多时速度慢于自定义 CUDA，但逻辑更明确、可先验证方案。

## 4. CSV 最少需要的字段

必须能映射：
- 距离
- 方位角（度，0~360）
- 二分类真值标签

可选：
- 圈号
- 俯仰角
- I、Q、相位、SNR、速度、幅度、RCS 等任意数值特征

运行 `python inspect_radar_csv.py --csv your.csv` 可查看实际列名，然后改 `radar_config.json`。

## 5. 首先必须修改的配置

`radar_config.json` 中：

- `columns.range`: 你的距离列名
- `columns.azimuth`: 你的方位列名
- `columns.label`: 你的真/假标签列名
- `columns.round_id`: 有现成圈号就填写；没有则保持 `null`
- `columns.features`: 想送入网络的点属性列
- `data.positive_label_values`: CSV 中哪些值代表真实目标点

## 6. 常用可调参数

### 数据相关
- `sector_width_deg`: 当前固定 30；以后改扇区宽度就在这里
- `sequence_length`: L，连续多少圈作为一个时序样本
- `sequence_stride`: 滑窗步长
- `range_scale`: 距离缩放。xyz 会由极坐标转换后除以该值；它与 radius 强相关
- `max_points_per_frame`: 每圈点数上限；建议先从 128/256 开始。超限时新版优先保留正类目标点，再抽样负类杂波，避免均匀抽样把稀少目标点删掉。设为 0 会使用 batch 动态最大点数，可能导致显存占用很高。
- `wrap_drop_deg`: 自动判圈阈值，一般 180°即可

### PointLSTM相关
- `hidden_dims`: 各层隐藏维度
- `radius`: 每层跨圈邻域半径，基于缩放后的 xyz；这是最关键的超参数之一
- `nsamples`: 每个当前点最多搜索多少个历史邻点
- `dropout`: 分类头 dropout

### 训练相关
- `batch_size`（显存不够时先设为 1）
- `epochs`
- `lr`
- `class_weights`: 若真实点远少于虚假点，可如 `[1.0, 5.0]`

## 7. 训练

```bash
pip install -r requirements-radar.txt
python inspect_radar_csv.py --csv data/plots.csv
# 修改 radar_config.json 列名后
python radar_train.py --csv data/plots.csv --config radar_config.json --output outputs/exp1
```

最佳模型：`outputs/exp1/best.pth`。

## 8. 推理

```bash
python radar_predict.py --csv data/plots.csv --config radar_config.json \
  --checkpoint outputs/exp1/best.pth --output predictions.csv --split all
```

## 9. 进度显示与性能保护

新版训练会显示 CSV 读取、序列窗口构建、样本索引、每个 Epoch 的 Batch 进度条，并打印张量形状、有效点数、Loss、耗时和 GPU 显存占用。训练/验证共享一次 CSV 预处理结果，避免重复读取和分组。

PointLSTM 每个 cell 的 5 个门原本会重复执行相同的 KNN 搜索；新版复用邻域索引，并对距离矩阵按 query 点分块计算，降低重复计算和峰值显存。

如果仍出现 CUDA/CUBLAS 报错：

1. 先把 `data.max_points_per_frame` 设为 `128` 或 `256`，`train.batch_size` 设为 `1`。
2. 如仍报错，运行 `python radar_train.py --csv data/plots.csv --config radar_config.json --debug-cuda`，以获得更准确的 CUDA 报错位置。
3. 确认 CSV 的 `range/azimuth/features` 都是有限数值，并确认 `round_id` 与 `label` 字段映射正确。

当前安全默认值为 `max_points_per_frame=256`、`batch_size=1`、`hidden_dims=[32,64,64]`。这套配置用于先稳定跑通；确认显存和速度后再逐步增加点数上限和模型宽度。由于模型宽度变化，旧模型 checkpoint 可能无法直接加载，需要重新训练。

## 10. 与原项目相比改了什么

原项目：固定点数点云 -> 前半序列编码 -> 后半序列未来位置预测 -> Chamfer Distance。

本实现：变长点集 + padding mask -> 每一圈都进入 PointLSTM -> 保留跨圈隐藏状态 -> 每个真实点输出二分类 logits -> masked CrossEntropy。

新增文件：
- `radar/dataset.py`: CSV、自动判圈、30°扇区、跨圈滑窗、动态 padding
- `radar/masked_ops.py`: mask-aware KNN/radius 邻域搜索
- `radar/model.py`: mask-aware PointLSTM 与逐点分类器
- `radar/metrics.py`: Accuracy/Precision/Recall/F1
- `radar_train.py`: 训练与 checkpoint
- `radar_predict.py`: 逐点预测导出
- `inspect_radar_csv.py`: CSV字段检查
- `radar_config.json`: 集中配置

原 Moving-MNIST 代码保留不动，便于对照。

## 11. 当前需要你特别确认的数据语义

代码可直接运行，但模型效果依赖下面两点是否正确映射：
1. `label` 到底是哪一列，以及真实点如何编码；
2. CSV 行是否按采集时间顺序排列。如果没有 round_id，自动判圈依赖这一点。

另外，如果点迹里有径向速度，建议务必加入 `columns.features`；对跨圈真实航迹筛选通常比单独 I/Q 更直接。
