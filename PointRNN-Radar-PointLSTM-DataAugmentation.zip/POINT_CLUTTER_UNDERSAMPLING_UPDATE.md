# 点迹级杂波下采样更新

本版数据流程：

1. 从完整 CSV 按扇区和连续圈生成全部滑窗样本。
2. 删除窗口内所有有效点标签均为 0 的纯杂波窗口。
3. 将剩余含目标窗口按样本随机划分 train / val / test。
4. train、val 在各自 split 内统计目标点迹出现次数 N，并从杂波点迹出现次数中随机保留 min(N, N_clutter) 个；所有目标点始终保留。
5. `split.sample_test_clutter=true` 时 test 也执行相同下采样；为 false 时 test 保留原始杂波分布。
6. padding 不参与统计、loss 或指标。Precision / Recall / F1 均按有效点迹逐点计算。

## 为什么先 split 再下采样

如果先对全部样本全局删掉杂波，再划分，就无法在 `sample_test_clutter=false` 时恢复 test 的原始杂波。因此当前实现先固定 train/val/test 样本，再分别构造点迹下采样计划。这样 train/val 可精确控制为约 1:1，test 可独立决定是否平衡。

## 配置

```json
"split": {
  "train_ratio": 0.7,
  "val_ratio": 0.15,
  "shuffle_samples": true,
  "sample_test_clutter": false
}
```

- `false`：train/val 下采样杂波；test 保留真实分布（推荐用于最终客观评估）。
- `true`：train/val/test 都下采样杂波，三者都更接近 1:1。

## 统计口径

统计的是模型在 `max_points_per_frame` 限制后真正看到的“点迹出现次数”。相邻滑窗若重复包含同一原始点迹，会按出现次数重复统计。

启用下采样时，一个 split 的目标点数为 N：

- 所有目标点保留；
- 若杂波点 >= N，随机保留 N 个杂波点；
- 若杂波点 < N，则全部保留，并打印警告。

随机采样受 `train.seed` 控制，可复现。
