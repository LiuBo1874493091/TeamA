import argparse, pandas as pd
p=argparse.ArgumentParser(); p.add_argument('--csv',required=True); a=p.parse_args()
df=pd.read_csv(a.csv)
print('rows:',len(df)); print('columns:')
for c in df.columns:
    s=df[c]
    print(f'  {c}: dtype={s.dtype}, nonnull={s.notna().sum()}, unique={s.nunique(dropna=True)}')
print('\nfirst 5 rows:'); print(df.head().to_string())
