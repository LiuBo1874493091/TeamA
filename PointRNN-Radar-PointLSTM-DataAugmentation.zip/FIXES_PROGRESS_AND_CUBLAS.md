# 进度显示与 CUBLAS 报错修复说明

## 本次改动

1. `radar/dataset.py`
   - CSV 分块读取时显示 tqdm 进度。
   - 将数据处理拆成字段/标签、圈扇区分组、滑窗、样本索引几个阶段并打印耗时/样本数。
   - 训练集和验证集共享一次预处理结果，不再把整份 CSV 读入并处理两遍。
   - `max_points_per_frame` 超限时优先保留 label=1 的目标点，再抽取 label=0 的杂波点。
2. `radar/model.py` 和 `radar/masked_ops.py`
   - 邻域距离矩阵按 query 点分块，降低 `torch.cdist` 的瞬时显存峰值。
   - 同一个 PointLSTM cell 的 I/F/O/C 门共享相同的 KNN 邻居索引，避免重复执行 5 次距离计算。
   - 检查输入 shape 和 NaN/Inf；CUDA 报错时输出 batch shape 和有效点数量。
3. `radar_train.py`
   - 训练和验证都显示 batch 进度条、平均 loss、当前 T、首批 tensor shape、GPU 显存、每个 epoch 的耗时。
   - 新增 `--debug-cuda` 参数用于精确定位异步 CUDA 错误。
4. `requirements-radar.txt`
   - 新增 `tqdm` 依赖。

## 建议先用的安全配置

```json
"data": {
  "max_points_per_frame": 256
},
"model": {
  "hidden_dims": [32, 64, 64],
  "nsamples": [8, 8, 8],
  "knn_query_chunk_size": 128
},
"train": {
  "batch_size": 1
}
```

其余 `data` / `model` / `train` 字段要保留在原 JSON 对应对象内，不要把以上片段直接当成完整配置覆盖。

## Windows 运行

在项目根目录运行：

```bat
python -m pip install -r requirements-radar.txt
python radar_train.py --csv .\data\data.csv --config radar_config.json --output outputs\radar_pointlstm
```

如果仍报 CUDA/CUBLAS 错误：

```bat
python radar_train.py --csv .\data\data.csv --config radar_config.json --output outputs\radar_pointlstm --debug-cuda
```

将完整 traceback、程序打印的 `xyz/features/mask` shape、`T` 和 GPU 显存信息一起保存，便于继续定位。

## 注意

- 新默认模型宽度是 `[32,64,64]`，和旧版 `[64,128,128]` 不同，因此旧版 checkpoint 不一定能加载；首次请从头训练。
- `max_points_per_frame=256` 是为了先稳定运行。确认训练稳定后，可逐步尝试 384、512；每次只改一个参数并观察显存与速度。
- 纯 PyTorch KNN 仍会比定制 CUDA 算子慢。此次优化减少重复搜索和峰值内存，但不代表所有规模的数据都能实时训练。
- 当前运行环境没有可用于验证的 CUDA GPU；已在合成 CSV 上完成 CPU 前向、反向传播和一个 epoch 的 smoke test。请在你的 Windows GPU 环境中验证 CUDA 路径。
