# 本次修改说明

## 任务变化
原仓库解决“点云序列未来帧预测”；本版本新增雷达任务，解决“同一30°方位扇区、连续多圈点迹中的逐点真/假分类”。原 Moving-MNIST 文件保留，雷达功能作为独立入口加入。

## 新增内容
- `radar/dataset.py`：CSV读取、自动判圈/已有圈号、30°扇区、连续L圈滑窗、动态padding、mask、特征标准化、极坐标转xyz。
- `radar/masked_ops.py`：纯PyTorch mask-aware KNN/radius邻域搜索，padding不会成为邻居。
- `radar/model.py`：mask-aware PointLSTM，保留I/F/O/C门与跨时刻点相关结构；输出 `[B,L,T,2]`。
- `radar/metrics.py`：Accuracy/Precision/Recall/F1。
- `radar_train.py`：masked CrossEntropy、AdamW、checkpoint。
- `radar_predict.py`：逐点概率与标签导出。
- `inspect_radar_csv.py`：查看CSV字段。
- `radar_config.json`：所有常用参数集中配置。
- `RADAR_README.md`：完整使用说明。

## 后续最常改参数
1. CSV映射：`columns.range/azimuth/elevation/round_id/label/features`
2. 序列：`data.sequence_length`、`sequence_stride`
3. 扇区：`data.sector_width_deg`（当前30°）
4. 点数：`data.max_points_per_frame`，0表示不主动截断，batch内动态padding
5. 标签：`data.positive_label_values`
6. 空间尺度：`data.range_scale` 与 `model.radius` 联合调整
7. 模型：`hidden_dims`、`radius`、`nsamples`、`dropout`
8. 训练：`batch_size`、`epochs`、`lr`、`class_weights`

## 仍需按真实CSV映射的内容
- 真值标签是哪一列、真实点如何编码；
- 圈号列是否存在。若没有，CSV必须保持采集时间顺序，才能根据360°->0°方位回绕自动判圈。


## 运行进度与稳定性修复（本次）
- CSV 分块读取并显示进度；显示字段处理、圈扇区分组、滑窗和样本索引阶段耗时。
- train/val 共享同一次预处理，避免完整 CSV 被重复读取和分组。
- 训练/验证增加 tqdm batch 进度、每批张量形状/有效点数、Loss、每轮耗时和 GPU 显存提示。
- KNN 距离矩阵分块计算，限制临时显存峰值；同一 PointLSTM cell 的 5 个门复用同一组邻域索引，减少重复 cdist/top-k。
- 超过 max_points_per_frame 时优先保留正类点，再采样负类点，缓解杂波数量远多于目标点导致目标被均匀抽样丢弃的问题。
- 安全默认参数调整为 max_points_per_frame=256、batch_size=1、hidden_dims=[32,64,64]、nsamples=[8,8,8]。
- 新增 `--debug-cuda` 选项；输入出现 NaN/Inf 时提前报错并显示张量形状。
